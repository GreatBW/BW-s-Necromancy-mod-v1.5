﻿// Copyright (C)
// See LICENSE file for extended copyright information.
// This file is part of the repository from .

using ModShardLauncher;
using ModShardLauncher.Mods;
using UndertaleModLib.Models;

namespace Necromancy
{
    public class Necromancy : Mod
    {
        public override string Author => "BW, Kurs, CommissarAmethyst, Zizani";
        public override string Name => "BW's Necromancy";
        public override string Description => "Necromancy Reborn revamps undead mechanics, balancing enemies, adding 14 abilities, 200+ objects, and code improvements.";
        public override string Version => "0.9.3.13 (1.5)";
        public override string TargetVersion => "0.9.3.13";

        public override void PatchMod()
        {
            // sprites 

            Msl.GetSprite("s_bwdis").OriginX = 340;
            Msl.GetSprite("s_bwdis").OriginY = 275;
            Msl.GetSprite("s_bw_stage_sprite").OriginX = 8;
            Msl.GetSprite("s_bw_stage_sprite").OriginY = 5;
            Msl.GetSprite("s_bw_b_sealofpower_unholy").OriginX = 12;
            Msl.GetSprite("s_bw_b_sealofpower_unholy").OriginY = 12;
            Msl.GetSprite("s_bandit_arbalester_z_melee").OriginX = 36;
            Msl.GetSprite("s_bandit_arbalester_z_melee").OriginY = 43;
            Msl.GetSprite("s_bandit_outlaw_z_melee").OriginX = 36;
            Msl.GetSprite("s_bandit_outlaw_z_melee").OriginY = 43;
            Msl.GetSprite("s_bandit_poacher01_z_melee").OriginX = 36;
            Msl.GetSprite("s_bandit_poacher01_z_melee").OriginY = 43;
            Msl.GetSprite("s_bandit_arbalester_z").OriginX = 36;
            Msl.GetSprite("s_bandit_arbalester_z").OriginY = 43;
            Msl.GetSprite("s_bandit_crook_z").OriginX = 36;
            Msl.GetSprite("s_bandit_crook_z").OriginY = 43;
            Msl.GetSprite("s_bandit_cutthroat_z").OriginX = 36;
            Msl.GetSprite("s_bandit_cutthroat_z").OriginY = 43;
            Msl.GetSprite("s_proselyte_outcast_z").OriginX = 37;
            Msl.GetSprite("s_proselyte_outcast_z").OriginY = 32;
            Msl.GetSprite("s_bandit_madman_z").OriginX = 36;
            Msl.GetSprite("s_bandit_madman_z").OriginY = 43;
            Msl.GetSprite("s_teal_ball").OriginX = 17;
            Msl.GetSprite("s_teal_ball").OriginY = 12;
            Msl.GetSprite("s_bandit_goon_cleaver_z").OriginX = 36;
            Msl.GetSprite("s_bandit_goon_cleaver_z").OriginY = 43;
            Msl.GetSprite("s_bandit_goon_club_z").OriginX = 36;
            Msl.GetSprite("s_bandit_goon_club_z").OriginY = 43;
            Msl.GetSprite("s_bandit_halberdier_z").OriginX = 36;
            Msl.GetSprite("s_bandit_halberdier_z").OriginY = 43;
            Msl.GetSprite("s_bandit_henchman_axe_z").OriginX = 36;
            Msl.GetSprite("s_bandit_henchman_axe_z").OriginY = 43;
            Msl.GetSprite("s_bandit_kingpin_z").OriginX = 36;
            Msl.GetSprite("s_bandit_kingpin_z").OriginY = 43;
            Msl.GetSprite("s_proselyte_outcast_z_swim").OriginX = 37;
            Msl.GetSprite("s_proselyte_outcast_z_swim").OriginY = 32;
            Msl.GetSprite("s_bandit_mancatcher_z").OriginX = 36;
            Msl.GetSprite("s_bandit_mancatcher_z").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_2haxe_z").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_2haxe_z").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_2hflail_z").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_2hflail_z").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_2hsword_z").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_2hsword_z").OriginY = 43;
            Msl.GetSprite("s_bandit_outlaw_z").OriginX = 36;
            Msl.GetSprite("s_bandit_outlaw_z").OriginY = 43;
            Msl.GetSprite("s_bandit_poacher01_z").OriginX = 36;
            Msl.GetSprite("s_bandit_poacher01_z").OriginY = 43;
            Msl.GetSprite("s_bandit_thug_2haxe_z").OriginX = 36;
            Msl.GetSprite("s_bandit_thug_2haxe_z").OriginY = 43;
            Msl.GetSprite("s_bandit_renegade_mace_z").OriginX = 36;
            Msl.GetSprite("s_bandit_renegade_mace_z").OriginY = 43;
            Msl.GetSprite("s_bandit_thug_2hsword_z").OriginX = 36;
            Msl.GetSprite("s_bandit_thug_2hsword_z").OriginY = 43;
            Msl.GetSprite("s_bw_attitude_attack").OriginX = 12;
            Msl.GetSprite("s_bw_attitude_attack").OriginY = 12;
            Msl.GetSprite("s_bandit_thug_spear_z").OriginX = 36;
            Msl.GetSprite("s_bandit_thug_spear_z").OriginY = 43;
            Msl.GetSprite("s_bandit_rioter_z").OriginX = 36;
            Msl.GetSprite("s_bandit_rioter_z").OriginY = 43;
            Msl.GetSprite("s_bandit_rogue_mage_z").OriginX = 36;
            Msl.GetSprite("s_bandit_rogue_mage_z").OriginY = 43;
            Msl.GetSprite("s_bandit_sidekick_mace_z").OriginX = 36;
            Msl.GetSprite("s_bandit_sidekick_mace_z").OriginY = 43;
            Msl.GetSprite("s_bandit_soldier_axe_z").OriginX = 36;
            Msl.GetSprite("s_bandit_soldier_axe_z").OriginY = 43;
            Msl.GetSprite("s_bandit_soldier_mace_z").OriginX = 36;
            Msl.GetSprite("s_bandit_soldier_mace_z").OriginY = 43;
            Msl.GetSprite("s_bandit_soldier_sword_z").OriginX = 36;
            Msl.GetSprite("s_bandit_soldier_sword_z").OriginY = 43;
            Msl.GetSprite("s_bandit_goon_flail_z").OriginX = 36;
            Msl.GetSprite("s_bandit_goon_flail_z").OriginY = 43;
            Msl.GetSprite("s_bandit_enforcer_2haxe_z").OriginX = 36;
            Msl.GetSprite("s_bandit_enforcer_2haxe_z").OriginY = 43;
            Msl.GetSprite("s_bandit_enforcer_2hsword_z").OriginX = 36;
            Msl.GetSprite("s_bandit_enforcer_2hsword_z").OriginY = 43;
            Msl.GetSprite("s_rec_resep").OriginX = 12;
            Msl.GetSprite("s_rec_resep").OriginY = 12;
            Msl.GetSprite("s_bw_attitude_follow").OriginX = 12;
            Msl.GetSprite("s_bw_attitude_follow").OriginY = 12;
            Msl.GetSprite("s_bandit_enforcer_2hmace_z").OriginX = 36;
            Msl.GetSprite("s_bandit_enforcer_2hmace_z").OriginY = 43;
            Msl.GetSprite("s_bandit_warlock_z").OriginX = 36;
            Msl.GetSprite("s_bandit_warlock_z").OriginY = 43;
            Msl.GetSprite("s_bandit_arbalester_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_arbalester_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_crook_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_crook_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_cutthroat_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_cutthroat_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_madman_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_madman_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_goon_cleaver_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_goon_cleaver_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_goon_club_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_goon_club_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_halberdier_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_halberdier_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_henchman_axe_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_henchman_axe_z_swim").OriginY = 43;
            Msl.GetSprite("s_rec_rese").OriginX = 12;
            Msl.GetSprite("s_rec_rese").OriginY = 12;
            Msl.GetSprite("s_bandit_kingpin_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_kingpin_z_swim").OriginY = 43;
            Msl.GetSprite("s_buff_cursse").OriginX = 12;
            Msl.GetSprite("s_buff_cursse").OriginY = 12;
            Msl.GetSprite("s_buff_death_blesss").OriginX = 12;
            Msl.GetSprite("s_buff_death_blesss").OriginY = 12;
            Msl.GetSprite("s_bandit_mancatcher_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_mancatcher_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_2haxe_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_2haxe_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_2hflail_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_2hflail_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_2hsword_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_2hsword_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_outlaw_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_outlaw_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_poacher01_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_poacher01_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_thug_2haxe_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_thug_2haxe_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_renegade_mace_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_renegade_mace_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_thug_2hsword_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_thug_2hsword_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_thug_spear_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_thug_spear_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_rioter_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_rioter_z_swim").OriginY = 43;
            Msl.GetSprite("s_buff_punish").OriginX = 12;
            Msl.GetSprite("s_buff_punish").OriginY = 12;
            Msl.GetSprite("s_b_sealofpower_unholy").OriginX = 12;
            Msl.GetSprite("s_b_sealofpower_unholy").OriginY = 12;
            Msl.GetSprite("s_bandit_rogue_mage_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_rogue_mage_z_swim").OriginY = 43;
            Msl.GetSprite("s_charged_z").OriginX = 12;
            Msl.GetSprite("s_charged_z").OriginY = 12;
            Msl.GetSprite("s_dark_enchant_effect").OriginX = 12;
            Msl.GetSprite("s_dark_enchant_effect").OriginY = 12;
            Msl.GetSprite("s_bandit_sidekick_mace_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_sidekick_mace_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_soldier_axe_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_soldier_axe_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_soldier_mace_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_soldier_mace_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_soldier_sword_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_soldier_sword_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_goon_flail_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_goon_flail_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_enforcer_2haxe_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_enforcer_2haxe_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_enforcer_2hsword_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_enforcer_2hsword_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_enforcer_2hmace_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_enforcer_2hmace_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_warlock_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_warlock_z_swim").OriginY = 43;
            Msl.GetSprite("s_exception_soulus").OriginX = 12;
            Msl.GetSprite("s_exception_soulus").OriginY = 12;
            Msl.GetSprite("s_icon_unbind").OriginX = 12;
            Msl.GetSprite("s_icon_unbind").OriginY = 12;
            Msl.GetSprite("s_rec_resa").OriginX = 12;
            Msl.GetSprite("s_rec_resa").OriginY = 12;
            Msl.GetSprite("s_rec_resf").OriginX = 12;
            Msl.GetSprite("s_rec_resf").OriginY = 12;
            Msl.GetSprite("s_cryptwarden_swim").OriginX = 35;
            Msl.GetSprite("s_cryptwarden_swim").OriginY = 46;
            Msl.GetSprite("s_proselyte_adept_z").OriginX = 27;
            Msl.GetSprite("s_proselyte_adept_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_champion_z").OriginX = 28;
            Msl.GetSprite("s_proselyte_champion_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_flagellant_z").OriginX = 27;
            Msl.GetSprite("s_proselyte_flagellant_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_hierarch_z").OriginX = 28;
            Msl.GetSprite("s_proselyte_hierarch_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_immolated_z").OriginX = 28;
            Msl.GetSprite("s_proselyte_immolated_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_toller_z").OriginX = 27;
            Msl.GetSprite("s_proselyte_toller_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_tormentor_z").OriginX = 28;
            Msl.GetSprite("s_proselyte_tormentor_z").OriginY = 41;
            Msl.GetSprite("s_take_over_effect").OriginX = 12;
            Msl.GetSprite("s_take_over_effect").OriginY = 12;
            Msl.GetSprite("s_proselyte_adept_z_swim").OriginX = 27;
            Msl.GetSprite("s_proselyte_adept_z_swim").OriginY = 41;
            Msl.GetSprite("s_b_winks").OriginX = 12;
            Msl.GetSprite("s_b_winks").OriginY = 12;
            Msl.GetSprite("s_proselyte_champion_z_swim").OriginX = 28;
            Msl.GetSprite("s_proselyte_champion_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_flagellant_z_swim").OriginX = 27;
            Msl.GetSprite("s_proselyte_flagellant_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_hierarch_z_swim").OriginX = 28;
            Msl.GetSprite("s_proselyte_hierarch_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_immolated_z_swim").OriginX = 28;
            Msl.GetSprite("s_proselyte_immolated_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_toller_z_swim").OriginX = 27;
            Msl.GetSprite("s_proselyte_toller_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_tormentor_z_swim").OriginX = 28;
            Msl.GetSprite("s_proselyte_tormentor_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_apostate_z").OriginX = 27;
            Msl.GetSprite("s_proselyte_apostate_z").OriginY = 47;
            Msl.GetSprite("s_proselyte_apostate_z_swim").OriginX = 27;
            Msl.GetSprite("s_proselyte_apostate_z_swim").OriginY = 47;
            Msl.GetSprite("s_proselyte_harbinger_z").OriginX = 27;
            Msl.GetSprite("s_proselyte_harbinger_z").OriginY = 38;
            Msl.GetSprite("s_proselyte_harbinger_z_swim").OriginX = 27;
            Msl.GetSprite("s_proselyte_harbinger_z_swim").OriginY = 38;
            Msl.GetSprite("s_angel_of_death").OriginX = 12;
            Msl.GetSprite("s_angel_of_death").OriginY = 12;
            Msl.GetSprite("s_crazed_by_magic").OriginX = 12;
            Msl.GetSprite("s_crazed_by_magic").OriginY = 12;
            Msl.GetSprite("s_ghoul_large_z").OriginX = 38;
            Msl.GetSprite("s_ghoul_large_z").OriginY = 35;
            Msl.GetSprite("s_ghoul_medium_z").OriginX = 38;
            Msl.GetSprite("s_ghoul_medium_z").OriginY = 35;
            Msl.GetSprite("s_ghoul_small_z").OriginX = 38;
            Msl.GetSprite("s_ghoul_small_z").OriginY = 35;
            Msl.GetSprite("s_proselyte_brander_z").OriginX = 29;
            Msl.GetSprite("s_proselyte_brander_z").OriginY = 44;
            Msl.GetSprite("s_ghoul_large_z_swim").OriginX = 38;
            Msl.GetSprite("s_ghoul_large_z_swim").OriginY = 35;
            Msl.GetSprite("s_ghoul_medium_z_swim").OriginX = 38;
            Msl.GetSprite("s_ghoul_medium_z_swim").OriginY = 35;
            Msl.GetSprite("s_ghoul_small_z_swim").OriginX = 38;
            Msl.GetSprite("s_ghoul_small_z_swim").OriginY = 35;
            Msl.GetSprite("s_proselyte_juggernaut_z").OriginX = 26;
            Msl.GetSprite("s_proselyte_juggernaut_z").OriginY = 44;
            Msl.GetSprite("s_growing_madness").OriginX = 12;
            Msl.GetSprite("s_growing_madness").OriginY = 12;
            Msl.GetSprite("s_proselyte_brander_z_swim").OriginX = 29;
            Msl.GetSprite("s_proselyte_brander_z_swim").OriginY = 44;
            Msl.GetSprite("s_proselyte_juggernaut_z_swim").OriginX = 26;
            Msl.GetSprite("s_proselyte_juggernaut_z_swim").OriginY = 44;
            Msl.GetSprite("s_necromancer01_swim").OriginX = 29;
            Msl.GetSprite("s_necromancer01_swim").OriginY = 37;
            Msl.GetSprite("s_necromancer02_swim").OriginX = 29;
            Msl.GetSprite("s_necromancer02_swim").OriginY = 37;
            Msl.GetSprite("s_necromancer04_swim").OriginX = 29;
            Msl.GetSprite("s_necromancer04_swim").OriginY = 37;
            Msl.GetSprite("s_necromancer05_swim").OriginX = 29;
            Msl.GetSprite("s_necromancer05_swim").OriginY = 37;
            Msl.GetSprite("s_necromancer06_swim").OriginX = 29;
            Msl.GetSprite("s_necromancer06_swim").OriginY = 37;
            Msl.GetSprite("s_imortal_soul").OriginX = 12;
            Msl.GetSprite("s_imortal_soul").OriginY = 12;
            Msl.GetSprite("s_proselyte_anmarak_z").OriginX = 24;
            Msl.GetSprite("s_proselyte_anmarak_z").OriginY = 43;
            Msl.GetSprite("s_proselyte_anmarak_z_swim").OriginX = 24;
            Msl.GetSprite("s_proselyte_anmarak_z_swim").OriginY = 43;
            Msl.GetSprite("s_zombie14_swim").OriginX = 27;
            Msl.GetSprite("s_zombie14_swim").OriginY = 35;
            Msl.GetSprite("s_proselyte_matriarch_z").OriginX = 26;
            Msl.GetSprite("s_proselyte_matriarch_z").OriginY = 42;
            Msl.GetSprite("s_proselyte_matriarch_z_swim").OriginX = 26;
            Msl.GetSprite("s_proselyte_matriarch_z_swim").OriginY = 42;
            Msl.GetSprite("s_archivist_swim").OriginX = 27;
            Msl.GetSprite("s_archivist_swim").OriginY = 37;
            Msl.GetSprite("s_ghast02_swim").OriginX = 27;
            Msl.GetSprite("s_ghast02_swim").OriginY = 38;
            Msl.GetSprite("s_ghast03_swim").OriginX = 27;
            Msl.GetSprite("s_ghast03_swim").OriginY = 38;
            Msl.GetSprite("s_ghast_swim").OriginX = 27;
            Msl.GetSprite("s_ghast_swim").OriginY = 38;
            Msl.GetSprite("s_mortician_swim").OriginX = 27;
            Msl.GetSprite("s_mortician_swim").OriginY = 37;
            Msl.GetSprite("s_undertaker_swim").OriginX = 27;
            Msl.GetSprite("s_undertaker_swim").OriginY = 37;
            Msl.GetSprite("s_teal_ball_cast").OriginX = 31;
            Msl.GetSprite("s_teal_ball_cast").OriginY = 20;
            Msl.GetSprite("s_husk_swim").OriginX = 28;
            Msl.GetSprite("s_husk_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_armorbreaker_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_armorbreaker_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_axeman_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_axeman_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_bowman_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_bowman_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_crossbowman_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_crossbowman_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_defender_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_defender_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_footman_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_footman_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_guardianaxe_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_guardianaxe_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_guardianmace_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_guardianmace_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_guard_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_guard_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_halberdier_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_halberdier_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_highpriest_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_highpriest_swim").OriginY = 38;
            Msl.GetSprite("s_zombie15_swim").OriginX = 19;
            Msl.GetSprite("s_zombie15_swim").OriginY = 33;
            Msl.GetSprite("s_skeleton_knightaxe_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_knightaxe_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_knighthammer_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_knighthammer_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_knightspear_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_knightspear_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_knightswordshield_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_knightswordshield_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_knightsword_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_knightsword_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_maceman_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_maceman_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_militiaman_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_militiaman_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_monk_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_monk_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_priest_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_priest_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_ranger_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_ranger_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_soldier_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_soldier_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_spearman_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_spearman_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_swordsman_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_swordsman_swim").OriginY = 38;
            Msl.GetSprite("s_skeleton_warrior_swim").OriginX = 28;
            Msl.GetSprite("s_skeleton_warrior_swim").OriginY = 38;
            Msl.GetSprite("s_proselyte_girrud_z").OriginX = 22;
            Msl.GetSprite("s_proselyte_girrud_z").OriginY = 30;
            Msl.GetSprite("s_bandit_heavyarbalester_z_melee").OriginX = 26;
            Msl.GetSprite("s_bandit_heavyarbalester_z_melee").OriginY = 41;
            Msl.GetSprite("s_bandit_huntmaster_z_melee").OriginX = 26;
            Msl.GetSprite("s_bandit_huntmaster_z_melee").OriginY = 41;
            Msl.GetSprite("s_bandit_longbowman_z_melee").OriginX = 26;
            Msl.GetSprite("s_bandit_longbowman_z_melee").OriginY = 41;
            Msl.GetSprite("s_bandit_banneret_z").OriginX = 16;
            Msl.GetSprite("s_bandit_banneret_z").OriginY = 43;
            Msl.GetSprite("s_bandit_bonebreaker_axe_z").OriginX = 20;
            Msl.GetSprite("s_bandit_bonebreaker_axe_z").OriginY = 41;
            Msl.GetSprite("s_bandit_bonebreaker_mace_z").OriginX = 20;
            Msl.GetSprite("s_bandit_bonebreaker_mace_z").OriginY = 41;
            Msl.GetSprite("s_bandit_conjurer_z").OriginX = 26;
            Msl.GetSprite("s_bandit_conjurer_z").OriginY = 41;
            Msl.GetSprite("s_bandit_duelist_z").OriginX = 26;
            Msl.GetSprite("s_bandit_duelist_z").OriginY = 41;
            Msl.GetSprite("s_reaping_darkness").OriginX = 12;
            Msl.GetSprite("s_reaping_darkness").OriginY = 12;
            Msl.GetSprite("s_bandit_electromancer_z").OriginX = 26;
            Msl.GetSprite("s_bandit_electromancer_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_girrud_z_swim").OriginX = 22;
            Msl.GetSprite("s_proselyte_girrud_z_swim").OriginY = 30;
            Msl.GetSprite("s_bandit_geomancer_z").OriginX = 26;
            Msl.GetSprite("s_bandit_geomancer_z").OriginY = 41;
            Msl.GetSprite("s_bandit_gmdeserter_gaxe_z").OriginX = 26;
            Msl.GetSprite("s_bandit_gmdeserter_gaxe_z").OriginY = 41;
            Msl.GetSprite("s_bandit_gmdeserter_ghammer_z").OriginX = 26;
            Msl.GetSprite("s_bandit_gmdeserter_ghammer_z").OriginY = 41;
            Msl.GetSprite("s_bandit_gmdeserter_polearm_z").OriginX = 26;
            Msl.GetSprite("s_bandit_gmdeserter_polearm_z").OriginY = 41;
            Msl.GetSprite("s_bandit_heavyarbalester_z").OriginX = 26;
            Msl.GetSprite("s_bandit_heavyarbalester_z").OriginY = 41;
            Msl.GetSprite("s_bandit_huntmaster_z").OriginX = 26;
            Msl.GetSprite("s_bandit_huntmaster_z").OriginY = 41;
            Msl.GetSprite("s_bandit_longbowman_z").OriginX = 26;
            Msl.GetSprite("s_bandit_longbowman_z").OriginY = 41;
            Msl.GetSprite("s_bandit_magehunter_z").OriginX = 26;
            Msl.GetSprite("s_bandit_magehunter_z").OriginY = 41;
            Msl.GetSprite("s_bandit_paymaster_z").OriginX = 26;
            Msl.GetSprite("s_bandit_paymaster_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_abomination_z").OriginX = 18;
            Msl.GetSprite("s_proselyte_abomination_z").OriginY = 31;
            Msl.GetSprite("s_bandit_raubritter_2hmace_z").OriginX = 27;
            Msl.GetSprite("s_bandit_raubritter_2hmace_z").OriginY = 41;
            Msl.GetSprite("s_bandit_raubritter_2hsword_z").OriginX = 22;
            Msl.GetSprite("s_bandit_raubritter_2hsword_z").OriginY = 41;
            Msl.GetSprite("s_bandit_raubritter_flail_z").OriginX = 26;
            Msl.GetSprite("s_bandit_raubritter_flail_z").OriginY = 41;
            Msl.GetSprite("s_bandit_ringleader_2hsword_z").OriginX = 26;
            Msl.GetSprite("s_bandit_ringleader_2hsword_z").OriginY = 41;
            Msl.GetSprite("s_bandit_ringleader_shield_z").OriginX = 26;
            Msl.GetSprite("s_bandit_ringleader_shield_z").OriginY = 41;
            Msl.GetSprite("s_bandit_sergeant_axe_z").OriginX = 26;
            Msl.GetSprite("s_bandit_sergeant_axe_z").OriginY = 41;
            Msl.GetSprite("s_bandit_sergeant_gsword_z").OriginX = 26;
            Msl.GetSprite("s_bandit_sergeant_gsword_z").OriginY = 41;
            Msl.GetSprite("s_bandit_sergeant_hammer_z").OriginX = 26;
            Msl.GetSprite("s_bandit_sergeant_hammer_z").OriginY = 41;
            Msl.GetSprite("s_bandit_sergeant_mace_z").OriginX = 26;
            Msl.GetSprite("s_bandit_sergeant_mace_z").OriginY = 41;
            Msl.GetSprite("s_bandit_turncoat_sword_z").OriginX = 36;
            Msl.GetSprite("s_bandit_turncoat_sword_z").OriginY = 43;
            Msl.GetSprite("s_soulzac").OriginX = 12;
            Msl.GetSprite("s_soulzac").OriginY = 12;
            Msl.GetSprite("s_proselyte_gifted_axe_z").OriginX = 26;
            Msl.GetSprite("s_proselyte_gifted_axe_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_abomination_z_swim").OriginX = 18;
            Msl.GetSprite("s_proselyte_abomination_z_swim").OriginY = 31;
            Msl.GetSprite("s_proselyte_gifted_mace_z").OriginX = 26;
            Msl.GetSprite("s_proselyte_gifted_mace_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_impaler_z").OriginX = 26;
            Msl.GetSprite("s_proselyte_impaler_z").OriginY = 42;
            Msl.GetSprite("s_proselyte_murkstalker_z").OriginX = 26;
            Msl.GetSprite("s_proselyte_murkstalker_z").OriginY = 41;
            Msl.GetSprite("s_proselyte_wormbearer_z").OriginX = 26;
            Msl.GetSprite("s_proselyte_wormbearer_z").OriginY = 40;
            Msl.GetSprite("s_proselyte_yagram_z").OriginX = 26;
            Msl.GetSprite("s_proselyte_yagram_z").OriginY = 41;
            Msl.GetSprite("s_bandit_banneret_z_swim").OriginX = 16;
            Msl.GetSprite("s_bandit_banneret_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_bonebreaker_axe_z_swim").OriginX = 20;
            Msl.GetSprite("s_bandit_bonebreaker_axe_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_bonebreaker_mace_z_swim").OriginX = 20;
            Msl.GetSprite("s_bandit_bonebreaker_mace_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_conjurer_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_conjurer_z_swim").OriginY = 41;
            Msl.GetSprite("s_zombie16_swim").OriginX = 27;
            Msl.GetSprite("s_zombie16_swim").OriginY = 32;
            Msl.GetSprite("s_bandit_duelist_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_duelist_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_electromancer_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_electromancer_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_geomancer_swim_z").OriginX = 26;
            Msl.GetSprite("s_bandit_geomancer_swim_z").OriginY = 41;
            Msl.GetSprite("s_bandit_gmdeserter_gaxe_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_gmdeserter_gaxe_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_gmdeserter_ghammer_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_gmdeserter_ghammer_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_gmdeserter_polearm_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_gmdeserter_polearm_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_heavyarbalester_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_heavyarbalester_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_huntmaster_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_huntmaster_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_longbowman_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_longbowman_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_magehunter_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_magehunter_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_paymaster_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_paymaster_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_raubritter_2hmace_z_swim").OriginX = 27;
            Msl.GetSprite("s_bandit_raubritter_2hmace_z_swim").OriginY = 41;
            Msl.GetSprite("s_zombie12_swim").OriginX = 20;
            Msl.GetSprite("s_zombie12_swim").OriginY = 33;
            Msl.GetSprite("s_bandit_raubritter_2hsword_z_swim").OriginX = 22;
            Msl.GetSprite("s_bandit_raubritter_2hsword_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_raubritter_flail_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_raubritter_flail_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_ringleader_2hsword_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_ringleader_2hsword_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_ringleader_shield_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_ringleader_shield_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_sergeant_axe_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_sergeant_axe_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_sergeant_gsword_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_sergeant_gsword_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_sergeant_hammer_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_sergeant_hammer_z_swim").OriginY = 41;
            Msl.GetSprite("s_bandit_sergeant_mace_z_swim").OriginX = 26;
            Msl.GetSprite("s_bandit_sergeant_mace_z_swim").OriginY = 41;
            Msl.GetSprite("s_darkbolt_icon_off").OriginX = 12;
            Msl.GetSprite("s_darkbolt_icon_off").OriginY = 12;
            Msl.GetSprite("s_bandit_turncoat_sword_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_turncoat_sword_z_swim").OriginY = 43;
            Msl.GetSprite("s_zombie13_swim").OriginX = 24;
            Msl.GetSprite("s_zombie13_swim").OriginY = 32;
            Msl.GetSprite("s_proselyte_gifted_axe_z_swim").OriginX = 26;
            Msl.GetSprite("s_proselyte_gifted_axe_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_gifted_mace_z_swim").OriginX = 26;
            Msl.GetSprite("s_proselyte_gifted_mace_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_impaler_z_swim").OriginX = 26;
            Msl.GetSprite("s_proselyte_impaler_z_swim").OriginY = 42;
            Msl.GetSprite("s_proselyte_murkstalker_z_swim").OriginX = 26;
            Msl.GetSprite("s_proselyte_murkstalker_z_swim").OriginY = 41;
            Msl.GetSprite("s_proselyte_wormbearer_z_swim").OriginX = 26;
            Msl.GetSprite("s_proselyte_wormbearer_z_swim").OriginY = 40;
            Msl.GetSprite("s_bandit_thug_2hflail_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_thug_2hflail_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_thug_2hflail_z").OriginX = 36;
            Msl.GetSprite("s_bandit_thug_2hflail_z").OriginY = 43;
            Msl.GetSprite("s_proselyte_yagram_z_swim").OriginX = 26;
            Msl.GetSprite("s_proselyte_yagram_z_swim").OriginY = 41;
            Msl.GetSprite("s_zombie06_swim").OriginX = 25;
            Msl.GetSprite("s_zombie06_swim").OriginY = 29;
            Msl.GetSprite("s_proselyte_saggul_z").OriginX = 18;
            Msl.GetSprite("s_proselyte_saggul_z").OriginY = 32;
            Msl.GetSprite("s_proselyte_saggul_z_swim").OriginX = 18;
            Msl.GetSprite("s_proselyte_saggul_z_swim").OriginY = 32;
            Msl.GetSprite("s_restlesshero_swim").OriginX = 20;
            Msl.GetSprite("s_restlesshero_swim").OriginY = 30;
            Msl.GetSprite("s_zombie04_swim").OriginX = 20;
            Msl.GetSprite("s_zombie04_swim").OriginY = 30;
            Msl.GetSprite("s_zombie05_swim").OriginX = 20;
            Msl.GetSprite("s_zombie05_swim").OriginY = 30;
            Msl.GetSprite("s_zombie07_swim").OriginX = 20;
            Msl.GetSprite("s_zombie07_swim").OriginY = 30;
            Msl.GetSprite("s_zombie_01_swim").OriginX = 20;
            Msl.GetSprite("s_zombie_01_swim").OriginY = 30;
            Msl.GetSprite("s_zombie10_swim").OriginX = 24;
            Msl.GetSprite("s_zombie10_swim").OriginY = 30;
            Msl.GetSprite("s_zombie11_swim").OriginX = 27;
            Msl.GetSprite("s_zombie11_swim").OriginY = 28;
            Msl.GetSprite("s_zombie17_swim").OriginX = 13;
            Msl.GetSprite("s_zombie17_swim").OriginY = 30;
            Msl.GetSprite("s_darkness_sign_off").OriginX = 12;
            Msl.GetSprite("s_darkness_sign_off").OriginY = 12;
            Msl.GetSprite("s_zombie09_swim").OriginX = 20;
            Msl.GetSprite("s_zombie09_swim").OriginY = 30;
            Msl.GetSprite("s_painful_curse_off").OriginX = 12;
            Msl.GetSprite("s_painful_curse_off").OriginY = 12;
            Msl.GetSprite("s_skill_death_blesss_off").OriginX = 12;
            Msl.GetSprite("s_skill_death_blesss_off").OriginY = 12;
            Msl.GetSprite("s_soul_sacri_off").OriginX = 12;
            Msl.GetSprite("s_soul_sacri_off").OriginY = 12;
            Msl.GetSprite("s_touch_of_death_off").OriginX = 12;
            Msl.GetSprite("s_touch_of_death_off").OriginY = 12;
            Msl.GetSprite("s_undying_disaster_off").OriginX = 12;
            Msl.GetSprite("s_undying_disaster_off").OriginY = 12;
            Msl.GetSprite("s_unholy_bles_off").OriginX = 12;
            Msl.GetSprite("s_unholy_bles_off").OriginY = 12;
            Msl.GetSprite("s_unholy_resurrection_off").OriginX = 12;
            Msl.GetSprite("s_unholy_resurrection_off").OriginY = 12;
            Msl.GetSprite("s_blusss").OriginX = 12;
            Msl.GetSprite("s_blusss").OriginY = 12;
            Msl.GetSprite("s_pcurse").OriginX = 12;
            Msl.GetSprite("s_pcurse").OriginY = 12;
            Msl.GetSprite("s_darkbalz").OriginX = 12;
            Msl.GetSprite("s_darkbalz").OriginY = 12;
            Msl.GetSprite("s_dtouch").OriginX = 12;
            Msl.GetSprite("s_dtouch").OriginY = 12;
            Msl.GetSprite("s_disasterundead").OriginX = 12;
            Msl.GetSprite("s_disasterundead").OriginY = 12;
            Msl.GetSprite("s_recurct").OriginX = 12;
            Msl.GetSprite("s_recurct").OriginY = 12;
            Msl.GetSprite("s_soul_abs").OriginX = 12;
            Msl.GetSprite("s_soul_abs").OriginY = 12;
            Msl.GetSprite("s_wraithbind").OriginX = 12;
            Msl.GetSprite("s_wraithbind").OriginY = 12;
            Msl.GetSprite("s_MordredHead_normal").OriginX = 15;
            Msl.GetSprite("s_MordredHead_normal").OriginY = 36;
            Msl.GetSprite("s_MordredHead_helmet_normal").OriginX = 15;
            Msl.GetSprite("s_MordredHead_helmet_normal").OriginY = 36;
            Msl.GetSprite("s_MordredHead_blood").OriginX = 15;
            Msl.GetSprite("s_MordredHead_blood").OriginY = 36;
            Msl.GetSprite("s_MordredHead_helmet_blood").OriginX = 15;
            Msl.GetSprite("s_MordredHead_helmet_blood").OriginY = 36;
            Msl.GetSprite("s_Mordred_dead").OriginX = 20;
            Msl.GetSprite("s_Mordred_dead").OriginY = 20;
            Msl.GetSprite("s_bw_openbook").OriginX = 264;
            Msl.GetSprite("s_bw_openbook").OriginY = 153;
            Msl.GetSprite("s_char3_hexermantle").OriginX = 24;
            Msl.GetSprite("s_char3_hexermantle").OriginY = 34;
            Msl.GetSprite("s_char3_hexermantle_female").OriginX = 24;
            Msl.GetSprite("s_char3_hexermantle_female").OriginY = 34;
            Msl.GetSprite("s_char_hexermantle").OriginX = 24;
            Msl.GetSprite("s_char_hexermantle").OriginY = 34;
            Msl.GetSprite("s_char_hexermantle_female").OriginX = 24;
            Msl.GetSprite("s_char_hexermantle_female").OriginY = 34;
            Msl.GetSprite("s_bandit_sidekick_flail01_z").OriginX = 36;
            Msl.GetSprite("s_bandit_sidekick_flail01_z").OriginY = 43;
            Msl.GetSprite("s_bandit_sidekick_flail01_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_sidekick_flail01_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_rabblerouser_z").OriginX = 36;
            Msl.GetSprite("s_bandit_rabblerouser_z").OriginY = 43;
            Msl.GetSprite("s_bandit_rabblerouser_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_rabblerouser_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_firestarter_z").OriginX = 18;
            Msl.GetSprite("s_bandit_firestarter_z").OriginY = 30;
            Msl.GetSprite("s_bandit_firestarter_z_swim").OriginX = 18;
            Msl.GetSprite("s_bandit_firestarter_z_swim").OriginY = 30;
            Msl.GetSprite("s_bandit_marauder_2hmace_z").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_2hmace_z").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_2hmace_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_2hmace_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_halberd_z").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_halberd_z").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_halberd_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_halberd_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_spear_z").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_spear_z").OriginY = 43;
            Msl.GetSprite("s_bandit_marauder_spear_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_marauder_spear_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_turncoat_axe_z").OriginX = 36;
            Msl.GetSprite("s_bandit_turncoat_axe_z").OriginY = 43;
            Msl.GetSprite("s_bandit_turncoat_axe_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_turncoat_axe_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_turncoat_mace_z").OriginX = 36;
            Msl.GetSprite("s_bandit_turncoat_mace_z").OriginY = 43;
            Msl.GetSprite("s_bandit_turncoat_mace_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_turncoat_mace_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_turncoat_flail_z").OriginX = 36;
            Msl.GetSprite("s_bandit_turncoat_flail_z").OriginY = 43;
            Msl.GetSprite("s_bandit_turncoat_flail_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_turncoat_flail_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_hired_sorcerer_electro_z").OriginX = 36;
            Msl.GetSprite("s_bandit_hired_sorcerer_electro_z").OriginY = 43;
            Msl.GetSprite("s_bandit_hired_sorcerer_electro_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_hired_sorcerer_electro_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_drummer_z").OriginX = 36;
            Msl.GetSprite("s_bandit_drummer_z").OriginY = 43;
            Msl.GetSprite("s_bandit_drummer_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_drummer_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_deserter_2hflail_z").OriginX = 36;
            Msl.GetSprite("s_bandit_deserter_2hflail_z").OriginY = 43;
            Msl.GetSprite("s_bandit_deserter_2hflail_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_deserter_2hflail_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_witchhunter_z").OriginX = 36;
            Msl.GetSprite("s_bandit_witchhunter_z").OriginY = 43;
            Msl.GetSprite("s_bandit_witchhunter_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_witchhunter_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_ringleader_axe_z").OriginX = 36;
            Msl.GetSprite("s_bandit_ringleader_axe_z").OriginY = 43;
            Msl.GetSprite("s_bandit_ringleader_axe_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_ringleader_axe_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_ringleader_sword_z").OriginX = 36;
            Msl.GetSprite("s_bandit_ringleader_sword_z").OriginY = 43;
            Msl.GetSprite("s_bandit_ringleader_sword_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_ringleader_sword_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_renegade_2hflail_z").OriginX = 36;
            Msl.GetSprite("s_bandit_renegade_2hflail_z").OriginY = 43;
            Msl.GetSprite("s_bandit_renegade_2hflail_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_renegade_2hflail_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_renegade_halberd_z").OriginX = 36;
            Msl.GetSprite("s_bandit_renegade_halberd_z").OriginY = 43;
            Msl.GetSprite("s_bandit_renegade_halberd_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_renegade_halberd_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_renegade_2hmace_z").OriginX = 36;
            Msl.GetSprite("s_bandit_renegade_2hmace_z").OriginY = 43;
            Msl.GetSprite("s_bandit_renegade_2hmace_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_renegade_2hmace_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_overseer_z").OriginX = 36;
            Msl.GetSprite("s_bandit_overseer_z").OriginY = 43;
            Msl.GetSprite("s_bandit_overseer_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_overseer_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_scout_z").OriginX = 18;
            Msl.GetSprite("s_bandit_scout_z").OriginY = 30;
            Msl.GetSprite("s_bandit_scout_z_swim").OriginX = 18;
            Msl.GetSprite("s_bandit_scout_z_swim").OriginY = 30;
            Msl.GetSprite("s_bandit_miner_z").OriginX = 36;
            Msl.GetSprite("s_bandit_miner_z").OriginY = 43;
            Msl.GetSprite("s_bandit_miner_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_miner_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_raider_z").OriginX = 36;
            Msl.GetSprite("s_bandit_raider_z").OriginY = 43;
            Msl.GetSprite("s_bandit_raider_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_raider_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_torturer_z").OriginX = 36;
            Msl.GetSprite("s_bandit_torturer_z").OriginY = 43;
            Msl.GetSprite("s_bandit_torturer_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_torturer_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_prospector_z").OriginX = 36;
            Msl.GetSprite("s_bandit_prospector_z").OriginY = 43;
            Msl.GetSprite("s_bandit_prospector_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_prospector_z_swim").OriginY = 43;
            Msl.GetSprite("s_bandit_spelunker_z").OriginX = 18;
            Msl.GetSprite("s_bandit_spelunker_z").OriginY = 30;
            Msl.GetSprite("s_bandit_spelunker_z_swim").OriginX = 18;
            Msl.GetSprite("s_bandit_spelunker_z_swim").OriginY = 30;
            Msl.GetSprite("s_bandit_arcanist_z").OriginX = 36;
            Msl.GetSprite("s_bandit_arcanist_z").OriginY = 43;
            Msl.GetSprite("s_bandit_arcanist_z_swim").OriginX = 36;
            Msl.GetSprite("s_bandit_arcanist_z_swim").OriginY = 43;
            Msl.GetSprite("s_bw_heraldzombie").OriginX = 18;
            Msl.GetSprite("s_bw_heraldzombie").OriginY = 30;
            Msl.GetSprite("s_bw_heraldzombie_swim").OriginX = 18;
            Msl.GetSprite("s_bw_heraldzombie_swim").OriginY = 30;

            UndertaleSprite s_charming = Msl.GetSprite("s_charming");
            s_charming.OriginX = 32;
            s_charming.OriginY = 59;
            s_charming.IsSpecialType = true;
            s_charming.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerGameFrame;
            s_charming.GMS2PlaybackSpeed = 0.33f;

            UndertaleSprite s_teal_curse = Msl.GetSprite("s_teal_curse");
            s_teal_curse.OriginX = 20;
            s_teal_curse.OriginY = 61;
            s_teal_curse.IsSpecialType = true;
            s_teal_curse.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerGameFrame;
            s_teal_curse.GMS2PlaybackSpeed = 0.4f;

            UndertaleSprite s_curse_cast = Msl.GetSprite("s_curse_cast");
            s_curse_cast.OriginX = 17;
            s_curse_cast.OriginY = 30;
            s_curse_cast.IsSpecialType = true;
            s_curse_cast.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerGameFrame;
            s_curse_cast.GMS2PlaybackSpeed = 0.4f;

            UndertaleSprite s_bw_signcast = Msl.GetSprite("s_bw_signcast");
            s_bw_signcast.OriginX = 17;
            s_bw_signcast.OriginY = 63;
            s_bw_signcast.IsSpecialType = true;
            s_bw_signcast.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerGameFrame;
            s_bw_signcast.GMS2PlaybackSpeed = 0.3f;

            UndertaleSprite s_bw_signmark = Msl.GetSprite("s_bw_signmark");
            s_bw_signmark.OriginX = 25;
            s_bw_signmark.OriginY = 30;
            s_bw_signmark.IsSpecialType = true;
            s_bw_signmark.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerSecond;
            s_bw_signmark.GMS2PlaybackSpeed = 15;

            UndertaleSprite s_bw_sigilend = Msl.GetSprite("s_bw_sigilend");
            s_bw_sigilend.OriginX = 25;
            s_bw_sigilend.OriginY = 30;
            s_bw_sigilend.IsSpecialType = true;
            s_bw_sigilend.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerSecond;
            s_bw_sigilend.GMS2PlaybackSpeed = 15;

            UndertaleSprite s_bw_resurrection = Msl.GetSprite("s_bw_resurrection");
            s_bw_resurrection.OriginX = 19;
            s_bw_resurrection.OriginY = 42;
            s_bw_resurrection.IsSpecialType = true;
            s_bw_resurrection.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerGameFrame;
            s_bw_resurrection.GMS2PlaybackSpeed = 0.48f;

            UndertaleSprite s_bw_elder_ritual = Msl.GetSprite("s_bw_elder_ritual");
            s_bw_elder_ritual.OriginX = 40;
            s_bw_elder_ritual.OriginY = 75;
            s_bw_elder_ritual.IsSpecialType = true;
            s_bw_elder_ritual.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerGameFrame;
            s_bw_elder_ritual.GMS2PlaybackSpeed = 0.4f;

            UndertaleSprite s_bw_herald_birth = Msl.GetSprite("s_bw_herald_birth");
            s_bw_herald_birth.OriginX = 18;
            s_bw_herald_birth.OriginY = 39;
            s_bw_herald_birth.IsSpecialType = true;
            s_bw_herald_birth.GMS2PlaybackSpeedType = AnimSpeedType.FramesPerGameFrame;
            s_bw_herald_birth.GMS2PlaybackSpeed = 0.6f;

            // Add New Objects

            UndertaleGameObject o_Specter_bw = Msl.AddObject(  // Parenting Object
            name: "o_Specter_bw",
            spriteName: "",
            parentName: "o_Specter",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_allAttack_Attitude = Msl.AddObject(
            name: "o_allAttack_Attitude",
            spriteName: "s_bw_attitude_attack",
            parentName: "o_Attitude",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_allDeffence_Attitude = Msl.AddObject(
            name: "o_allDeffence_Attitude",
            spriteName: "s_bw_attitude_follow",
            parentName: "o_Attitude",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_b_unbind = Msl.AddObject(
            name: "o_b_unbind",
            spriteName: "s_icon_unbind",
            parentName: "o_class_skills",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bwammo = Msl.AddObject(
            name: "o_skill_bwammo",
            spriteName: "sprite1",
            parentName: "o_weapon_skills",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_targeting = Msl.AddObject(
            name: "o_skill_bw_targeting",
            spriteName: "s_torchishka",
            parentName: "o_skills_like",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_b_corpse_dur = Msl.AddObject(
            name: "o_b_corpse_dur",
            spriteName: "",
            parentName: "o_invisible_buff",
            isVisible: false,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_b_ammo_count = Msl.AddObject(
            name: "o_b_ammo_count",
            spriteName: "",
            parentName: "o_invisible_buff",
            isVisible: false,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_b_servemaster = Msl.AddObject(
            name: "o_b_servemaster",
            spriteName: "s_zompie_passiveskill",
            parentName: "o_class_skills",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_resurrection = Msl.AddObject(
            name: "o_skill_bw_resurrection",
            spriteName: "s_recurct",
            parentName: "o_skill",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_resurrection_ico = Msl.AddObject(
            name: "o_skill_bw_resurrection_ico",
            spriteName: "s_recurct",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_resurrection_birth = Msl.AddObject(
            name: "o_bw_resurrection_birth",
            spriteName: "s_makefeast_birth",
            parentName: "o_spellbirth",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_resurrection = Msl.AddObject(
            name: "o_bw_resurrection",
            spriteName: "s_bw_resurrection",
            parentName: "o_magic_pillar",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_dark_bless = Msl.AddObject(
            name: "o_skill_bw_dark_bless",
            spriteName: "s_blusss",
            parentName: "o_skill",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_dark_bless_ico = Msl.AddObject(
            name: "o_skill_bw_dark_bless_ico",
            spriteName: "s_blusss",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_blessing_birth = Msl.AddObject(
            name: "o_bw_blessing_birth",
            spriteName: "s_darkbless_birth",
            parentName: "o_spellbirth",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_darkbless = Msl.AddObject(
            name: "o_bw_darkbless",
            spriteName: "s_darkblessing",
            parentName: "o_magic_pillar",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_b_deathbless = Msl.AddObject(
            name: "o_b_deathbless",
            spriteName: "s_buff_death_blesss",
            parentName: "o_physical_buff",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_pass_skill_shackles_of_darkness = Msl.AddObject(
            name: "o_pass_skill_shackles_of_darkness",
            spriteName: "s_reaping_darkness",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_pass_skill_bw_immortality = Msl.AddObject(
            name: "o_pass_skill_bw_immortality",
            spriteName: "s_imortal_soul",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_b_charged_soul = Msl.AddObject(
            name: "o_b_charged_soul",
            spriteName: "s_charged_z",
            parentName: "o_buff_stage",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_inv_occult_text1 = Msl.AddObject(
            name: "o_inv_occult_text1",
            spriteName: "s_inv_occulistic_texts1",
            parentName: "o_inv_consum_active",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_loot_occult_text1 = Msl.AddObject(
            name: "o_loot_occult_text1",
            spriteName: "s_loot_occulistic_texts1",
            parentName: "o_consument_loot",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_inv_occult_text2 = Msl.AddObject(
            name: "o_inv_occult_text2",
            spriteName: "s_inv_occulistic_texts1",
            parentName: "o_inv_consum_active",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_loot_occult_text2 = Msl.AddObject(
            name: "o_loot_occult_text2",
            spriteName: "s_loot_occulistic_texts1",
            parentName: "o_consument_loot",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_inv_occult_text3 = Msl.AddObject(
            name: "o_inv_occult_text3",
            spriteName: "s_inv_occulistic_texts1",
            parentName: "o_inv_consum_active",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_loot_occult_text3 = Msl.AddObject(
            name: "o_loot_occult_text3",
            spriteName: "s_loot_occulistic_texts1",
            parentName: "o_consument_loot",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_inv_occult_text4 = Msl.AddObject(
            name: "o_inv_occult_text4",
            spriteName: "s_inv_occulistic_texts1",
            parentName: "o_inv_consum_active",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_loot_occult_text4 = Msl.AddObject(
            name: "o_loot_occult_text4",
            spriteName: "s_loot_occulistic_texts1",
            parentName: "o_consument_loot",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_former_physician = Msl.AddObject(
            name: "o_former_physician",
            spriteName: "s_char_select",
            parentName: "o_player",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_perk_order_and_chaos = Msl.AddObject(
            name: "o_perk_order_and_chaos",
            spriteName: "s_skills_passive_power_rune",
            parentName: "o_perks",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_soul_absorption_impact = Msl.AddObject(
            name: "o_soul_absorption_impact",
            spriteName: "",
            parentName: "",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_inv_bwbook = Msl.AddObject(
            name: "o_inv_bwbook",
            spriteName: "s_inv_book",
            parentName: "o_inv_consum_active",
            isVisible: true,
            isPersistent: true,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_inv_bw_journal1 = Msl.AddObject(
            name: "o_inv_bw_journal1",
            spriteName: "s_inv_cg01",
            parentName: "o_inv_bwbook",
            isVisible: true,
            isPersistent: true,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_loot_bw_journal1 = Msl.AddObject(
            name: "o_loot_bw_journal1",
            spriteName: "s_loot_cg",
            parentName: "o_consument_loot",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_open_book = Msl.AddObject(
            name: "o_bw_open_book",
            spriteName: "s_bw_openbook",
            parentName: "o_guiContainer",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_printer = Msl.AddObject(
            name: "o_bw_printer",
            spriteName: "s_bw_border_empty",
            parentName: "",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_chart = Msl.AddObject(
            name: "o_bw_chart",
            spriteName: "s_bw_border_empty",
            parentName: "",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_b_angel_charm = Msl.AddObject(
            name: "o_b_angel_charm",
            spriteName: "s_buff_punish",
            parentName: "o_magical_buff",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            // Temporary Objects   ---------------------------------------------------------

            UndertaleGameObject o_pass_skill_ndarkness = Msl.AddObject(
            name: "o_pass_skill_ndarkness",
            spriteName: "s_exception_soulus",
            parentName: "o_magical_buff",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_db_takeover = Msl.AddObject(
            name: "o_db_takeover",
            spriteName: "s_take_over_effect",
            parentName: "o_mental_debuff",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_db_painful_curse = Msl.AddObject(
            name: "o_db_painful_curse",
            spriteName: "s_exception_soulus",
            parentName: "o_magical_buff",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_b_exceptional = Msl.AddObject(
            name: "o_b_exceptional",
            spriteName: "s_exception_soulus",
            parentName: "o_magical_buff",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_pass_skill_kingdead = Msl.AddObject(
            name: "o_pass_skill_kingdead",
            spriteName: "s_angel_of_death",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            // ============================= Skills pre-requirements =============================

            UndertaleGameObject o_b_newfound_power = Msl.AddObject(
            name: "o_b_newfound_power",
            spriteName: "s_charged_z",
            parentName: "o_mental_buff",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_enemy_birth = Msl.AddObject(
            name: "o_bw_enemy_birth",
            spriteName: "s_church_zombie_anim",
            parentName: "o_spellimpact",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_archtheurgy_impact = Msl.AddObject(
            name: "o_archtheurgy_impact",
            spriteName: "",
            parentName: "",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_essence_leech = Msl.AddObject(
            name: "o_bw_essence_leech",
            spriteName: "s_essence_leech_cast",
            parentName: "o_target_spell",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_leech = Msl.AddObject(
            name: "o_skill_bw_leech",
            spriteName: "s_torchishka",
            parentName: "o_skills_like",
            isVisible: true,
            isPersistent: true,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_aoe_range = Msl.AddObject(
            name: "o_bw_aoe_range",
            spriteName: "s_aoe_area",
            parentName: "",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_lifeleech = Msl.AddObject(
            name: "o_bw_lifeleech",
            spriteName: "",
            parentName: "",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_darkball2 = Msl.AddObject(
            name: "o_darkball2",
            spriteName: "s_teal_ball",
            parentName: "o_shell_damage",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_ballbirth = Msl.AddObject(
            name: "o_bw_ballbirth",
            spriteName: "s_teal_ball_cast",
            parentName: "o_spellbirth",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_cursebirth = Msl.AddObject(
            name: "o_bw_cursebirth",
            spriteName: "s_curse_cast",
            parentName: "o_spellbirth",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_curse = Msl.AddObject(
            name: "o_bw_curse",
            spriteName: "s_teal_curse",
            parentName: "o_magic_pillar",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_curse_bg = Msl.AddObject(
            name: "o_bw_curse_bg",
            spriteName: "s_cursebg",
            parentName: "",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_db_demise_curse = Msl.AddObject(
            name: "o_db_demise_curse",
            spriteName: "s_buff_cursse",
            parentName: "o_magical_debuff",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_wraith_summoning = Msl.AddObject(
            name: "o_bw_wraith_summoning", 
            spriteName: "s_wraithsummon_cast", 
            parentName: "o_spellbirth", 
            isVisible: true, 
            isPersistent: false, 
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_sign_of_darkness_birth = Msl.AddObject(
            name: "o_bw_sign_of_darkness_birth",
            spriteName: "s_bw_signcast",
            parentName: "o_spellbirth",
            isVisible: false,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_sign_of_darkness = Msl.AddObject(
            name: "o_bw_sign_of_darkness",
            spriteName: "s_bw_signmark",
            parentName: "o_mark_spell_damage",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_harbingers_birth = Msl.AddObject(
            name: "o_bw_harbingers_birth",
            spriteName: "s_bw_elder_ritual",
            parentName: "o_spellbirth",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_harbingers_call = Msl.AddObject(
            name: "o_bw_harbingers_call",
            spriteName: "",
            parentName: "o_aoe_spell",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_bw_coord_harbingers = Msl.AddObject(
            name: "o_bw_coord_harbingers",
            spriteName: "",
            parentName: "",
            isVisible: true,
            isPersistent: true,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            // ============================= Skill Tree =============================

            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_array_generator.gml"), "scr_bw_array_generator");

            UndertaleGameObject o_skill_necromancy = Msl.AddObject(
            name: "o_skill_necromancy",
            spriteName: "",
            parentName: "o_skill",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skill_necromancy", "event_inherited()\r\nMiscast_Type = \"Necromantic_Miscast_Chance\"", EventType.Create, 0);
            Msl.AddNewEvent("o_skill_necromancy", "event_inherited()", EventType.Other, 13);

            UndertaleGameObject o_skill_bw_1 = Msl.AddObject( // Darkbolt
            name: "o_skill_bw_1",
            spriteName: "s_darkbalz",
            parentName: "o_skill_necromancy",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_1_ico = Msl.AddObject( // Darkbolt ICO
            name: "o_skill_bw_1_ico",
            spriteName: "s_darkbalz",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_2 = Msl.AddObject( // Soul Reap
            name: "o_skill_bw_2",
            spriteName: "s_soul_abs",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            
            UndertaleGameObject o_skill_bw_3 = Msl.AddObject( // Curse of Demise
            name: "o_skill_bw_3",
            spriteName: "s_pcurse",
            parentName: "o_skill_necromancy",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
           
            UndertaleGameObject o_skill_bw_3_ico = Msl.AddObject( // Curse of Demise ICO
            name: "o_skill_bw_3_ico",
            spriteName: "s_pcurse",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            
            UndertaleGameObject o_skill_bw_4 = Msl.AddObject( // Death's Blessing
            name: "o_skill_bw_4",
            spriteName: "s_blusss",
            parentName: "o_skill_necromancy",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
           
            UndertaleGameObject o_skill_bw_4_ico = Msl.AddObject( // Death's Blessing ICO
            name: "o_skill_bw_4_ico",
            spriteName: "s_blusss",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_5 = Msl.AddObject( // Decay Flesh
            name: "o_skill_bw_5",
            spriteName: "s_growing_madness",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_6 = Msl.AddObject( // Restless Spirit
            name: "o_skill_bw_6",
            spriteName: "s_crazed_by_magic",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_7 = Msl.AddObject( // Resurrection
            name: "o_skill_bw_7",
            spriteName: "s_recurct",
            parentName: "o_skill_necromancy",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_7_ico = Msl.AddObject( // Resurrection ICO
            name: "o_skill_bw_7_ico",
            spriteName: "s_recurct",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_8 = Msl.AddObject( // Absolute Darkness
            name: "o_skill_bw_8",
            spriteName: "s_reaping_darkness",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_9 = Msl.AddObject( // Nightmare Rift
            name: "o_skill_bw_9",
            spriteName: "s_soulzac",
            parentName: "o_skill_necromancy",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_9_ico = Msl.AddObject( // Nightmare Rift
            name: "o_skill_bw_9_ico",
            spriteName: "s_soulzac",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_10 = Msl.AddObject( // Mastery of Binding
            name: "o_skill_bw_10",
            spriteName: "s_dtouch",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_11 = Msl.AddObject( // Immortality
            name: "o_skill_bw_11",
            spriteName: "s_imortal_soul",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_12 = Msl.AddObject( // Harbingers of Death
            name: "o_skill_bw_12",
            spriteName: "s_disasterundead",
            parentName: "o_skill_necromancy",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_12_ico = Msl.AddObject( // Harbingers of Death ICO
            name: "o_skill_bw_12_ico",
            spriteName: "s_disasterundead",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_13 = Msl.AddObject( // Divine Revelation
            name: "o_skill_bw_13",
            spriteName: "s_angel_of_death",
            parentName: "o_skill_passive",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_14 = Msl.AddObject( // Spirit Call
            name: "o_skill_bw_14",
            spriteName: "s_wraithbind",
            parentName: "o_skill_necromancy",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            UndertaleGameObject o_skill_bw_14_ico = Msl.AddObject( // Spirit Call ICO
            name: "o_skill_bw_14_ico",
            spriteName: "s_wraithbind",
            parentName: "o_skill_ico",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );

            Msl.LoadGML("gml_Object_o_textLoader_Other_25")
                .MatchFrom("ds_map_set(global.attribute_decimals, \"Arcanistic_Power\", 1)")
                .InsertBelow("ds_map_set(global.attribute_decimals, \"Necromantic_Power\", 1)")
                .Save();

            Msl.LoadGML("gml_Object_o_textLoader_Other_25")
                .MatchFrom("scr_add_atr_percent(")
                .InsertBelow("scr_add_atr_percent(\"Necromantic_Power\")")
                .Save();

            Msl.LoadGML("gml_Object_o_textLoader_Other_25")
                .MatchFrom("ds_list_add(global.attribute_order_magic_stats,")
                .InsertBelow("ds_list_insert(global.attribute_order_magic_stats, ds_list_find_index(global.attribute_order_magic_stats, \"Arcanistic_Power\") + 1, \"Necromantic_Power\")")
                .Save();

            Msl.LoadGML("gml_GlobalScript_scr_atr_calc")
                .MatchFrom("Arcanistic_Power = scr_buff_param(\"Arcanistic_Power\") + bArcanistic_Power")
                .InsertBelow("Necromantic_Power = scr_buff_param(\"Necromantic_Power\") + bNecromantic_Power")
                .Save();

            Msl.LoadGML("gml_GlobalScript_scr_atr_calc")
                .MatchFrom("Arcanistic_Power = scr_inv_buff_atr(\"Arcanistic_Power\")")
                .InsertBelow("Necromantic_Power = scr_inv_buff_atr(\"Necromantic_Power\")")
                .Save();

            Msl.LoadGML("gml_Object_o_characterBottomContainer_Other_10")
                .MatchFrom("scr_param_list_add(\"Psimantic_Power\", scr_hoversGetAttributeValueString(\"Psimantic_Power\", (o_player.Psimantic_Power + global.magalomania_value), false))")
                .InsertBelow("scr_param_list_add(\"Necromantic_Power\", scr_hoversGetAttributeValueString(\"Necromantic_Power\", (o_player.Necromantic_Power + global.magalomania_value), false))")
                .Save();

            Msl.LoadGML("gml_GlobalScript_scr_atr_calc")
                .MatchFrom("Pyromantic_Miscast_Chance = scr_inv_buff_atr(\"Pyromantic_Miscast_Chance\")")
                .InsertBelow("Necromantic_Miscast_Chance = scr_inv_buff_atr(\"Necromantic_Miscast_Chance\")")
                .Save();

            UndertaleGameObject o_b_necro = Msl.AddObject(
            name: "o_b_necro",
            spriteName: "",
            parentName: "o_invisible_buff",
            isVisible: false,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_b_necro", "event_inherited()\r\ncan_save = false\r\nstage = 1\r\nhave_duration = false", EventType.Create, 0);
            Msl.AddNewEvent("o_b_necro", "event_inherited()\r\nevent_user(5)", EventType.Alarm, 2);
            Msl.AddNewEvent("o_b_necro", "event_inherited()\r\nds_map_replace(data, \"Pyromantic_Miscast_Chance\", (1 * stage))\r\nds_map_replace(data, \"Electromantic_Miscast_Chance\", (1 * stage))\r\nds_map_replace(data, \"Geomantic_Miscast_Chance\", (1 * stage))\r\nds_map_replace(data, \"Venomantic_Miscast_Chance\", (1 * stage))\r\nds_map_replace(data, \"Cryomantic_Miscast_Chance\", (1 * stage))\r\nds_map_replace(data, \"Arcanistic_Miscast_Chance\", (1 * stage))\r\nds_map_replace(data, \"Astromantic_Miscast_Chance\", (1 * stage))\r\nds_map_replace(data, \"Psimantic_Miscast_Chance\", (1 * stage))\r\nds_map_replace(data, \"Chronomantic_Miscast_Chance\", (1 * stage))", EventType.Other, 15);

            Msl.LoadGML("gml_Object_o_b_electro_Other_15").MatchFrom("event_inherited()").InsertBelow("ds_map_replace(data, \"Necromantic_Miscast_Chance\", (1 * stage))").Save();
            Msl.LoadGML("gml_Object_o_b_pyro_Other_15").MatchFrom("event_inherited()").InsertBelow("ds_map_replace(data, \"Necromantic_Miscast_Chance\", (1 * stage))").Save();
            Msl.LoadGML("gml_Object_o_b_geo_Other_15").MatchFrom("event_inherited()").InsertBelow("ds_map_replace(data, \"Necromantic_Miscast_Chance\", (1 * stage))").Save();
            Msl.LoadGML("gml_Object_o_b_arcanistics_Other_15").MatchFrom("event_inherited()").InsertBelow("ds_map_replace(data, \"Necromantic_Miscast_Chance\", (1 * stage))").Save();

            UndertaleGameObject o_skill_category_necromancy = Msl.AddObject( //================================= Branch
            name: "o_skill_category_necromancy",
            spriteName: "",
            parentName: "o_sklill_category_magic",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skill_category_necromancy", "event_inherited()\r\ntext = \"Necromancy\"\r\nskill = [o_skill_bw_1_ico, o_skill_bw_2, o_skill_bw_3_ico, o_skill_bw_4_ico, o_skill_bw_5, o_skill_bw_6, o_skill_bw_7_ico, o_skill_bw_8, o_skill_bw_9_ico, o_skill_bw_10, o_skill_bw_11, o_skill_bw_12_ico, o_skill_bw_13, o_skill_bw_14_ico]\r\nbranch_sprite = s_necromancy_branch\r\ndarkbolt = -4\r\nessence_flux = -4\r\ndemise_curse = -4\r\ndeath_blessing = -4\r\nblooming = -4\r\nresurrection = -4\r\nshackles_darkness = -4\r\nmonolith = -4\r\nbinding_mastery = -4\r\nimmortality = -4\r\ntriple_hand = -4\r\narchtheurgy = -4\r\nspirit_call = -4\r\nline1 = -4\r\nline2 = -4\r\nline3 = -4\r\nline4 = -4\r\nline5 = -4\r\nline6 = -4\r\nline7 = -4\r\nline8 = -4\r\nline9 = -4\r\nline10 = -4\r\nline11 = -4\r\nline12 = -4\r\nline13 = -4\r\nline14 = -4", EventType.Create, 0);
            Msl.AddNewEvent("o_skill_category_necromancy", "event_inherited()\r\nif (!instance_exists(o_b_necro))\r\n    scr_effect_create(o_b_necro, o_confirm_panel)\r\nelse\r\n{\r\n    with (o_b_necro)\r\n    {\r\n        stage++\r\n        event_user(5)\r\n    }\r\n}\r\nBonus_Damage += 0.035\r\nfor (var i = 0; i < array_length(skill); i++)\r\n{\r\n    if (!is_string(skill[i]))\r\n    {\r\n        with (skill[i])\r\n        {\r\n            if (!(object_is_ancestor(object_index, o_skill_passive)))\r\n            {\r\n                event_user(7)\r\n                with (child_skill)\r\n                    event_user(7)\r\n            }\r\n        }\r\n    }\r\n}", EventType.Other, 10);
            Msl.AddNewEvent("o_skill_category_necromancy", "", EventType.Other, 24);
            Msl.LoadAssemblyAsString("gml_Object_o_skill_category_necromancy_Other_24").MatchAll().ReplaceBy(".localvar 2 arguments\r\n\r\n:[0]\r\ncall.i event_inherited(argc=0)\r\npopz.v\r\npushi.e 55\r\nconv.i.v\r\npushi.e 33\r\nconv.i.v\r\npushi.e o_skill_bw_1_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.darkbolt\r\npushi.e 55\r\nconv.i.v\r\npushi.e 81\r\nconv.i.v\r\npushi.e o_skill_bw_2\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.essence_flux\r\npushi.e 55\r\nconv.i.v\r\npushi.e 130\r\nconv.i.v\r\npushi.e o_skill_bw_3_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.demise_curse\r\npushi.e 118\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e o_skill_bw_4_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.death_blessing\r\npushi.e 118\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e o_skill_bw_5\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.sealed_mind\r\npushi.e 118\r\nconv.i.v\r\npushi.e 100\r\nconv.i.v\r\npushi.e o_skill_bw_6\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.blooming\r\npushi.e 118\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e o_skill_bw_7_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.resurrection\r\npushi.e 171\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e o_skill_bw_8\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.shackles_darkness\r\npushi.e 171\r\nconv.i.v\r\npushi.e 81\r\nconv.i.v\r\npushi.e o_skill_bw_9_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.monolith\r\npushi.e 171\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e o_skill_bw_10\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.binding_mastery\r\npushi.e 221\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e o_skill_bw_11\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.immortality\r\npushi.e 221\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e o_skill_bw_12_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.triple_hand\r\npushi.e 221\r\nconv.i.v\r\npushi.e 100\r\nconv.i.v\r\npushi.e o_skill_bw_13\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.archtheurgy\r\npushi.e 221\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e o_skill_bw_14_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.spirit_call\r\npushi.e 70\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line1\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line1\r\npushi.e 70\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line2\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line2\r\npushi.e 70\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line3\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line3\r\npushi.e 70\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_lineconnect\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.linebase\r\npushi.e 133\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e s_bw_skill_line4\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line4\r\npushi.e 186\r\nconv.i.v\r\npushi.e 103\r\nconv.i.v\r\npushi.e s_bw_skill_line5\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line5\r\npushi.e 133\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line4\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line6\r\npushi.e 186\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line55\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line7\r\npushi.e 133\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e s_bw_skill_line7\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line8\r\npushi.e 133\r\nconv.i.v\r\npushi.e 84\r\nconv.i.v\r\npushi.e s_bw_skill_line8\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line9\r\npushi.e 1\r\nconv.b.v\r\npushi.e 152\r\nconv.i.v\r\npushi.e 81\r\nconv.i.v\r\npushi.e s_bw_skill_line9\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=6)\r\npop.v.v self.line10\r\npushi.e 186\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e s_bw_skill_line6\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line13\r\npushi.e 1\r\nconv.b.v\r\npushi.e 201\r\nconv.i.v\r\npushi.e 100\r\nconv.i.v\r\npushi.e s_bw_skill_line12\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=6)\r\npop.v.v self.line12\r\npushi.e 1\r\nconv.b.v\r\npushi.e 201\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e s_bw_skill_line12\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=6)\r\npop.v.v self.line14\r\npush.v self.death_blessing\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.death_blessing\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.sealed_mind\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.sealed_mind\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.blooming\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.blooming\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.resurrection\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.resurrection\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.binding_mastery\r\npush.v self.resurrection\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.binding_mastery\r\npush.v self.line4\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.spirit_call\r\npush.v self.binding_mastery\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.spirit_call\r\npush.v self.line5\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.shackles_darkness\r\npush.v self.death_blessing\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.shackles_darkness\r\npush.v self.line6\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.immortality\r\npush.v self.shackles_darkness\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.immortality\r\npush.v self.line7\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.monolith\r\npush.v self.sealed_mind\r\npush.v self.blooming\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.monolith\r\npush.v self.line10\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.triple_hand\r\npush.v self.shackles_darkness\r\npush.v self.monolith\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.triple_hand\r\npush.v self.line14\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.archtheurgy\r\npush.v self.binding_mastery\r\npush.v self.monolith\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.archtheurgy\r\npush.v self.line12\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line1\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line1\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line2\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line2\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line3\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line3\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.linebase\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.linebase\r\npush.v self.line3\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.line2\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.line1\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 3\r\npopz.v\r\npush.v self.line4\r\npush.v self.resurrection\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line5\r\npush.v self.binding_mastery\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line6\r\npush.v self.death_blessing\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line7\r\npush.v self.shackles_darkness\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line8\r\npush.v self.sealed_mind\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line9\r\npush.v self.blooming\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line13\r\npush.v self.monolith\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line10\r\npush.v self.sealed_mind\r\npush.v self.blooming\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line10\r\npush.v self.line8\r\npush.v self.line9\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line12\r\npush.v self.binding_mastery\r\npush.v self.monolith\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line12\r\npush.v self.line13\r\npush.v self.line5\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line14\r\npush.v self.shackles_darkness\r\npush.v self.monolith\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line14\r\npush.v self.line13\r\npush.v self.line7\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\n\r\n:[end]").Save();
            //Msl.LoadAssemblyAsString("gml_Object_o_skill_category_necromancy_Other_24").MatchAll().ReplaceBy(".localvar 2 arguments\r\n\r\n:[0]\r\ncall.i event_inherited(argc=0)\r\npopz.v\r\npushi.e 55\r\nconv.i.v\r\npushi.e 33\r\nconv.i.v\r\npushi.e o_skill_bw_1_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.darkbolt\r\npushi.e 55\r\nconv.i.v\r\npushi.e 81\r\nconv.i.v\r\npushi.e o_skill_bw_2\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.essence_flux\r\npushi.e 55\r\nconv.i.v\r\npushi.e 130\r\nconv.i.v\r\npushi.e o_skill_bw_3\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.demise_curse\r\npushi.e 118\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e o_skill_bw_4\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.death_blessing\r\npushi.e 118\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e o_skill_bw_5\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.sealed_mind\r\npushi.e 118\r\nconv.i.v\r\npushi.e 100\r\nconv.i.v\r\npushi.e o_skill_bw_6\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.blooming\r\npushi.e 118\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e o_skill_bw_7\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.resurrection\r\npushi.e 171\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e o_skill_bw_8\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.shackles_darkness\r\npushi.e 171\r\nconv.i.v\r\npushi.e 81\r\nconv.i.v\r\npushi.e o_skill_bw_9\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.monolith\r\npushi.e 171\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e o_skill_bw_10\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.binding_mastery\r\npushi.e 221\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e o_skill_bw_11\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.immortality\r\npushi.e 221\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e o_skill_bw_12\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.triple_hand\r\npushi.e 221\r\nconv.i.v\r\npushi.e 100\r\nconv.i.v\r\npushi.e o_skill_bw_13\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.archtheurgy\r\npushi.e 221\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e o_skill_bw_14_ico\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillPoint\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.spirit_call\r\npushi.e 70\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line1\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line1\r\npushi.e 70\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line2\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line2\r\npushi.e 70\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line3\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line3\r\npushi.e 70\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_lineconnect\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.linebase\r\npushi.e 133\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e s_bw_skill_line4\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line4\r\npushi.e 186\r\nconv.i.v\r\npushi.e 138\r\nconv.i.v\r\npushi.e s_bw_skill_line5\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line5\r\npushi.e 133\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line4\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line6\r\npushi.e 186\r\nconv.i.v\r\npushi.e 24\r\nconv.i.v\r\npushi.e s_bw_skill_line5\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line7\r\npushi.e 133\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e s_bw_skill_line7\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line8\r\npushi.e 133\r\nconv.i.v\r\npushi.e 84\r\nconv.i.v\r\npushi.e s_bw_skill_line8\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line9\r\npushi.e 1\r\nconv.b.v\r\npushi.e 152\r\nconv.i.v\r\npushi.e 81\r\nconv.i.v\r\npushi.e s_bw_skill_line9\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=6)\r\npop.v.v self.line10\r\npushi.e 187\r\nconv.i.v\r\npushi.e 62\r\nconv.i.v\r\npushi.e s_bw_skill_line6\r\nconv.i.v\r\npush.v self.connectionsRender\r\npush.i gml_Script_ctr_SkillLine\r\nconv.i.v\r\ncall.i @@NewGMLObject@@(argc=5)\r\npop.v.v self.line11\r\npush.v self.death_blessing\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.death_blessing\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.sealed_mind\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.sealed_mind\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.blooming\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.blooming\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.resurrection\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.resurrection\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.binding_mastery\r\npush.v self.resurrection\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.binding_mastery\r\npush.v self.line4\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.spirit_call\r\npush.v self.binding_mastery\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.spirit_call\r\npush.v self.line5\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.shackles_darkness\r\npush.v self.death_blessing\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.shackles_darkness\r\npush.v self.line6\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.immortality\r\npush.v self.shackles_darkness\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.immortality\r\npush.v self.line7\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.monolith\r\npush.v self.sealed_mind\r\npush.v self.blooming\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.monolith\r\npush.v self.line10\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.triple_hand\r\npush.v self.monolith\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.triple_hand\r\npush.v self.line11\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.archtheurgy\r\npush.v self.monolith\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.archtheurgy\r\npush.v self.line11\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line1\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line1\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line2\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line2\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line3\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line3\r\npush.v self.linebase\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.linebase\r\npush.v self.demise_curse\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.essence_flux\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.darkbolt\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 3\r\npopz.v\r\npush.v self.linebase\r\npush.v self.line3\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.line2\r\ncall.i @@NewGMLArray@@(argc=1)\r\npush.v self.line1\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 3 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 3\r\npopz.v\r\npush.v self.line4\r\npush.v self.resurrection\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line5\r\npush.v self.binding_mastery\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line6\r\npush.v self.death_blessing\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line7\r\npush.v self.shackles_darkness\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line8\r\npush.v self.sealed_mind\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line9\r\npush.v self.blooming\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line10\r\npush.v self.sealed_mind\r\npush.v self.blooming\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\npush.v self.line10\r\npush.v self.line8\r\npush.v self.line9\r\ncall.i @@NewGMLArray@@(argc=2)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedLines\r\ncallv.v 1\r\npopz.v\r\npush.v self.line11\r\npush.v self.monolith\r\ncall.i @@NewGMLArray@@(argc=1)\r\ndup.v 1 8 ;;; this is a weird GMS2.3+ swap instruction\r\ndup.v 0\r\npush.v stacktop.addConnectedPoints\r\ncallv.v 1\r\npopz.v\r\n\r\n:[end]").Save();

            Msl.LoadGML("gml_Object_o_skill_seal_of_power_Other_17")
                .MatchFrom("ds_map_replace(data, \"Arcane_DMG\", (owner.WIL * 0.2))")
                .InsertBelow("ds_map_replace(data, \"Unholy_DMG\", (owner.WIL * 0.2))")
                .Save();

            // Undead Bandits ============================

            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_param.gml"), "scr_bw_param"); // New Script

            UndertaleGameObject o_bw_brigand = Msl.AddObject(  // Parenting Object
            name: "o_bw_brigand",
            spriteName: "",
            parentName: "o_Bandit",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bw_brigand", "event_inherited()\r\nalert_snd = choose(snd_undead_zombie_alert_1, snd_undead_zombie_alert_2, snd_undead_zombie_alert_3, snd_undead_zombie_alert_4)\r\ndeath_sound = choose(snd_undead_zombie_death_1, snd_undead_zombie_death_2, snd_undead_zombie_death_3)\r\nemo_death_sound = -4\r\nds_list_clear(emo_sound)\r\nisLootDropped = false\r\nds_list_add(emo_sound, snd_undead_zombie_emotion_1, snd_undead_zombie_emotion_2, snd_undead_zombie_emotion_3, snd_undead_zombie_emotion_4)\r\nrevivify_dur = 0\r\nalarm[4] = 1\r\nowner = o_player", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_brigand", "event_inherited()\r\ncorpse_durability = min(100, max(0, corpse_durability))", EventType.Step, 2);
            Msl.AddNewEvent("o_bw_brigand", "if ((!global.attack_mode_on) && (!keyboard_check(vk_shift)))\r\n{\r\n    with (id)\r\n        scr_voice_text(choose(\"Get... lost\", \"Free... me\", \"Let me die...\", \"Don't ... get close...\"), -4, 16777215, 0, -39, 0)\r\n    scr_actionsLog(\"speech\", [scr_id_get_name(id), scr_actionsLogSpeechFormat(choose(\"Get... lost\", \"Free... me\", \"Let me die...\", \"Don't ... get close...\"))])\r\n}\r\nelse\r\n    event_inherited()", EventType.Mouse, 4);
            Msl.AddNewEvent("o_bw_brigand", "if (!(scr_instance_exists_in_list(o_b_servemaster, buffs)))\r\n{\r\n    with (self)\r\n        scr_effect_create(o_b_servemaster, revivify_dur, id, id)\r\n}\r\nif scr_instance_exists_in_list(o_b_corpse_dur, buffs)\r\n{\r\n    with (o_b_corpse_dur)\r\n    {\r\n        if (target == other.id)\r\n            other.corpse_durability = duration\r\n    }\r\n}\r\nelse\r\n    scr_effect_create(o_b_corpse_dur, o_damage_dealer, id, id)", EventType.Alarm, 4);

            // T1 Bandits

            UndertaleGameObject o_bandit_goon_club_z = Msl.AddObject(  // Goon Club (T1 Bandit)
            name: "o_bandit_goon_club_z",
            spriteName: "s_bandit_goon_club_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_goon_club_z", "event_inherited()\r\nscr_bw_param(\"Brigand Goon Flail\")\r\ncorpse_sprite = s_bandit_goon_club01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_goon_cleaver_z = Msl.AddObject(  // Goon Cleaver (T1 Bandit)
            name: "o_bandit_goon_cleaver_z",
            spriteName: "s_bandit_goon_cleaver_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_goon_cleaver_z", "event_inherited()\r\nscr_bw_param(\"Brigand Goon Cleaver\")\r\ncorpse_sprite = s_bandit_goon_cleaver01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_goon_flail_z = Msl.AddObject(  //  Goon Flail (T1 Bandit)
            name: "o_bandit_goon_flail_z",
            spriteName: "s_bandit_goon_flail_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_goon_flail_z", "event_inherited()\r\nscr_bw_param(\"Brigand Goon Flail\")\r\ncorpse_sprite = s_bandit_thug_club01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_rioter_z = Msl.AddObject(  //  Rebel/Rioter (T1 Bandit)
            name: "o_bandit_rioter_z",
            spriteName: "s_bandit_rioter_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_rioter_z", "event_inherited()\r\nscr_bw_param(\"Brigand Rioter\")\r\ncorpse_sprite = s_bandit_rioter01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_enforcer_2hmace_z = Msl.AddObject(  //  Enforcer 2h Mace (T1 Bandit)
            name: "o_bandit_enforcer_2hmace_z",
            spriteName: "s_bandit_enforcer_2hmace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_enforcer_2hmace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Enforcer 2HMace\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Power_Kick\")\r\ncorpse_sprite = s_bandit_trasher01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_enforcer_2haxe_z = Msl.AddObject(  //  Enforcer 2h Axe (T1 Bandit)
            name: "o_bandit_enforcer_2haxe_z",
            spriteName: "s_bandit_enforcer_2haxe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_enforcer_2haxe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Enforcer 2HAxe\")\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Power_Kick\")\r\ncorpse_sprite = s_bandit_trasher03_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_enforcer_2hsword_z = Msl.AddObject(  //  Enforcer 2h Sword (T1 Bandit)
            name: "o_bandit_enforcer_2hsword_z",
            spriteName: "s_bandit_enforcer_2hsword_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_enforcer_2hsword_z", "event_inherited()\r\nscr_bw_param(\"Brigand Enforcer 2HSword\")\r\nscr_create_skill_map(\"Feint_Swing\")\r\nscr_create_skill_map(\"Power_Kick\")\r\ncorpse_sprite = s_bandit_trasher02_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_poacher_z = Msl.AddObject(  //  Poacher (T1 Bandit) (Ranged)
            name: "o_bandit_poacher_z",
            spriteName: "s_bandit_poacher01_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_poacher_z", "event_inherited()\r\nscr_bw_param(\"Brigand Poacher\")\r\nscr_create_skill_map(\"Taking_Aim\")\r\nis_shoot = 1\r\nreload = 1\r\nammoCount = 0\r\ncorpse_sprite = s_bandit_poacher01_corpse", EventType.Create, 0);
            Msl.AddNewEvent("o_bandit_poacher_z", "event_inherited()\r\nif scr_instance_exists_in_list(o_b_ammo_count, buffs)\r\n{\r\nwith (o_b_ammo_count)\r\n{\r\nif (target == other.id)\r\nother.ammoCount = duration\r\n}\r\n}\r\nelse\r\nscr_effect_create(o_b_ammo_count, 0, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_bandit_kingpin_z = Msl.AddObject(  //  Brute (T1 Bandit) (Boss)
            name: "o_bandit_kingpin_z",
            spriteName: "s_bandit_kingpin_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_kingpin_z", "event_inherited()\r\nscr_bw_param(\"Brigand Kingpin\")\r\nnetSize = \"high\"\r\ncritDeathAnimationFraction = \"\"\r\nshadow_spr_shift = [2, 0]\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Power_Kick\")\r\ncorpse_sprite = s_bandit_kingpin_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_madman_z = Msl.AddObject(  //  Madman (T1 Bandit) (Boss)
            name: "o_bandit_madman_z",
            spriteName: "s_bandit_madman_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_madman_z", "event_inherited()\r\nscr_bw_param(\"Brigand Madman\")\r\nscr_create_skill_map(\"Double_Jab\")\r\nscr_create_skill_map(\"Sudden_Strike\")\r\ncorpse_sprite = s_bandit_freak_corpse", EventType.Create, 0);

            // T2 Bandits

            UndertaleGameObject o_bandit_thug_spear_z = Msl.AddObject(  //  Thug Spear (T2 Bandit)
            name: "o_bandit_thug_spear_z",
            spriteName: "s_bandit_thug_spear_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_thug_spear_z", "event_inherited()\r\nscr_bw_param(\"Brigand Thug Spear\")\r\nscr_create_skill_map(\"Piercing_Lunge\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_renegade02_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_thug_2haxe_z = Msl.AddObject(  //  Thug Axe (T2 Bandit)
            name: "o_bandit_thug_2haxe_z",
            spriteName: "s_bandit_thug_2haxe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_thug_2haxe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Thug 2HAxe\")\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Reign_in_Blood\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_renegade05_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_thug_2hsword_z = Msl.AddObject(  //  Thug 2h Sword (T2 Bandit)
            name: "o_bandit_thug_2hsword_z",
            spriteName: "s_bandit_thug_2hsword_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_thug_2hsword_z", "event_inherited()\r\nscr_bw_param(\"Brigand Thug 2HSword\")\r\nscr_create_skill_map(\"Feint_Swing\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_renegade04_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_thug_2hflail_z = Msl.AddObject(  //  Thug 2h Flail (T2 Bandit)
            name: "o_bandit_thug_2hflail_z",
            spriteName: "s_bandit_thug_2hflail_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_thug_2hflail_z", "event_inherited()\r\nscr_bw_param(\"Brigand Thug 2HFlail\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\ncorpse_sprite = s_bandit_renegade07_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_thug_2hmace_z = Msl.AddObject(  //  Thug 2h Mace (T2 Bandit)
            name: "o_bandit_thug_2hmace_z",
            spriteName: "s_bandit_renegade_mace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_thug_2hmace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Thug 2HFlail\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\ncorpse_sprite = s_bandit_renegade06_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_mancatcher_z = Msl.AddObject(  //  Mancatcher (T2 Bandit)
            name: "o_bandit_mancatcher_z",
            spriteName: "s_bandit_mancatcher_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_mancatcher_z", "event_inherited()\r\nscr_bw_param(\"Brigand Mancatcher\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_mancatcher01_corpse\r\n", EventType.Create, 0);

            UndertaleGameObject o_bandit_henchman_axe_z = Msl.AddObject(  // Henchman Axe (T2 Bandit)
            name: "o_bandit_henchman_axe_z",
            spriteName: "s_bandit_henchman_axe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_henchman_axe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Henchman Axe\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_henchman_axe01_corpse\r\n", EventType.Create, 0);

            UndertaleGameObject o_bandit_henchman_flail_z = Msl.AddObject(  // Henchman Flail (T2 Bandit)
            name: "o_bandit_henchman_flail_z",
            spriteName: "s_bandit_sidekick_flail01_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_henchman_flail_z", "event_inherited()\r\nscr_bw_param(\"Brigand Henchman Flail\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_passive(o_pass_skill_moment_of_weakness)\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_sidekick_flail01_corpse\r\n", EventType.Create, 0);

            UndertaleGameObject o_bandit_henchman_mace_z = Msl.AddObject(  // Henchman Mace (T2 Bandit)
            name: "o_bandit_henchman_mace_z",
            spriteName: "s_bandit_sidekick_mace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_henchman_mace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Henchman Mace\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_sidekick_mace01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_crook_z = Msl.AddObject(  // Crook (T2 Bandit)
            name: "o_bandit_crook_z",
            spriteName: "s_bandit_crook_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_crook_z", "event_inherited()\r\nscr_bw_param(\"Brigand Crook\")\r\nscr_create_skill_map(\"Double_Jab\")\r\nscr_create_skill_map(\"Deadly_Trick\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_crook01_corpse\r\n", EventType.Create, 0);

            UndertaleGameObject o_bandit_outlaw_z = Msl.AddObject(  // Outlaw (T2 Bandit)
            name: "o_bandit_outlaw_z",
            spriteName: "s_bandit_outlaw_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_outlaw_z", "event_inherited()\r\nscr_bw_param(\"Brigand Outlaw\")\r\nammoCount = 0\r\nis_shoot = true\r\nreload = false\r\nscr_create_skill_map(\"Taking_Aim\")\r\nscr_create_skill_map(\"Long_Range_Shot\")\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\nscr_create_skill_passive(o_pass_skill_constant_training)\r\ncorpse_sprite = s_bandit_outlaw02_corpse\r\n", EventType.Create, 0);
            Msl.AddNewEvent("o_bandit_outlaw_z", "event_inherited()\r\nif scr_instance_exists_in_list(o_b_ammo_count, buffs)\r\n{\r\nwith (o_b_ammo_count)\r\n{\r\nif (target == other.id)\r\nother.ammoCount = duration\r\n}\r\n}\r\nelse\r\nscr_effect_create(o_b_ammo_count, 0, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_bandit_rabblerouser_z = Msl.AddObject(  // Rabble Rouser (T2 Bandit) (Boss)
            name: "o_bandit_rabblerouser_z",
            spriteName: "s_bandit_rabblerouser_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_rabblerouser_z", "event_inherited()\r\nscr_bw_param(\"Brigand Rabble Rouser\")\r\nscr_create_skill_map(\"Hail_of_Blows\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_pass_skill_hard_target)\r\nscr_create_skill_map(\"Instigate\")\r\ncorpse_sprite = s_bandit_rabblerouser_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_firestarter_z = Msl.AddObject(  // Fire Starter (T2 Bandit) (Boss)
            name: "o_bandit_firestarter_z",
            spriteName: "s_bandit_firestarter_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_firestarter_z", "event_inherited()\r\nscr_bw_param(\"Brigand Firestarter\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nscr_create_skill_passive(o_pass_skill_intimidation)\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\ncorpse_sprite = s_bandit_firestarter_corpse", EventType.Create, 0);

            // T3 Bandits

            UndertaleGameObject o_bandit_marauder_2hmace_z = Msl.AddObject(  // Bandit Marauder 2h Mace (T3 Bandit)
            name: "o_bandit_marauder_2hmace_z",
            spriteName: "s_bandit_marauder_2hmace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_marauder_2hmace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Marauder 2HMace\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\ncorpse_sprite = s_bandit_marauder04_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_marauder_2haxe_z = Msl.AddObject(  // Bandit Marauder 2h Axe (T3 Bandit)
            name: "o_bandit_marauder_2haxe_z",
            spriteName: "s_bandit_marauder_2haxe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_marauder_2haxe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Marauder 2HAxe\")\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Reign_in_Blood\")\r\nscr_create_skill_passive(o_pass_skill_shieldbreaker)\r\ncorpse_sprite = s_bandit_marauder02_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_marauder_2hsword_z = Msl.AddObject(  // Bandit Marauder 2h Sword (T3 Bandit)
            name: "o_bandit_marauder_2hsword_z",
            spriteName: "s_bandit_marauder_2hsword_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_marauder_2hsword_z", "event_inherited()\r\nscr_bw_param(\"Brigand Marauder 2HSword\")\r\nscr_create_skill_map(\"Feint_Swing\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_map(\"Heroic_Charge\")\r\nscr_create_skill_passive(o_pass_skill_fight_to_death)\r\ncorpse_sprite = s_bandit_marauder01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_marauder_2hflail_z = Msl.AddObject(  // Bandit Marauder 2h Flail (T3 Bandit)
            name: "o_bandit_marauder_2hflail_z",
            spriteName: "s_bandit_marauder_2hflail_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_marauder_2hflail_z", "event_inherited()\r\nscr_bw_param(\"Brigand Marauder 2HFlail\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\ncorpse_sprite = s_bandit_marauder03_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_marauder_halberd_z = Msl.AddObject(  // Bandit Marauder halberd (T3 Bandit)
            name: "o_bandit_marauder_halberd_z",
            spriteName: "s_bandit_marauder_halberd_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_marauder_halberd_z", "event_inherited()\r\nscr_bw_param(\"Brigand Marauder Halberd\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Regroup\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_passive(o_pass_skill_no_retreat)\r\ncorpse_sprite = s_bandit_marauder05_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_marauder_spear_z = Msl.AddObject(  // Bandit Marauder spear (T3 Bandit)
            name: "o_bandit_marauder_spear_z",
            spriteName: "s_bandit_marauder_spear_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_marauder_spear_z", "event_inherited()\r\nscr_bw_param(\"Brigand Marauder Spear\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Piercing_Lunge\")\r\nscr_create_skill_map(\"Regroup\")\r\nscr_create_skill_passive(o_pass_skill_precise_hits)\r\ncorpse_sprite = s_bandit_marauder06_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_cutthroat_z = Msl.AddObject(  // Bandit Cutthroat (T3 Bandit) 
            name: "o_bandit_cutthroat_z",
            spriteName: "s_bandit_cutthroat_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_cutthroat_z", "event_inherited()\r\nscr_bw_param(\"Brigand Cutthroat\")\r\nscr_create_skill_map(\"Double_Jab\")\r\nscr_create_skill_map(\"Deadly_Trick\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\ncorpse_sprite = s_bandit_cutthroat01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_turncoat_sword_z = Msl.AddObject(  // Bandit Turncoat Sword (T3 Bandit) 
            name: "o_bandit_turncoat_sword_z",
            spriteName: "s_bandit_turncoat_sword_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_turncoat_sword_z", "event_inherited()\r\nscr_bw_param(\"Brigand Turncoat Sword\")\r\nscr_create_skill_map(\"Cleave\")\r\nscr_create_skill_map(\"Fencer_Stance\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_passive(o_pass_skill_gloat)\r\ncorpse_sprite = s_bandit_sergeant_sword01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_turncoat_axe_z = Msl.AddObject(  // Bandit Turncoat Axe (T3 Bandit) 
            name: "o_bandit_turncoat_axe_z",
            spriteName: "s_bandit_turncoat_axe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_turncoat_axe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Turncoat Axe\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nscr_create_skill_map(\"Crippling_Lunge\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_passive(o_pass_skill_reprisal)\r\ncorpse_sprite = s_bandit_sergeant_sword01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_turncoat_mace_z = Msl.AddObject(  // Bandit Turncoat Mace (T3 Bandit) 
            name: "o_bandit_turncoat_mace_z",
            spriteName: "s_bandit_turncoat_mace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_turncoat_mace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Turncoat Mace\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_passive(o_pass_skill_dazing_strikes)\r\ncorpse_sprite = s_bandit_sergeant_blunt01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_turncoat_flail_z = Msl.AddObject(  // Bandit Turncoat Flail (T3 Bandit) 
            name: "o_bandit_turncoat_flail_z",
            spriteName: "s_bandit_turncoat_flail_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_turncoat_flail_z", "event_inherited()\r\nscr_bw_param(\"Brigand Turncoat Flail\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_passive(o_pass_skill_moment_of_weakness)\r\ncorpse_sprite = s_bandit_sergeant_flail01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_hired_sorcerer_pyro_z = Msl.AddObject(  // Bandit Hired Sorcerer Pyro (T3 Bandit) 
            name: "o_bandit_hired_sorcerer_pyro_z",
            spriteName: "s_bandit_rogue_mage_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_hired_sorcerer_pyro_z", "event_inherited()\r\nscr_bw_param(\"Hired Sorcerer Pyro\")\r\nscr_create_skill_map(\"Fire_Barrage\")\r\nscr_create_skill_map(\"Flame_Wave\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_flame_saturation)\r\nscr_create_skill_passive(o_pass_skill_scorch)\r\ncorpse_sprite = s_bandit_roguemage01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_hired_sorcerer_electro_z = Msl.AddObject(  // Bandit Hired Sorcerer Electro (T3 Bandit) 
            name: "o_bandit_hired_sorcerer_electro_z",
            spriteName: "s_bandit_hired_sorcerer_electro_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_hired_sorcerer_electro_z", "event_inherited()\r\nscr_bw_param(\"Hired Sorcerer Electro\")\r\nscr_create_skill_map(\"Discharge\")\r\nscr_create_skill_map(\"Short_Circuit\")\r\nscr_create_skill_map(\"Impulse\")\r\nscr_create_skill_passive(o_pass_skill_residual_charge)\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\ncorpse_sprite = s_bandit_roguemage02_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_drummer_z = Msl.AddObject(  // Bandit Drummer (T3 Bandit) 
            name: "o_bandit_drummer_z",
            spriteName: "s_bandit_drummer_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_drummer_z", "event_inherited()\r\nscr_bw_param(\"Brigand Drummer\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Active_Defence\")\r\nscr_create_skill_map(\"Instigate\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_pass_skill_hard_target)\r\ncorpse_sprite = s_bandit_drummer_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_ambusher_z = Msl.AddObject( // Bandit Ambusher (T3 Bandit)
            name: "o_bandit_ambusher_z",
            spriteName: "s_bandit_arbalester_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_ambusher_z", "event_inherited()\r\nscr_bw_param(\"Brigand Ambusher\")\r\nammoCount = 0\r\nis_shoot = true\r\nreload = true\r\ncrossbowIsLoaded = false\r\nisCrossbowmanEnemy = true\r\narrowTypeSprite = s_leafshapedbolt_shoot\r\narrowTypeUsed = o_leafshaped_bolt_used\r\nscr_create_skill_map(\"Taking_Aim\")\r\nscr_create_skill_map(\"Suppression\")\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\nscr_create_skill_passive(o_pass_skill_constant_training)\r\nscr_create_skill_passive(o_pass_skill_hard_target)\r\nscr_create_skill_passive(o_pass_skill_weak_spots)\r\ncorpse_sprite = s_bandit_arbalester01_corpse", EventType.Create, 0);
            Msl.AddNewEvent("o_bandit_ambusher_z", "event_inherited()\r\nif scr_instance_exists_in_list(o_b_ammo_count, buffs)\r\n{\r\nwith (o_b_ammo_count)\r\n{\r\nif (target == other.id)\r\nother.ammoCount = duration\r\n}\r\n}\r\nelse\r\nscr_effect_create(o_b_ammo_count, 0, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_bandit_bonebreaker_axe_z = Msl.AddObject(  // Bandit Bonebreaker Axe (T3 Bandit) (Boss)
            name: "o_bandit_bonebreaker_axe_z",
            spriteName: "s_bandit_bonebreaker_axe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_bonebreaker_axe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Bonebreaker 2HAxe\")\r\ncritDeathAnimationFraction = \"\"\r\nnetSize = \"high\"\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Reign_in_Blood\")\r\nscr_create_skill_map(\"Rampage\")\r\nscr_create_skill_passive(o_pass_skill_finish_him)\r\nscr_create_skill_passive(o_pass_skill_shieldbreaker)\r\nscr_create_skill_passive(o_pass_skill_never_again)\r\ncorpse_sprite = s_bandit_bonebreaker_01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_bonebreaker_mace_z = Msl.AddObject(  // Bandit Bonebreaker Mace (T3 Bandit) (Boss)
            name: "o_bandit_bonebreaker_mace_z",
            spriteName: "s_bandit_bonebreaker_mace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_bonebreaker_mace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Bonebreaker 2HMace\")\r\ncritDeathAnimationFraction = \"\"\r\nnetSize = \"high\"\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_map(\"Mayhem\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\nscr_create_skill_passive(o_pass_skill_heavy_concussion)\r\nscr_create_skill_passive(o_pass_skill_never_again)\r\ncorpse_sprite = s_bandit_bonebreaker_02_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_warlock_z = Msl.AddObject(  // Bandit Warlock (T3 Bandit) (Boss)
            name: "o_bandit_warlock_z",
            spriteName: "s_bandit_warlock_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_warlock_z", "event_inherited()\r\nscr_bw_param(\"Brigand Warlock\")\r\nscr_create_skill_map(\"Hail_of_Blows\")\r\nscr_create_skill_map(\"Fire_Barrage\")\r\nscr_create_skill_map(\"Discharge\")\r\nscr_create_skill_map(\"Seal_of_Power\")\r\nscr_create_skill_map(\"Chain_Lightning\")\r\nscr_create_skill_map(\"Magma_Rain\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_now_or_never)\r\ncorpse_sprite = s_bandit_warlock_corpse", EventType.Create, 0);

            // T4 Bandits

            UndertaleGameObject o_bandit_condottiere_z = Msl.AddObject(  // Rogue Knight (T4 Bandit) (Boss)
            name: "o_bandit_condottiere_z",
            spriteName: "s_bandit_ringleader_shield_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_condottiere_z", "event_inherited()\r\nscr_bw_param(\"Brigand Condottiere\")\r\nhead_sprite = s_bandit_ringleader_head\r\nscr_create_skill_map(\"Cleave\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Defensive_Stance\")\r\nscr_create_skill_passive(o_pass_skill_sharpened_edge)\r\nscr_create_skill_passive(o_pass_skill_moment_of_retribution)\r\nscr_create_skill_passive(o_pass_skill_ultimate_resilience)\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\ncorpse_sprite = s_bandit_ringleader_shieldsword_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_paymaster_z = Msl.AddObject(  // Paymaster (T4 Bandit) (Boss)
            name: "o_bandit_paymaster_z",
            spriteName: "s_bandit_paymaster_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_paymaster_z", "event_inherited()\r\nscr_bw_param(\"Brigand Paymaster\")\r\nscr_create_skill_map(\"Feint_Swing\")\r\nscr_create_skill_map(\"Riposte\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_map(\"Thirst_for_Battle\")\r\nscr_create_skill_passive(o_pass_skill_fight_to_death)\r\nscr_create_skill_map(\"Heroic_Charge\")\r\nscr_create_skill_passive(o_pass_skill_disengage)\r\ncorpse_sprite = s_bandit_paymaster01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_huntmaster_z = Msl.AddObject(  // Beast Trapper / Huntmaster / Sharpshooter (So many names lol) (T4 Bandit) (Boss)
            name: "o_bandit_huntmaster_z",
            spriteName: "s_bandit_huntmaster_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_huntmaster_z", "event_inherited()\r\nscr_bw_param(\"Brigand Huntmaster\")\r\nammoCount = 0\r\nis_shoot = true\r\nreload = true\r\ncrossbowIsLoaded = false\r\nisCrossbowmanEnemy = true\r\narrowTypeSprite = s_leafshapedbolt_shoot\r\narrowTypeUsed = o_leafshaped_bolt_used\r\nscr_create_skill_map(\"Taking_Aim\")\r\nscr_create_skill_map(\"Headshot\")\r\nscr_create_skill_map(\"Hunters_Mark\")\r\nscr_create_skill_passive(o_pass_skill_constant_training)\r\nscr_create_skill_passive(o_pass_skill_control_shot)\r\nscr_create_skill_passive(o_pass_skill_weak_spots)\r\nscr_create_skill_passive(o_pass_skill_precision)\r\nscr_create_skill_passive(o_pass_skill_hard_target)\r\ncorpse_sprite = s_bandit_sharpshooter_corpse", EventType.Create, 0);
            Msl.AddNewEvent("o_bandit_huntmaster_z", "event_inherited()\r\nif scr_instance_exists_in_list(o_b_ammo_count, buffs)\r\n{\r\nwith (o_b_ammo_count)\r\n{\r\nif (target == other.id)\r\nother.ammoCount = duration\r\n}\r\n}\r\nelse\r\nscr_effect_create(o_b_ammo_count, 0, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_bandit_deserter_sword_z = Msl.AddObject(  // Deserter sword shield (T4 Bandit)
            name: "o_bandit_deserter_sword_z",
            spriteName: "s_bandit_soldier_sword_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_deserter_sword_z", "event_inherited()\r\nscr_bw_param(\"Brigand Deserter Sword\")\r\nscr_create_skill_map(\"Cleave\")\r\nscr_create_skill_map(\"Advance\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_passive(o_pass_skill_gloat)\r\ncorpse_sprite = s_bandit_soldier_sword01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_deserter_axe_z = Msl.AddObject(  // Deserter axe shield (T4 Bandit)
            name: "o_bandit_deserter_axe_z",
            spriteName: "s_bandit_soldier_axe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_deserter_axe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Deserter Axe\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nscr_create_skill_map(\"Crippling_Lunge\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_passive(o_pass_skill_reprisal)\r\nscr_create_skill_passive(o_pass_skill_ferocity)\r\ncorpse_sprite = s_bandit_soldier_axe01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_deserter_flail_z = Msl.AddObject(  // Deserter Flail (T4 Bandit)
            name: "o_bandit_deserter_flail_z",
            spriteName: "s_bandit_soldier_mace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_deserter_flail_z", "event_inherited()\r\nscr_bw_param(\"Brigand Deserter Flail\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_passive(o_pass_skill_moment_of_weakness)\r\nscr_create_skill_passive(o_pass_skill_dazing_strikes)\r\nscr_create_skill_passive(o_pass_skill_sprint_training)\r\ncorpse_sprite = s_bandit_soldier_mace01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_deserter_2hflail_z = Msl.AddObject(  // Deserter 2h Flail (T4 Bandit)
            name: "o_bandit_deserter_2hflail_z",
            spriteName: "s_bandit_deserter_2hflail_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_deserter_2hflail_z", "event_inherited()\r\nscr_bw_param(\"Brigand Deserter 2HFlail\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\nscr_create_skill_passive(o_pass_skill_heavy_concussion)\r\ncorpse_sprite = s_bandit_deserter_gflail01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_magistrate_deserter_2haxe_z = Msl.AddObject(  // Magistrate Deserter 2h axe (T4 Bandit)
            name: "o_bandit_magistrate_deserter_2haxe_z",
            spriteName: "s_bandit_gmdeserter_gaxe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_magistrate_deserter_2haxe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Magistrate Deserter 2HAxe\")\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Reign_in_Blood\")\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Rampage\")\r\nscr_create_skill_map(\"Battering_Ram\")\r\ncorpse_sprite = s_bandit_gmdeserter_gaxe01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_magistrate_deserter_2hmace_z = Msl.AddObject(  // Magistrate Deserter 2h mace (T4 Bandit)
            name: "o_bandit_magistrate_deserter_2hmace_z",
            spriteName: "s_bandit_gmdeserter_ghammer_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_magistrate_deserter_2hmace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Magistrate Deserter 2HMace\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Mayhem\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_map(\"Active_Defence\")\r\nscr_create_skill_map(\"Battering_Ram\")\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\ncorpse_sprite = s_bandit_gmdeserter_ghammer01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_magistrate_deserter_halberd_z = Msl.AddObject(  // Magistrate Deserter polearms (T4 Bandit)
            name: "o_bandit_magistrate_deserter_halberd_z",
            spriteName: "s_bandit_gmdeserter_polearm_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_magistrate_deserter_halberd_z", "event_inherited()\r\nscr_bw_param(\"Brigand Magistrate Deserter Halberd\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Piercing_Lunge\")\r\nscr_create_skill_map(\"Pikemans_Stance\")\r\nscr_create_skill_map(\"Regroup\")\r\nscr_create_skill_map(\"Active_Defence\")\r\nscr_create_skill_passive(o_pass_skill_one_at_a_time)\r\ncorpse_sprite = s_bandit_gmdeserter_polearm01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_banneret_z = Msl.AddObject(  // Banneret (T4 Bandit)
            name: "o_bandit_banneret_z",
            spriteName: "s_bandit_banneret_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_banneret_z", "event_inherited()\r\nscr_bw_param(\"Brigand Banneret\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_passive(o_pass_skill_stay_out)\r\nscr_create_skill_passive(o_pass_skill_no_retreat)\r\nscr_create_skill_passive(o_pass_skill_last_effort)\r\ncorpse_sprite = s_bandit_banneret01_corpse\r\n", EventType.Create, 0);

            UndertaleGameObject o_bandit_marksman_z = Msl.AddObject(  // Marksman / Longbowman (T4 Bandit)
            name: "o_bandit_marksman_z",
            spriteName: "s_bandit_longbowman_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_marksman_z", "event_inherited()\r\nscr_bw_param(\"Brigand Marksman\")\r\nis_shoot = true\r\nreload = true\r\nammoCount = 0\r\narrowTypeSprite = s_leafshapedarrow_shoot\r\narrowTypeUsed = o_arrow_used\r\nscr_create_skill_map(\"Taking_Aim\")\r\nscr_create_skill_map(\"Long_Range_Shot\")\r\nscr_create_skill_map(\"Headshot\")\r\nscr_create_skill_passive(o_pass_skill_precision)\r\nscr_create_skill_passive(o_pass_skill_constant_training)\r\nscr_create_skill_passive(o_pass_skill_hard_target)\r\ncorpse_sprite = s_bandit_longbowman01_corpse", EventType.Create, 0);
            Msl.AddNewEvent("o_bandit_marksman_z", "event_inherited()\r\nif scr_instance_exists_in_list(o_b_ammo_count, buffs)\r\n{\r\nwith (o_b_ammo_count)\r\n{\r\nif (target == other.id)\r\nother.ammoCount = duration\r\n}\r\n}\r\nelse\r\nscr_effect_create(o_b_ammo_count, 0, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_bandit_magehunter_z = Msl.AddObject(  // Magehunter (T4 Bandit)
            name: "o_bandit_magehunter_z",
            spriteName: "s_bandit_magehunter_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_magehunter_z", "event_inherited()\r\nscr_bw_param(\"Brigand Magehunter\")\r\nscr_create_skill_map(\"Advance\")\r\nscr_create_skill_map(\"Seal_of_Shackles\")\r\nscr_create_skill_map(\"Seal_of_Cleansing\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_spirit_and_body)\r\ncorpse_sprite = s_bandit_magehunter01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_geomancer_z = Msl.AddObject(  // Geomancer (T4 Bandit)
            name: "o_bandit_geomancer_z",
            spriteName: "s_bandit_geomancer_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_geomancer_z", "event_inherited()\r\nscr_bw_param(\"Brigand Geomancer\")\r\nscr_create_skill_map(\"Runic_Boulder\")\r\nscr_create_skill_map(\"Stone_Armor\")\r\nscr_create_skill_map(\"Stone_Spikes\")\r\nscr_create_skill_map(\"Boulder_Toss\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_now_or_never)\r\nscr_create_skill_passive(o_pass_skill_battle_trance)\r\ncorpse_sprite = s_bandit_pyromancer02_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_electromancer_z = Msl.AddObject(  // Electromancer (T4 Bandit)
            name: "o_bandit_electromancer_z",
            spriteName: "s_bandit_electromancer_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_electromancer_z", "event_inherited()\r\nscr_bw_param(\"Brigand Electromancer\")\r\nscr_create_skill_map(\"Discharge\")\r\nscr_create_skill_map(\"Impulse\")\r\nscr_create_skill_map(\"Short_Circuit\")\r\nscr_create_skill_map(\"Chain_Lightning\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_unlimited_power)\r\ncorpse_sprite = s_bandit_pyromancer03_corpse", EventType.Create, 0);

            // T5 Bandits 

            UndertaleGameObject o_bandit_witchhunter_z = Msl.AddObject(  // Rogue Witchfinder (T5 Bandit) (Boss)
            name: "o_bandit_witchhunter_z",
            spriteName: "s_bandit_witchhunter_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_witchhunter_z", "event_inherited()\r\nhead_sprite = s_bandit_witchhunter_head\r\nscr_bw_param(\"Brigand Witch Hunter\")\r\nscr_create_skill_map(\"Double_Jab\")\r\nscr_create_skill_map(\"Deadly_Trick\")\r\nscr_create_skill_map(\"Coup_de_Grace\")\r\nscr_create_skill_map(\"Seal_of_Shackles\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_counterattack_mastery)\r\nscr_create_skill_passive(o_pass_skill_dance_of_death)\r\ncorpse_sprite = s_bandit_witchhunter_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_raubritter_2hsword_z = Msl.AddObject(  // RobberBaron 2h Sword (T5 Bandit) (Boss)
            name: "o_bandit_raubritter_2hsword_z",
            spriteName: "s_bandit_raubritter_2hsword_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_raubritter_2hsword_z", "event_inherited()\r\nscr_bw_param(\"Brigand Raubritter 2HSword\")\r\nscr_create_skill_map(\"Feint_Swing\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_map(\"Unyielding_Defence\")\r\nscr_create_skill_map(\"Arc_Cleave\")\r\nscr_create_skill_map(\"Battering_Ram\")\r\nscr_create_skill_passive(o_pass_skill_revanche)\r\nscr_create_skill_passive(o_pass_skill_battle_hardiness)\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\nscr_create_skill_passive(o_pass_skill_fight_to_death)\r\ncorpse_sprite = s_bandit_raubritter_2hsword_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_raubritter_2hmace_z = Msl.AddObject(  // RobberBaron 2h Mace (T5 Bandit) (Boss)
            name: "o_bandit_raubritter_2hmace_z",
            spriteName: "s_bandit_raubritter_2hmace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_raubritter_2hmace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Raubritter 2HMace\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Battering_Ram\")\r\nscr_create_skill_passive(o_pass_skill_heavy_concussion)\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\nscr_create_skill_passive(o_pass_skill_battle_hardiness)\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\ncorpse_sprite = s_bandit_raubritter_2hmace_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_raubritter_flail_z = Msl.AddObject(  // RobberBaron Flail (T5 Bandit) (Boss)
            name: "o_bandit_raubritter_flail_z",
            spriteName: "s_bandit_raubritter_flail_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_raubritter_flail_z", "event_inherited()\r\nscr_bw_param(\"Brigand Raubritter Flail\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Knockout\")\r\nscr_create_skill_map(\"Battering_Ram\")\r\nscr_create_skill_passive(o_pass_skill_battle_hardiness)\r\nscr_create_skill_passive(o_pass_skill_dazing_strikes)\r\nscr_create_skill_passive(o_pass_skill_concussion)\r\nscr_create_skill_passive(o_pass_skill_opportune_moment)\r\ncorpse_sprite = s_bandit_raubritter_flail_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_ringleader_sword_z = Msl.AddObject(  // Ringleader Sword (T5 Bandit)
            name: "o_bandit_ringleader_sword_z",
            spriteName: "s_bandit_ringleader_sword_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_ringleader_sword_z", "event_inherited()\r\nscr_bw_param(\"Brigand Ringleader Sword\")\r\nscr_create_skill_map(\"Cleave\")\r\nscr_create_skill_map(\"Advance\")\r\nscr_create_skill_map(\"Fencer_Stance\")\r\nscr_create_skill_map(\"Offensive_Tactics\")\r\nscr_create_skill_passive(o_pass_skill_gloat)\r\nscr_create_skill_passive(o_pass_skill_sharpened_edge)\r\ncorpse_sprite = s_bandit_sergeant_sword02_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_ringleader_axe_z = Msl.AddObject(  // Ringleader Axe (T5 Bandit)
            name: "o_bandit_ringleader_axe_z",
            spriteName: "s_bandit_ringleader_axe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_ringleader_axe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Ringleader Axe\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nscr_create_skill_map(\"Crippling_Lunge\")\r\nscr_create_skill_map(\"Execution\")\r\nscr_create_skill_map(\"Offensive_Tactics\")\r\nscr_create_skill_passive(o_pass_skill_reprisal)\r\nscr_create_skill_passive(o_pass_skill_tormenting_swings)\r\ncorpse_sprite = s_bandit_soldier_axe01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_renegade_2hsword_z = Msl.AddObject(  // Renegade 2h-sword (T5 Bandit)
            name: "o_bandit_renegade_2hsword_z",
            spriteName: "s_bandit_sergeant_gsword_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_renegade_2hsword_z", "event_inherited()\r\nscr_bw_param(\"Brigand Renegade 2HSword\")\r\nscr_create_skill_map(\"Feint_Swing\")\r\nscr_create_skill_map(\"Riposte\")\r\nscr_create_skill_map(\"Steel_Feast\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_passive(o_pass_skill_fight_to_death)\r\nscr_create_skill_passive(o_pass_skill_revanche)\r\nscr_create_skill_passive(o_pass_skill_taste_of_victory)\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\ncorpse_sprite = s_bandit_sergeant_gsword01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_renegade_2haxe_z = Msl.AddObject(  // Renegade 2h-Axe (T5 Bandit)
            name: "o_bandit_renegade_2haxe_z",
            spriteName: "s_bandit_sergeant_axe_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_renegade_2haxe_z", "event_inherited()\r\nscr_bw_param(\"Brigand Renegade 2HAxe\")\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Reign_in_Blood\")\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Rampage\")\r\nscr_create_skill_map(\"Unyielding_Defence\")\r\nscr_create_skill_passive(o_pass_skill_fatal_hit)\r\nscr_create_skill_passive(o_pass_skill_shieldbreaker)\r\nscr_create_skill_passive(o_pass_skill_finish_him)\r\ncorpse_sprite = s_bandit_sergeant_gaxe01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_renegade_2hmace_z = Msl.AddObject(  // Renegade 2h-Mace (T5 Bandit)
            name: "o_bandit_renegade_2hmace_z",
            spriteName: "s_bandit_renegade_2hmace_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_renegade_2hmace_z", "event_inherited()\r\nscr_bw_param(\"Brigand Renegade 2HMace\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_map(\"Mayhem\")\r\nscr_create_skill_map(\"Forceful_Slam\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\nscr_create_skill_passive(o_pass_skill_heavy_concussion)\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\nscr_create_skill_passive(o_pass_skill_battle_hardiness)\r\ncorpse_sprite = s_bandit_sergeant_gmace01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_renegade_halberd_z = Msl.AddObject(  // Renegade Halberd (T5 Bandit)
            name: "o_bandit_renegade_halberd_z",
            spriteName: "s_bandit_renegade_halberd_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_renegade_halberd_z", "event_inherited()\r\nscr_bw_param(\"Brigand Renegade Halberd\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Piercing_Lunge\")\r\nscr_create_skill_map(\"Pikemans_Stance\")\r\nscr_create_skill_map(\"Regroup\")\r\nscr_create_skill_map(\"Active_Defence\")\r\nscr_create_skill_passive(o_pass_skill_one_at_a_time)\r\nscr_create_skill_passive(o_pass_skill_wounding_spearhead)\r\ncorpse_sprite = s_bandit_halberdier01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_renegade_2hflail_z = Msl.AddObject(  // Renegade 2h-Flail (T5 Bandit)
            name: "o_bandit_renegade_2hflail_z",
            spriteName: "s_bandit_renegade_2hflail_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_renegade_2hflail_z", "event_inherited()\r\nhead_sprite = s_bandit_ringleader_head\r\nscr_bw_param(\"Brigand Renegade 2HFlail\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_map(\"Mayhem\")\r\nscr_create_skill_map(\"Active_Defence\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\nscr_create_skill_passive(o_pass_skill_heavy_concussion)\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\nscr_create_skill_passive(o_pass_skill_intimidation)\r\ncorpse_sprite = s_bandit_ringleader_2hsword_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_duelist_z = Msl.AddObject(  // Duelist (T5 Bandit)
            name: "o_bandit_duelist_z",
            spriteName: "s_bandit_duelist_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_duelist_z", "event_inherited()\r\nscr_bw_param(\"Brigand Duelist\")\r\nscr_create_skill_map(\"Series_of_Strikes\")\r\nscr_create_skill_map(\"Double_Jab\")\r\nscr_create_skill_map(\"Gaping_Wound\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_passive(o_pass_skill_sharpened_edge)\r\nscr_create_skill_passive(o_pass_skill_counterattack_mastery)\r\nscr_create_skill_passive(o_pass_skill_gloat)\r\ncorpse_sprite = s_bandit_duelist01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_arbalester_z = Msl.AddObject(  // Heavy Crossbowman (T5 Bandit)
            name: "o_bandit_arbalester_z",
            spriteName: "s_bandit_heavyarbalester_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_arbalester_z", "event_inherited()\r\nscr_bw_param(\"Brigand Arbalester\")\r\nammoCount = 0\r\nis_shoot = true\r\nreload = true\r\ncrossbowIsLoaded = false\r\nisCrossbowmanEnemy = true\r\narrowTypeSprite = s_leafshapedbolt_shoot\r\narrowTypeUsed = o_leafshaped_bolt_used\r\nscr_create_skill_map(\"Taking_Aim\")\r\nscr_create_skill_map(\"Suppression\")\r\nscr_create_skill_map(\"Headshot\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_passive(o_pass_skill_hard_target)\r\nscr_create_skill_passive(o_pass_skill_constant_training)\r\nscr_create_skill_passive(o_pass_skill_control_shot)\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\nscr_create_skill_passive(o_pass_skill_weak_spots)\r\nscr_create_skill_passive(o_pass_skill_precision)\r\ncorpse_sprite = s_bandit_heavyarbalester01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_pyromancer_z = Msl.AddObject(  // Pyromancer (T5 Bandit)
            name: "o_bandit_pyromancer_z",
            spriteName: "s_bandit_conjurer_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_pyromancer_z", "event_inherited()\r\nscr_bw_param(\"Brigand Pyromancer\")\r\nscr_create_skill_map(\"Fire_Barrage\")\r\nscr_create_skill_map(\"Flame_Ring\")\r\nscr_create_skill_map(\"Flame_Wave\")\r\nscr_create_skill_map(\"Magma_Rain\")\r\nscr_create_skill_map(\"Melting_Ray\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_feed_the_flames)\r\nscr_create_skill_passive(o_pass_skill_scorch)\r\nscr_create_skill_passive(o_pass_skill_baptism_of_fire)\r\ncorpse_sprite = s_bandit_pyromancer01_corpse", EventType.Create, 0);

            // New Bandits

            UndertaleGameObject o_bandit_overseer_z = Msl.AddObject(  // Bandit Overseer (T1 Bandit) (Boss)
            name: "o_bandit_overseer_z",
            spriteName: "s_bandit_overseer_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_overseer_z", "event_inherited()\r\nscr_bw_param(\"Brigand Overseer\")\r\nscr_create_skill_map(\"Lash_Blessing\")\r\nscr_create_skill_map(\"Power_Kick\")\r\nscr_create_skill_map(\"Sudden_Strike\")\r\ncorpse_sprite = s_bandit_overseer_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_miner_z = Msl.AddObject(  // Bandit Miner (T1 Bandit)
            name: "o_bandit_miner_z",
            spriteName: "s_bandit_miner_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_miner_z", "event_inherited()\r\nscr_bw_param(\"Brigand Miner\")\r\ncorpse_sprite = s_bandit_miner01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_scout_z = Msl.AddObject(  // Bandit Scout (T1 Bandit)
            name: "o_bandit_scout_z",
            spriteName: "s_bandit_scout_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_scout_z", "event_inherited()\r\nscr_bw_param(\"Brigand Scout\")\r\ncorpse_sprite = s_bandit_scout01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_raider_z = Msl.AddObject(  // Bandit Raider (T2 Bandit) (Boss)
            name: "o_bandit_raider_z",
            spriteName: "s_bandit_raider_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_raider_z", "event_inherited()\r\nscr_bw_param(\"Brigand Raider\")\r\nnetSize = \"high\"\r\ncritDeathAnimationFraction = \"\"\r\nshadow_spr_shift = [2, 0]\r\nscr_create_skill_map(\"Crippling_Lunge\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_passive(o_pass_skill_moment_of_retribution)\r\nscr_create_skill_passive(o_pass_skill_show_no_mercy)\r\ncorpse_sprite = s_bandit_raider_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_torturer_z = Msl.AddObject(  // Bandit Torturer (T3 Bandit) (Boss)
            name: "o_bandit_torturer_z",
            spriteName: "s_bandit_torturer_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_torturer_z", "event_inherited()\r\nscr_bw_param(\"Brigand Torturer\")\r\nnetSize = \"high\"\r\ncritDeathAnimationFraction = \"\"\r\nshadow_spr_shift = [2, 0]\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_map(\"Mayhem\")\r\nscr_create_skill_map(\"Power_Kick\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\nscr_create_skill_passive(o_pass_skill_heavy_concussion)\r\nscr_create_skill_passive(o_enemy_pass_driven_by_pain)\r\ncorpse_sprite = s_bandit_torturer_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_prospector_z = Msl.AddObject(  // Bandit Prospector (T3 Bandit)
            name: "o_bandit_prospector_z",
            spriteName: "s_bandit_prospector_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_prospector_z", "event_inherited()\r\nscr_bw_param(\"Brigand Prospector\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Power_Kick\")\r\nscr_create_skill_map(\"Sweep\")\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\ncorpse_sprite = s_bandit_prospector01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_spelunker_z = Msl.AddObject(  // Bandit Spelunker (T3 Bandit)
            name: "o_bandit_spelunker_z",
            spriteName: "s_bandit_spelunker_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_spelunker_z", "event_inherited()\r\nscr_bw_param(\"Brigand Spelunker\")\r\nscr_create_skill_map(\"Double_Jab\")\r\nscr_create_skill_passive(o_pass_skill_weakening_jabs)\r\ncorpse_sprite = s_bandit_spelunker01_corpse", EventType.Create, 0);

            UndertaleGameObject o_bandit_arcanist_z = Msl.AddObject(  // Bandit Arcanist (T5 Bandit) (Boss)
            name: "o_bandit_arcanist_z",
            spriteName: "s_bandit_arcanist_z",
            parentName: "o_bw_brigand",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bandit_arcanist_z", "event_inherited()\r\nscr_bw_param(\"Brigand Arcanist\")\r\nscr_create_skill_map(\"Planar_Exchange\")\r\nscr_create_skill_map(\"Aether_Shield\")\r\nscr_create_skill_map(\"Mana_Crystal\")\r\nscr_create_skill_map(\"Astral_Phantasm\")\r\nscr_create_skill_map(\"Seal_of_Power\")\r\nscr_create_skill_map(\"Fire_Barrage\")\r\nscr_create_skill_map(\"Peacemaker\")\r\nscr_create_skill_passive(o_pass_skill_aethereal_harmony)\r\nscr_create_skill_passive(o_pass_skill_arcane_might)\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_lingering_incantations)\r\nscr_create_skill_passive(o_pass_skill_thaumaturgy)\r\ncorpse_sprite = s_bandit_arcanist01_corpse", EventType.Create, 0);
            Msl.AddNewEvent("o_bandit_arcanist_z", "event_inherited()\r\nif is_full_destroy\r\n{\r\n    with (o_summoned_entity)\r\n    {\r\n        if (owner == other.id)\r\n            HP = 0\r\n    }\r\n}\r\n", EventType.Destroy, 0);
            Msl.AddNewEvent("o_bandit_arcanist_z", "event_inherited()\r\nwith (o_planar_exchange)\r\n{\r\n    if (owner.id == other.id)\r\n        target_array = other.target_array\r\n}", EventType.Other, 11);

            // Death March 

            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_zombiepass.gml"), "scr_bw_zombiepass");
            Msl.LoadGML("gml_Object_o_enemy_pass_zombie_Other_22").MatchFrom("scr_param((string(enemyTag) + \" NH\"), false)").ReplaceBy("scr_bw_zombiepass()").Save();

            UndertaleGameObject o_Undead_bw = Msl.AddObject(  // Parenting Object
            name: "o_Undead_bw",
            spriteName: "",
            parentName: "o_Undead",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_Undead_bw", "event_inherited()\r\nrevivify_dur = 0\r\nalarm[4] = 1\r\nowner = o_player", EventType.Create, 0);
            Msl.AddNewEvent("o_Undead_bw", "event_inherited()\r\ncorpse_durability = min(100, max(0, corpse_durability))", EventType.Step, 2);
            Msl.AddNewEvent("o_Undead_bw", "if (!(scr_instance_exists_in_list(o_b_servemaster, buffs)))\r\n{\r\n    with (self)\r\n        scr_effect_create(o_b_servemaster, revivify_dur, id, id)\r\n}\r\nif scr_instance_exists_in_list(o_b_corpse_dur, buffs)\r\n{\r\n    with (o_b_corpse_dur)\r\n    {\r\n        if (target == other.id)\r\n            other.corpse_durability = duration\r\n    }\r\n}\r\nelse\r\n    scr_effect_create(o_b_corpse_dur, o_damage_dealer, id, id)", EventType.Alarm, 4);
            Msl.AddNewEvent("o_Undead_bw", "if ((!global.attack_mode_on) && (!keyboard_check(vk_shift)))\r\n{\r\n    with (id)\r\n        scr_voice_text(choose(\". . .\"), -4, 16777215, 0, -39, 0)\r\n    scr_actionsLog(\"speech\", [scr_id_get_name(id), scr_actionsLogSpeechFormat(choose(\". . .\"))])\r\n}\r\nelse\r\n    event_inherited()", EventType.Mouse, 4);

            Msl.AddNewEvent("o_Specter_bw", "event_inherited()\r\nrevivify_dur = 0\r\nalarm[4] = 1\r\nowner = o_player", EventType.Create, 0);
            Msl.AddNewEvent("o_Specter_bw", "event_inherited()\r\ncorpse_durability = min(100, max(0, corpse_durability))", EventType.Step, 2);
            Msl.AddNewEvent("o_Specter_bw", "if (!(scr_instance_exists_in_list(o_b_servemaster, buffs)))\r\n{\r\n    with (self)\r\n        scr_effect_create(o_b_servemaster, revivify_dur, id, id)\r\n}\r\nif scr_instance_exists_in_list(o_b_corpse_dur, buffs)\r\n{\r\n    with (o_b_corpse_dur)\r\n    {\r\n        if (target == other.id)\r\n            other.corpse_durability = duration\r\n    }\r\n}\r\nelse\r\n    scr_effect_create(o_b_corpse_dur, o_damage_dealer, id, id)", EventType.Alarm, 4);
            Msl.AddNewEvent("o_Specter_bw", "if ((!global.attack_mode_on) && (!keyboard_check(vk_shift)))\r\n{\r\n    with (id)\r\n        scr_voice_text(choose(\". . .\"), -4, 16777215, 0, -39, 0)\r\n    scr_actionsLog(\"speech\", [scr_id_get_name(id), scr_actionsLogSpeechFormat(choose(\". . .\"))])\r\n}\r\nelse\r\n    event_inherited()", EventType.Mouse, 4);

            UndertaleGameObject c_zombie_bw = Msl.AddObject(  // Parenting Object
            name: "c_zombie_bw",
            spriteName: "",
            parentName: "c_zombie",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("c_zombie_bw", "event_inherited()\r\nrevivify_dur = 0\r\nalarm[4] = 1\r\nowner = o_player", EventType.Create, 0);
            Msl.AddNewEvent("c_zombie_bw", "event_inherited()\r\ncorpse_durability = min(100, max(0, corpse_durability))", EventType.Step, 2);
            Msl.AddNewEvent("c_zombie_bw", "if (!(scr_instance_exists_in_list(o_b_servemaster, buffs)))\r\n{\r\n    with (self)\r\n        scr_effect_create(o_b_servemaster, revivify_dur, id, id)\r\n}\r\nif scr_instance_exists_in_list(o_b_corpse_dur, buffs)\r\n{\r\n    with (o_b_corpse_dur)\r\n    {\r\n        if (target == other.id)\r\n            other.corpse_durability = duration\r\n    }\r\n}\r\nelse\r\n    scr_effect_create(o_b_corpse_dur, o_damage_dealer, id, id)", EventType.Alarm, 4);
            Msl.AddNewEvent("c_zombie_bw", "if ((!global.attack_mode_on) && (!keyboard_check(vk_shift)))\r\n{\r\n    with (id)\r\n        scr_voice_text(choose(\". . .\"), -4, 16777215, 0, -39, 0)\r\n    scr_actionsLog(\"speech\", [scr_id_get_name(id), scr_actionsLogSpeechFormat(choose(\". . .\"))])\r\n}\r\nelse\r\n    event_inherited()", EventType.Mouse, 4);

            UndertaleGameObject c_ghoul_bw = Msl.AddObject(  // Parenting Object
            name: "c_ghoul_bw",
            spriteName: "",
            parentName: "c_ghoul",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("c_ghoul_bw", "event_inherited()\r\nrevivify_dur = 0\r\nalarm[4] = 1\r\nowner = o_player", EventType.Create, 0);
            Msl.AddNewEvent("c_ghoul_bw", "event_inherited()\r\ncorpse_durability = min(100, max(0, corpse_durability))", EventType.Step, 2);
            Msl.AddNewEvent("c_ghoul_bw", "if (!(scr_instance_exists_in_list(o_b_servemaster, buffs)))\r\n{\r\n    with (self)\r\n        scr_effect_create(o_b_servemaster, revivify_dur, id, id)\r\n}\r\nif scr_instance_exists_in_list(o_b_corpse_dur, buffs)\r\n{\r\n    with (o_b_corpse_dur)\r\n    {\r\n        if (target == other.id)\r\n            other.corpse_durability = duration\r\n    }\r\n}\r\nelse\r\n    scr_effect_create(o_b_corpse_dur, o_damage_dealer, id, id)", EventType.Alarm, 4);
            Msl.AddNewEvent("c_ghoul_bw", "if ((!global.attack_mode_on) && (!keyboard_check(vk_shift)))\r\n{\r\n    with (id)\r\n        scr_voice_text(choose(\". . .\"), -4, 16777215, 0, -39, 0)\r\n    scr_actionsLog(\"speech\", [scr_id_get_name(id), scr_actionsLogSpeechFormat(choose(\". . .\"))])\r\n}\r\nelse\r\n    event_inherited()", EventType.Mouse, 4);

            UndertaleGameObject o_skeleton_bw = Msl.AddObject(  // Parenting Object
            name: "o_skeleton_bw",
            spriteName: "",
            parentName: "o_skeleton",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_bw", "event_inherited()\r\nrevivify_dur = 0\r\nalarm[4] = 1\r\nowner = o_player", EventType.Create, 0);
            Msl.AddNewEvent("o_skeleton_bw", "event_inherited()\r\ncorpse_durability = min(100, max(0, corpse_durability))", EventType.Step, 2);
            Msl.AddNewEvent("o_skeleton_bw", "if (!(scr_instance_exists_in_list(o_b_servemaster, buffs)))\r\n{\r\n    with (self)\r\n        scr_effect_create(o_b_servemaster, revivify_dur, id, id)\r\n}\r\nif scr_instance_exists_in_list(o_b_corpse_dur, buffs)\r\n{\r\n    with (o_b_corpse_dur)\r\n    {\r\n        if (target == other.id)\r\n            other.corpse_durability = duration\r\n    }\r\n}\r\nelse\r\n    scr_effect_create(o_b_corpse_dur, o_damage_dealer, id, id)", EventType.Alarm, 4);
            Msl.AddNewEvent("o_skeleton_bw", "if ((!global.attack_mode_on) && (!keyboard_check(vk_shift)))\r\n{\r\n    with (id)\r\n        scr_voice_text(choose(\". . .\"), -4, 16777215, 0, -39, 0)\r\n    scr_actionsLog(\"speech\", [scr_id_get_name(id), scr_actionsLogSpeechFormat(choose(\". . .\"))])\r\n}\r\nelse\r\n    event_inherited()", EventType.Mouse, 4);

            // T1 Undeads

            UndertaleGameObject o_occultist_z = Msl.AddObject(  // Occultist (T1 Undead) (Boss)
            name: "o_occultist_z",
            spriteName: "s_necromancer01",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_occultist_z", "event_inherited()\r\nspr = sprite_index\r\nscr_set_hl()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nhostile_voice_tag = \"hostileNecromancer\"\r\nattack_voice_tag = \"attackNecromancer\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nidle_undead_speech = \"\"\r\nscr_bw_param(\"Occultist\")\r\nhead_sprite = asset_get_index(sprite_get_name(sprite_index) + \"_head\")\r\nscr_create_skill_map(\"Darkbolt\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Double_Jab\")\r\nds_list_add(cought_list, snd_cough_men_1, snd_cough_men_2, snd_cough_men_3, snd_cough_men_4)\r\nalert_snd = choose(snd_necromancer_alert_1, snd_necromancer_alert_2, snd_necromancer_alert_3, snd_necromancer_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_z = Msl.AddObject(  // Wraith (T1 Undead)
            name: "o_ghost_z",
            spriteName: "s_ghost",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nsprite_index = choose(s_ghost, s_ghost02)\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_zombieAxe_z = Msl.AddObject(  //Zombie Axe  (T1 Undead)
            name: "o_zombieAxe_z",
            spriteName: "s_zombie05",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieAxe_z", "event_inherited()\r\nenemyTag = \"Zombie Axe\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieAxe_zNH = Msl.AddObject(  //Zombie Axe  (T1 Undead)
            name: "o_zombieAxe_zNH",
            spriteName: "s_zombie05",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieAxe_zNH", "event_inherited()\r\nscr_bw_param(\"Zombie Axe NH\")\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombiePitchfork_z = Msl.AddObject(  //Zombie Pitchfork  (T1 Undead)
            name: "o_zombiePitchfork_z",
            spriteName: "s_zombie06",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombiePitchfork_z", "event_inherited()\r\nenemyTag = \"Zombie Pitchfork\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nis_two_hand_drop = false", EventType.Create, 0);

            UndertaleGameObject o_zombiePitchfork_zNH = Msl.AddObject(  //Zombie Pitchfork  (T1 Undead)
            name: "o_zombiePitchfork_zNH",
            spriteName: "s_zombie06",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombiePitchfork_zNH", "event_inherited()\r\nscr_bw_param(\"Zombie Pitchfork NH\")\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieDagger_z = Msl.AddObject(  //Zombie Dagger  (T1 Undead)
            name: "o_zombieDagger_z",
            spriteName: "s_zombie04",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieDagger_z", "event_inherited()\r\nenemyTag = \"Zombie Dagger\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieDagger_zNH = Msl.AddObject(  //Zombie Dagger  (T1 Undead)
            name: "o_zombieDagger_zNH",
            spriteName: "s_zombie04",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieDagger_zNH", "event_inherited()\r\nscr_bw_param(\"Zombie Dagger NH\")\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombie_z = Msl.AddObject(  //Zombie (T1 Undead)
            name: "o_zombie_z",
            spriteName: "s_zombie01",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombie_z", "sprite_index = choose(s_zombie01, s_zombie02, s_zombie03)\r\nevent_inherited()\r\nscr_bw_param(\"Zombie\")\r\nisLootDropped = false\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_necromancer_z = Msl.AddObject(  //Necromancer (T2 Undead) (Boss)
            name: "o_necromancer_z",
            spriteName: "s_necromancer02",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_necromancer_z", "event_inherited()\r\nsprite_index = s_necromancer02\r\nspr = sprite_index\r\nscr_set_hl()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nhostile_voice_tag = \"hostileNecromancer\"\r\nattack_voice_tag = \"attackNecromancer\"\r\nidle_undead_speech = \"\"\r\nscr_bw_param(\"Necromancer\")\r\nhead_sprite = asset_get_index(sprite_get_name(sprite_index) + \"_head\")\r\nalert_snd = choose(snd_necromancer_alert_1, snd_necromancer_alert_2, snd_necromancer_alert_3, snd_necromancer_alert_4)\r\nscr_create_skill_map(\"Sigil_Of_Binding\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nscr_create_skill_map(\"Hail_of_Blows\")", EventType.Create, 0);

            UndertaleGameObject o_archivist_z = Msl.AddObject(  //Archivist (T2 Undead) (Boss)
            name: "o_archivist_z",
            spriteName: "s_archivist",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_archivist_z", "event_inherited()\r\nspr = sprite_index\r\nscr_set_hl()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nhostile_voice_tag = \"hostileNecromancer\"\r\nattack_voice_tag = \"attackNecromancer\"\r\nidle_undead_speech = \"\"\r\nscr_bw_param(\"Archivist\")\r\nhead_sprite = asset_get_index(sprite_get_name(sprite_index) + \"_head\")\r\nalert_snd = choose(snd_necromancer_alert_1, snd_necromancer_alert_2, snd_necromancer_alert_3, snd_necromancer_alert_4)\r\nscr_create_skill_map(\"Darkbolt\")\r\nscr_create_skill_map(\"Death_Touch\")\r\nscr_create_skill_map(\"Sign_of_Darkness\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Seal_of_Power\")\r\nds_list_add(cought_list, snd_cough_men_1, snd_cough_men_2, snd_cough_men_3, snd_cough_men_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_squire_z = Msl.AddObject(  // Wraith Squire (T2 Undead)
            name: "o_ghost_squire_z",
            spriteName: "s_ghost_squire",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_squire_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith Squire\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_monk_z = Msl.AddObject(  // Wraith Monk (T2 Undead)
            name: "o_ghost_monk_z",
            spriteName: "s_ghost_monk",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_monk_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith Monk\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Dark_Blessing\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghoul_small_z = Msl.AddObject(  // Ghoul Small (T2 Undead)
            name: "o_ghoul_small_z",
            spriteName: "s_ghoul_small_z",
            parentName: "c_ghoul_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghoul_small_z", "event_inherited()\r\nscr_bw_param(\"Small Ghoul\")\r\ncorpse_sprite = s_ghoul_small_dead", EventType.Create, 0);

            UndertaleGameObject o_zombieGuardSword_z = Msl.AddObject(  //Zombie Guard Sword (T2 Undead)
            name: "o_zombieGuardSword_z",
            spriteName: "s_zombie07",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieGuardSword_z", "event_inherited()\r\nenemyTag = \"Zombie Guard Sword\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieGuardSword_zNH = Msl.AddObject(  //Zombie Guard Sword (T2 Undead)
            name: "o_zombieGuardSword_zNH",
            spriteName: "s_zombie07",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieGuardSword_zNH", "event_inherited()\r\nscr_bw_param(\"Zombie Guard Sword NH\")\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieBrigandSword_z = Msl.AddObject(  //Zombie Brigand Sword (T2 Undead)
            name: "o_zombieBrigandSword_z",
            spriteName: "s_zombie09",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieBrigandSword_z", "event_inherited()\r\nenemyTag = \"Zombie Brigand Sword\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieBrigandSword_zNH = Msl.AddObject(  //Zombie Brigand Sword (T2 Undead)
            name: "o_zombieBrigandSword_zNH",
            spriteName: "s_zombie09",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieBrigandSword_zNH", "event_inherited()\r\nenemyTag = \"Zombie Brigand Sword NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieGuardSpear_z = Msl.AddObject(  //Zombie Guard Spear (T2 Undead)
            name: "o_zombieGuardSpear_z",
            spriteName: "s_zombie10",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieGuardSpear_z", "event_inherited()\r\nenemyTag = \"Zombie Guard Spear\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieGuardSpear_zNH = Msl.AddObject(  //Zombie Guard Spear (T2 Undead)
            name: "o_zombieGuardSpear_zNH",
            spriteName: "s_zombie10",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieGuardSpear_zNH", "event_inherited()\r\nenemyTag = \"Zombie Guard Spear NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieGuardHalberd_z = Msl.AddObject(  //Zombie Guard Halberd (T2 Undead)
            name: "o_zombieGuardHalberd_z",
            spriteName: "s_zombie11",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieGuardHalberd_z", "event_inherited()\r\nenemyTag = \"Zombie Guard Halberd\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_zombieGuardHalberd_zNH = Msl.AddObject(  //Zombie Guard Halberd (T2 Undead)
            name: "o_zombieGuardHalberd_zNH",
            spriteName: "s_zombie11",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieGuardHalberd_zNH", "event_inherited()\r\nenemyTag = \"Zombie Guard Halberd NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_map(\"Strangling_Grasp\")", EventType.Create, 0);

            UndertaleGameObject o_skeleton_monk_z = Msl.AddObject(  //Skeleton Monk (T2 Undead)
            name: "o_skeleton_monk_z",
            spriteName: "s_skeleton_monk",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_monk_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Monk\")\r\nscr_create_skill_map(\"Darkbolt\")", EventType.Create, 0);

            UndertaleGameObject o_skeleton_swordsman_z = Msl.AddObject(  //Skeleton Swordman (T2 Undead)
            name: "o_skeleton_swordsman_z",
            spriteName: "s_skeleton_swordsman",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_swordsman_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Swordsman\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nhave_shield = true", EventType.Create, 0);

            UndertaleGameObject o_skeleton_axeman_z = Msl.AddObject(  //Skeleton Axeman (T2 Undead)
            name: "o_skeleton_axeman_z",
            spriteName: "s_skeleton_axeman",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_axeman_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Axeman\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nhave_shield = true", EventType.Create, 0);

            UndertaleGameObject o_skeleton_maceman_z = Msl.AddObject(  //Skeleton Axeman (T2 Undead)
            name: "o_skeleton_maceman_z",
            spriteName: "s_skeleton_maceman",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_maceman_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Maceman\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nhave_shield = true", EventType.Create, 0);

            UndertaleGameObject o_skeleton_spearman_z = Msl.AddObject(  //Skeleton Axeman (T2 Undead)
            name: "o_skeleton_spearman_z",
            spriteName: "s_skeleton_spearman",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_spearman_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Spearman\")\r\nscr_create_skill_map(\"Piercing_Lunge\")", EventType.Create, 0);

            UndertaleGameObject o_skeleton_bowman_z = Msl.AddObject(  //Skeleton Axeman (T2 Undead)
            name: "o_skeleton_bowman_z",
            spriteName: "s_skeleton_bowman",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_bowman_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Spearman\")\r\nscr_create_skill_map(\"Piercing_Lunge\")", EventType.Create, 0);
            Msl.AddNewEvent("o_skeleton_bowman_z", "event_inherited()\r\nif scr_instance_exists_in_list(o_b_ammo_count, buffs)\r\n{\r\nwith (o_b_ammo_count)\r\n{\r\nif (target == other.id)\r\nother.ammoCount = duration\r\n}\r\n}\r\nelse\r\nscr_effect_create(o_b_ammo_count, 0, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_ritualist_z = Msl.AddObject(  //Ritualist (T3 Undead) (Boss)
            name: "o_ritualist_z",
            spriteName: "s_necromancer04",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ritualist_z", "event_inherited()\r\nscr_set_hl()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nhostile_voice_tag = \"hostileNecromancer\"\r\nattack_voice_tag = \"attackNecromancer\"\r\nidle_undead_speech = \"\"\r\nscr_bw_param(\"Ritualist\")\r\nhead_sprite = asset_get_index(sprite_get_name(sprite_index) + \"_head\")\r\nalert_snd = choose(snd_necromancer_alert_1, snd_necromancer_alert_2, snd_necromancer_alert_3, snd_necromancer_alert_4)\r\nscr_create_skill_map(\"Darkbolt\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")\r\nscr_create_skill_map(\"Deadly_Premonition\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nscr_create_skill_map(\"Hail_of_Blows\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nscr_create_skill_passive(o_pass_skill_spirit_and_body)\r\nds_list_add(cought_list, snd_cough_men_1, snd_cough_men_2, snd_cough_men_3, snd_cough_men_4)", EventType.Create, 0);

            UndertaleGameObject o_armored_husk_z = Msl.AddObject(  //Armored Husk (T3 Undead) (Boss)
            name: "o_armored_husk_z",
            spriteName: "s_husk",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_armored_husk_z", "event_inherited()\r\nscr_bw_param(\"Armored Husk\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Brace_For_Impact\")\r\nscr_create_skill_passive(o_enemy_pass_fall_of_giants)\r\nscr_create_skill_passive(o_enemy_pass_unsteady_gait)", EventType.Create, 0);

            UndertaleGameObject o_undertaker_z = Msl.AddObject(  //Armored Husk (T3 Undead) (Boss)
            name: "o_undertaker_z",
            spriteName: "s_undertaker",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_undertaker_z", "event_inherited()\r\nspr = sprite_index\r\nscr_set_hl()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nhostile_voice_tag = \"hostileNecromancer\"\r\nattack_voice_tag = \"attackNecromancer\"\r\nidle_undead_speech = \"\"\r\nscr_bw_param(\"Undertaker\")\r\nhead_sprite = asset_get_index(sprite_get_name(sprite_index) + \"_head\")\r\nalert_snd = choose(snd_necromancer_alert_1, snd_necromancer_alert_2, snd_necromancer_alert_3, snd_necromancer_alert_4)\r\nscr_create_skill_map(\"Befoul_the_Remains\")\r\nscr_create_skill_map(\"Deadly_Premonition\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nscr_create_skill_map(\"Death_Touch\")\r\nds_list_add(cought_list, snd_cough_men_1, snd_cough_men_2, snd_cough_men_3, snd_cough_men_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_knight_z = Msl.AddObject(  // Wraith Warrior (T3 Undead)
            name: "o_ghost_knight_z",
            spriteName: "s_wraith_knight",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_knight_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith Knight\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Cleave\")\r\nscr_create_skill_map(\"Thirst_for_Battle\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_sergeant_z = Msl.AddObject(  // Wraith Seargent (T3 Undead)
            name: "o_ghost_sergeant_z",
            spriteName: "s_ghost_sergeant",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_sergeant_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith Sergeant\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Feint_Swing\")\r\nscr_create_skill_map(\"Sudden_Strike\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_cleric_z = Msl.AddObject(  // Wraith Cleric (T3 Undead)
            name: "o_ghost_cleric_z",
            spriteName: "s_ghost_cleric",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_cleric_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith Cleric\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Dark_Blessing\")\r\nscr_create_skill_map(\"Curse\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghoul_medium_z = Msl.AddObject(  // Ghoul Medium (T3 Undead)
            name: "o_ghoul_medium_z",
            spriteName: "s_ghoul_medium_z",
            parentName: "c_ghoul_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghoul_medium_z", "event_inherited()\r\nscr_bw_param(\"Medium Ghoul\")\r\nscr_create_skill_map(\"Series_of_Strikes\")\r\nscr_create_skill_map(\"Bone_Throw\")\r\ncorpse_sprite = s_ghoul_medium_dead", EventType.Create, 0);

            UndertaleGameObject o_ghast_z = Msl.AddObject(  // Ghast (T3 Undead)
            name: "o_ghast_z",
            spriteName: "s_ghast",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghast_z", "event_inherited()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nhostile_voice_tag = \"necromancer_alarm\"\r\nattack_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nscr_bw_param(\"Ghast\")\r\nscr_create_skill_map(\"Death_Touch\")\r\nscr_create_skill_map(\"Dark_Blessing\")\r\nscr_create_skill_map(\"Sigil_Of_Binding\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")\r\nalert_snd = choose(snd_ghast_alert_1, snd_ghast_alert_2, snd_ghast_alert_3, snd_ghast_alert_4)\r\ndeath_sound = choose(snd_ghast_death_1, snd_ghast_death_2, snd_ghast_death_3)\r\nemo_death_sound = -4\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghast_emotion_1, snd_ghast_emotion_2, snd_ghast_emotion_3, snd_ghast_emotion_4)", EventType.Create, 0);

            UndertaleGameObject o_zombieSoldierMace_z = Msl.AddObject(  //Zombie Soldier Mace (T3 Undead)
            name: "o_zombieSoldierMace_z",
            spriteName: "s_zombie12",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieSoldierMace_z", "event_inherited()\r\nenemyTag = \"Zombie Soldier Mace\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nis_two_hand_drop = false", EventType.Create, 0);

            UndertaleGameObject o_zombieSoldierMace_zNH = Msl.AddObject(  //Zombie Soldier Mace (T3 Undead)
            name: "o_zombieSoldierMace_zNH",
            spriteName: "s_zombie12",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieSoldierMace_zNH", "event_inherited()\r\nscr_bw_param(\"Zombie Soldier Mace NH\")\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)", EventType.Create, 0);

            UndertaleGameObject o_zombieSoldierAxe_z = Msl.AddObject(  //Zombie Soldier Axe (T3 Undead)
            name: "o_zombieSoldierAxe_z",
            spriteName: "s_zombie13",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieSoldierAxe_z", "event_inherited()\r\nenemyTag = \"Zombie Soldier Axe\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nis_two_hand_drop = false", EventType.Create, 0);

            UndertaleGameObject o_zombieSoldierAxe_zNH = Msl.AddObject(  //Zombie Soldier Axe (T3 Undead)
            name: "o_zombieSoldierAxe_zNH",
            spriteName: "s_zombie13",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieSoldierAxe_zNH", "event_inherited()\r\nenemyTag = \"Zombie Soldier Axe NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)", EventType.Create, 0);

            UndertaleGameObject o_zombieSoldierHalberd_z = Msl.AddObject(  //Zombie Soldier Halberd (T3 Undead)
            name: "o_zombieSoldierHalberd_z",
            spriteName: "s_zombie14",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieSoldierHalberd_z", "event_inherited()\r\nenemyTag = \"Zombie Soldier Halberd\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nis_two_hand_drop = false\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nshadow_spr = s_shadow_medium\r\nshadow_spr_shift = [0, -1]", EventType.Create, 0);

            UndertaleGameObject o_zombieSoldierHalberd_zNH = Msl.AddObject(  //Zombie Soldier Halberd (T3 Undead)
            name: "o_zombieSoldierHalberd_zNH",
            spriteName: "s_zombie14",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieSoldierHalberd_zNH", "event_inherited()\r\nenemyTag = \"Zombie Soldier Halberd NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nshadow_spr = s_shadow_medium\r\nshadow_spr_shift = [0, -1]", EventType.Create, 0);

            UndertaleGameObject o_skeleton_priest_z = Msl.AddObject(  //Skeleton Priest (T3 Undead)
            name: "o_skeleton_priest_z",
            spriteName: "s_skeleton_priest",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_priest_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Priest\")\r\nscr_create_skill_map(\"Darkbolt\")\r\nscr_create_skill_map(\"Sign_of_Darkness\")", EventType.Create, 0);

            UndertaleGameObject o_skeleton_footman_z = Msl.AddObject(  //Skeleton Squire Sword (T3 Undead)
            name: "o_skeleton_footman_z",
            spriteName: "s_skeleton_footman",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_footman_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Footman\")\r\nscr_create_skill_map(\"Cleave\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_passive(o_pass_skill_ultimate_resilience)\r\nscr_create_skill_passive(o_pass_skill_gloat)\r\nhave_shield = true", EventType.Create, 0);

            UndertaleGameObject o_skeleton_militiaman_z = Msl.AddObject(  //Skeleton Squire Axe (T3 Undead)
            name: "o_skeleton_militiaman_z",
            spriteName: "s_skeleton_militiaman",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_militiaman_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Militiaman\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_passive(o_pass_skill_ultimate_resilience)\r\nscr_create_skill_passive(o_pass_skill_show_no_mercy)\r\nhave_shield = true", EventType.Create, 0);

            UndertaleGameObject o_skeleton_defender_z = Msl.AddObject(  //Skeleton Squire Mace (T3 Undead)
            name: "o_skeleton_defender_z",
            spriteName: "s_skeleton_defender",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_defender_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Defender\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Defensive_Stance\")\r\nscr_create_skill_passive(o_pass_skill_ultimate_resilience)\r\nhave_shield = true", EventType.Create, 0);

            UndertaleGameObject o_skeleton_guard_z = Msl.AddObject(  //Skeleton Sariant Halberd (T3 Undead)
            name: "o_skeleton_guard_z",
            spriteName: "s_skeleton_guard",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_guard_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Guard\")\r\nscr_create_skill_map(\"Piercing_Lunge\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_passive(o_pass_skill_one_at_a_time)", EventType.Create, 0);

            UndertaleGameObject o_skeleton_ranger_z = Msl.AddObject(  //Skeleton Bowman (T3 Undead)
            name: "o_skeleton_ranger_z",
            spriteName: "s_skeleton_ranger",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_ranger_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Ranger\")\r\nscr_create_skill_map(\"Taking_Aim\")\r\nis_shoot = true\r\nreload = true\r\nammoCount = 0", EventType.Create, 0);
            Msl.AddNewEvent("o_skeleton_ranger_z", "event_inherited()\r\nif scr_instance_exists_in_list(o_b_ammo_count, buffs)\r\n{\r\nwith (o_b_ammo_count)\r\n{\r\nif (target == other.id)\r\nother.ammoCount = duration\r\n}\r\n}\r\nelse\r\nscr_effect_create(o_b_ammo_count, 0, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_crypt_warden_z = Msl.AddObject(  //Skeleton Crypt Keeper (T4 Undead) (Boss)
            name: "o_crypt_warden_z",
            spriteName: "s_cryptwarden",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_crypt_warden_z", "event_inherited()\r\nshadow_spr = s_shadow_big\r\nshadow_spr_shift = [0, 1]\r\nscr_bw_param(\"Crypt Warden\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Knockout\")\r\nscr_create_skill_map(\"Baleful_Glow\")\r\nscr_create_skill_map(\"Sigil_Of_Binding\")\r\nscr_create_skill_map(\"Death_Touch\")\r\nscr_create_skill_map(\"Sign_of_Darkness\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")\r\nscr_create_skill_map(\"Dark_Blessing\")", EventType.Create, 0);

            UndertaleGameObject o_restless_hero_z = Msl.AddObject(  //Restless Hero (T4 Undead) (Boss)
            name: "o_restless_hero_z",
            spriteName: "s_restlesshero",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_restless_hero_z", "event_inherited()\r\nenemyTag = \"Restless Hero\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Reign_in_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_passive(o_enemy_pass_putrid_stench)\r\nscr_create_skill_passive(o_enemy_pass_tis_but_a_scratch)\r\nscr_create_skill_passive(o_pass_skill_never_again)\r\nscr_create_skill_passive(o_pass_skill_shieldbreaker)\r\nshadow_spr = s_shadow_small", EventType.Create, 0);

            UndertaleGameObject o_restless_hero_zNH = Msl.AddObject(  //Restless Hero (T4 Undead) (Boss)
            name: "o_restless_hero_zNH",
            spriteName: "s_restlesshero",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_restless_hero_zNH", "event_inherited()\r\nenemyTag = \"Restless Hero NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_pass_skill_last_effort)\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_passive(o_enemy_pass_putrid_stench)\r\nscr_create_skill_passive(o_enemy_pass_tis_but_a_scratch)\r\nscr_create_skill_passive(o_pass_skill_never_again)\r\nshadow_spr = s_shadow_small", EventType.Create, 0);

            UndertaleGameObject o_mortician_z = Msl.AddObject(  //Mortician (T4 Undead) (Boss)
            name: "o_mortician_z",
            spriteName: "s_mortician",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_mortician_z", "event_inherited()\r\nspr = sprite_index\r\nscr_set_hl()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nhostile_voice_tag = \"hostileNecromancer\"\r\nattack_voice_tag = \"attackNecromancer\"\r\nidle_undead_speech = \"\"\r\nscr_bw_param(\"Mortician\")\r\nhead_sprite = asset_get_index(sprite_get_name(sprite_index) + \"_head\")\r\nalert_snd = choose(snd_necromancer_alert_1, snd_necromancer_alert_2, snd_necromancer_alert_3, snd_necromancer_alert_4)\r\nscr_create_skill_map(\"Befoul_the_Remains\")\r\nscr_create_skill_map(\"Deadly_Premonition\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nscr_create_skill_map(\"Death_Touch\")\r\nscr_create_skill_map(\"Sigil_Of_Binding\")\r\nds_list_add(cought_list, snd_cough_men_1, snd_cough_men_2, snd_cough_men_3, snd_cough_men_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_templar_z = Msl.AddObject(  //Wraith Templar (T4 Undead)
            name: "o_ghost_templar_z",
            spriteName: "s_ghost_templar",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_templar_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith Templar\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_seer_z = Msl.AddObject(  //Wraith Seer (T4 Undead)
            name: "o_ghost_seer_z",
            spriteName: "s_wraith_hierarch",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_seer_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith Sage\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Darkbolt\")\r\nscr_create_skill_map(\"Dark_Blessing\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Deadly_Premonition\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)\r\n", EventType.Create, 0);

            UndertaleGameObject o_ghoul_large_z = Msl.AddObject(  // Ghoul Large (T4 Undead)
            name: "o_ghoul_large_z",
            spriteName: "s_ghoul_large_z",
            parentName: "c_ghoul_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghoul_large_z", "event_inherited()\r\nscr_bw_param(\"Large Ghoul\")\r\nscr_create_skill_map(\"Series_of_Strikes\")\r\nscr_create_skill_map(\"Lacerate\")\r\nscr_create_skill_map(\"Bone_Throw\")", EventType.Create, 0);

            UndertaleGameObject o_ghast_accursed_z = Msl.AddObject(  // Ghast Accursed (T3 Undead)
            name: "o_ghast_accursed_z",
            spriteName: "s_ghast02",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghast_accursed_z", "event_inherited()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nhostile_voice_tag = \"necromancer_alarm\"\r\nattack_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nscr_bw_param(\"Accursed Ghast\")\r\nscr_create_skill_map(\"Soul_Sacrifice\")\r\nscr_create_skill_map(\"Death_Touch\")\r\nscr_create_skill_map(\"Dark_Blessing\")\r\nscr_create_skill_map(\"Sigil_Of_Binding\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nalert_snd = choose(snd_ghast_alert_1, snd_ghast_alert_2, snd_ghast_alert_3, snd_ghast_alert_4)\r\ndeath_sound = choose(snd_ghast_death_1, snd_ghast_death_2, snd_ghast_death_3)\r\nemo_death_sound = -4\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghast_emotion_1, snd_ghast_emotion_2, snd_ghast_emotion_3, snd_ghast_emotion_4)", EventType.Create, 0);

            UndertaleGameObject o_zombie2HMaceDecayedSoldier_z = Msl.AddObject(  //Putrid Soldier 2hMace (T4 Undead)
            name: "o_zombie2HMaceDecayedSoldier_z",
            spriteName: "s_zombie15",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombie2HMaceDecayedSoldier_z", "event_inherited()\r\nenemyTag = \"Decayed Soldier 2HMace\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_passive(o_enemy_pass_putrid_stench)\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nshadow_spr = s_shadow_small", EventType.Create, 0);

            UndertaleGameObject o_zombie2HMaceDecayedSoldier_zNH = Msl.AddObject(  //Putrid Soldier 2hMace (T4 Undead)
            name: "o_zombie2HMaceDecayedSoldier_zNH",
            spriteName: "s_zombie15",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombie2HMaceDecayedSoldier_zNH", "event_inherited()\r\nenemyTag = \"Decayed Soldier 2HMace NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_passive(o_enemy_pass_putrid_stench)\r\nshadow_spr = s_shadow_small\r\n", EventType.Create, 0);

            UndertaleGameObject o_zombie2HAxeDecayedSoldier_z = Msl.AddObject(  //Putrid Soldier 2hAxe (T4 Undead)
            name: "o_zombie2HAxeDecayedSoldier_z",
            spriteName: "s_zombie17",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombie2HAxeDecayedSoldier_z", "event_inherited()\r\nenemyTag = \"Decayed Soldier 2HAxe\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_passive(o_enemy_pass_putrid_stench)\r\nshadow_spr = s_shadow_small", EventType.Create, 0);

            UndertaleGameObject o_zombie2HAxeDecayedSoldier_zNH = Msl.AddObject(  //Putrid Soldier 2hAxe (T4 Undead)
            name: "o_zombie2HAxeDecayedSoldier_zNH",
            spriteName: "s_zombie17",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombie2HAxeDecayedSoldier_zNH", "event_inherited()\r\nenemyTag = \"Decayed Soldier 2HAxe NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_passive(o_enemy_pass_putrid_stench)\r\nshadow_spr = s_shadow_small\r\n", EventType.Create, 0);

            UndertaleGameObject o_zombieHalberdDecayedSoldier_z = Msl.AddObject(  //Putrid Soldier Halberd (T4 Undead)
            name: "o_zombieHalberdDecayedSoldier_z",
            spriteName: "s_zombie16",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieHalberdDecayedSoldier_z", "event_inherited()\r\nenemyTag = \"Decayed Soldier Halberd\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Strangling_Grasp\")\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_passive(o_enemy_pass_putrid_stench)\r\nshadow_spr = s_shadow_small\r\n", EventType.Create, 0);

            UndertaleGameObject o_zombieHalberdDecayedSoldier_zNH = Msl.AddObject(  //Putrid Soldier Halberd (T4 Undead)
            name: "o_zombieHalberdDecayedSoldier_zNH",
            spriteName: "s_zombie16",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_zombieHalberdDecayedSoldier_zNH", "event_inherited()\r\nenemyTag = \"Decayed Soldier Halberd NH\"\r\nscr_bw_param(enemyTag)\r\nhead_sprite = asset_get_index(string(sprite_get_name(sprite_index) + \"_head\"))\r\nscr_create_skill_passive(o_enemy_pass_zombie)\r\nscr_create_skill_passive(o_enemy_pass_putrid_stench)\r\nshadow_spr = s_shadow_small", EventType.Create, 0);

            UndertaleGameObject o_skeleton_highpriest_z = Msl.AddObject(  //Skeleton High Priest (T4 Undead)
            name: "o_skeleton_highpriest_z",
            spriteName: "s_skeleton_highpriest",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_highpriest_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Highpriest\")\r\nscr_create_skill_map(\"Darkbolt\")\r\nscr_create_skill_map(\"Sign_of_Darkness\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")", EventType.Create, 0);

            UndertaleGameObject o_skeleton_soldier_z = Msl.AddObject(  //Skeleton Soldier (T4 Undead)
            name: "o_skeleton_soldier_z",
            spriteName: "s_skeleton_soldier",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_soldier_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Soldier\")\r\nscr_create_skill_map(\"Cleave\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Breakthrough\")\r\nscr_create_skill_passive(o_pass_skill_ultimate_resilience)\r\nhave_shield = true", EventType.Create, 0);

            UndertaleGameObject o_skeleton_warrior_z = Msl.AddObject(  //Skeleton Warrior (T4 Undead)
            name: "o_skeleton_warrior_z",
            spriteName: "s_skeleton_warrior",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_warrior_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Warrior\")\r\nscr_create_skill_map(\"Cut_Through\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Breakthrough\")\r\nscr_create_skill_passive(o_pass_skill_ultimate_resilience)\r\nhave_shield = true", EventType.Create, 0);

            UndertaleGameObject o_skeleton_armorbreaker_z = Msl.AddObject(  //Skeleton Armor Breaker (T4 Undead)
            name: "o_skeleton_armorbreaker_z",
            spriteName: "s_skeleton_armorbreaker",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_armorbreaker_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Armorbreaker\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Breakthrough\")\r\nscr_create_skill_passive(o_pass_skill_ultimate_resilience)\r\nscr_create_skill_passive(o_pass_skill_dazing_strikes)\r\nhave_shield = true\r\n", EventType.Create, 0);

            UndertaleGameObject o_skeleton_halberdier_z = Msl.AddObject(  //Skeleton Armor Breaker (T4 Undead)
            name: "o_skeleton_halberdier_z",
            spriteName: "s_skeleton_halberdier",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_halberdier_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Halberdier\")\r\nscr_create_skill_map(\"Piercing_Lunge\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_map(\"Pikemans_Stance\")\r\nscr_create_skill_map(\"Active_Defence\")\r\nscr_create_skill_passive(o_pass_skill_stay_out)\r\nscr_create_skill_passive(o_pass_skill_one_at_a_time)", EventType.Create, 0);

            UndertaleGameObject o_skeleton_crossbowman_z = Msl.AddObject(  //Skeleton Crossbowman (T4 Undead) 
            name: "o_skeleton_crossbowman_z",
            spriteName: "s_skeleton_crossbowman",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_crossbowman_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Crossbowman\")\r\nscr_create_skill_map(\"Taking_Aim\")\r\nscr_create_skill_passive(o_pass_skill_weak_spots)\r\narrowTypeSprite = s_leafshapedbolt_shoot\r\narrowTypeUsed = o_leafshaped_bolt_used\r\nis_shoot = true\r\nreload = true\r\ncrossbowIsLoaded = false\r\nisCrossbowmanEnemy = true\r\nammoCount = 0", EventType.Create, 0);
            Msl.AddNewEvent("o_skeleton_crossbowman_z", "event_inherited()\r\nif scr_instance_exists_in_list(o_b_ammo_count, buffs)\r\n{\r\nwith (o_b_ammo_count)\r\n{\r\nif (target == other.id)\r\nother.ammoCount = duration\r\n}\r\n}\r\nelse\r\nscr_effect_create(o_b_ammo_count, 0, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_revenant_z = Msl.AddObject(  //Revenant Commander - Risen Marshal (T5 Undead) (Boss)
            name: "o_revenant_z",
            spriteName: "s_necromancer05",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_revenant_z", "event_inherited()\r\nscr_set_hl()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nhostile_voice_tag = \"hostileNecromancer\"\r\nattack_voice_tag = \"attackNecromancer\"\r\nidle_undead_speech = \"\"\r\nscr_bw_param(\"Revenant\")\r\nscr_create_skill_map(\"Riposte\")\r\nscr_create_skill_map(\"Feint_Swing\")\r\nscr_create_skill_map(\"Seal_of_Reflection\")\r\nscr_create_skill_map(\"Against_the_Odds\")\r\nscr_create_skill_map(\"Darkbolt\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Death_Touch\")\r\nscr_create_skill_passive(o_pass_skill_never_again)\r\nscr_create_skill_passive(o_pass_skill_fight_to_death)\r\nds_list_add(cought_list, snd_cough_men_1, snd_cough_men_2, snd_cough_men_3, snd_cough_men_4)", EventType.Create, 0);

            UndertaleGameObject o_wraithbinder_z = Msl.AddObject(  //Wraith Binder (T5 Undead) (Boss)
            name: "o_wraithbinder_z",
            spriteName: "s_necromancer06",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_wraithbinder_z", "event_inherited()\r\nisIdleAnimation = true\r\nimage_speed = 1\r\nvar _sprite = s_necromancer06_aura\r\nscr_onUnitEffectCreate(id, o_onUnitEffectNecromancerAura, 0, 0, 0, true)\r\nalert_snd = choose(snd_necromancer_alert_1, snd_necromancer_alert_2, snd_necromancer_alert_3, snd_necromancer_alert_4)\r\nscr_set_hl()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nhostile_voice_tag = \"hostileNecromancer\"\r\nattack_voice_tag = \"attackNecromancer\"\r\nidle_undead_speech = \"\"\r\nscr_bw_param(\"Wraithbinder\")\r\nhead_sprite = asset_get_index(sprite_get_name(sprite_index) + \"_head\")\r\nscr_create_skill_map(\"Darkbolt\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Deadly_Premonition\")\r\nscr_create_skill_map(\"Dark_Blessing\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nscr_create_skill_map(\"Sigil_Of_Binding\")\r\nds_list_add(cought_list, snd_cough_men_1, snd_cough_men_2, snd_cough_men_3, snd_cough_men_4)\r\n", EventType.Create, 0);

            UndertaleGameObject o_spectral_herald_z = Msl.AddObject(  // Spectral Herald (T5 Undead) (Boss)
            name: "o_spectral_herald_z",
            spriteName: "s_ghost_spectralherald",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_spectral_herald_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Spectral Herald\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nscr_create_skill_map(\"Sign_of_Darkness\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")\r\nscr_create_skill_map(\"Deadly_Premonition\")\r\nscr_create_skill_passive(o_pass_skill_dispersion)\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghost_commander_z = Msl.AddObject(  // Wraith Commander (T5 Undead)
            name: "o_ghost_commander_z",
            spriteName: "s_ghost_commander",
            parentName: "o_Specter_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghost_commander_z", "event_inherited()\r\ncorpse_type = o_ghost_corpse\r\nspr = sprite_index\r\ndefault_sprite = spr\r\nscr_set_hl()\r\nis_flying = true\r\nimage_alpha = 0.7\r\nblood_ext = false\r\nblood_emit = false\r\nblood_counter = 0\r\nscr_bw_param(\"Wraith Commander\")\r\nscr_create_skill_map(\"Grave_Cold\")\r\nscr_create_skill_map(\"Dissipation\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nscr_create_skill_map(\"Curse\")\r\nscr_create_skill_map(\"Dismember\")\r\nds_list_clear(weapon_impact)\r\nds_list_clear(woosh_sound)\r\nds_list_clear(blood_sound)\r\nds_list_clear(impact_sound)\r\ndeath_sound = choose(snd_ghost_death_1, snd_ghost_death_2, snd_ghost_death_3)\r\nds_list_add(blood_sound, -4)\r\nds_list_add(impact_sound, snd_ghost_impact_1, snd_ghost_impact_2)\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghost_emotion_1, snd_ghost_emotion_2, snd_ghost_emotion_3, snd_ghost_emotion_4)\r\nalert_snd = choose(snd_ghost_alert_1, snd_ghost_alert_2, snd_ghost_alert_3, snd_ghost_alert_4)", EventType.Create, 0);

            UndertaleGameObject o_ghast_elder_z = Msl.AddObject(  // Ancient Ghast (T5 Undead)
            name: "o_ghast_elder_z",
            spriteName: "s_ghast03",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_ghast_elder_z", "event_inherited()\r\ndefault_sprite = spr\r\nsuspicious_voice_tag = \"\"\r\nhostile_voice_tag = \"necromancer_alarm\"\r\nattack_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\nmovement_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nscr_bw_param(\"Elder Ghast\")\r\nscr_create_skill_map(\"Soul_Sacrifice\")\r\nscr_create_skill_map(\"Death_Touch\")\r\nscr_create_skill_map(\"Dark_Blessing\")\r\nscr_create_skill_map(\"Sigil_Of_Binding\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")\r\nscr_create_skill_map(\"Essence_Leech\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nalert_snd = choose(snd_ghast_alert_1, snd_ghast_alert_2, snd_ghast_alert_3, snd_ghast_alert_4)\r\ndeath_sound = choose(snd_ghast_death_1, snd_ghast_death_2, snd_ghast_death_3)\r\nemo_death_sound = -4\r\nds_list_clear(emo_sound)\r\nds_list_add(emo_sound, snd_ghast_emotion_1, snd_ghast_emotion_2, snd_ghast_emotion_3, snd_ghast_emotion_4)", EventType.Create, 0);

            UndertaleGameObject o_skeleton_knightAxe_z = Msl.AddObject(  //Skeleton Knight Axe  (T5 Undead)
            name: "o_skeleton_knightAxe_z",
            spriteName: "s_skeleton_knightaxe",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_knightAxe_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Knight Axe\")\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Unyielding_Defence\")\r\nscr_create_skill_map(\"Thirst_for_Battle\")\r\nscr_create_skill_passive(o_pass_skill_shieldbreaker)", EventType.Create, 0);

            UndertaleGameObject o_skeleton_knightHammer_z = Msl.AddObject(  //Skeleton Knight Hammer  (T5 Undead)
            name: "o_skeleton_knightHammer_z",
            spriteName: "s_skeleton_knighthammer",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_knightHammer_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Knight Hammer\")\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Thirst_for_Battle\")\r\nscr_create_skill_map(\"Unyielding_Defence\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)", EventType.Create, 0);

            UndertaleGameObject o_skeleton_knightSword_z = Msl.AddObject(  //Skeleton Knight Sword  (T5 Undead)
            name: "o_skeleton_knightSword_z",
            spriteName: "s_skeleton_knightsword",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_knightSword_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Knight Sword\")\r\nscr_create_skill_map(\"Riposte\")\r\nscr_create_skill_map(\"Arc_Cleave\")\r\nscr_create_skill_map(\"Thirst_for_Battle\")\r\nscr_create_skill_map(\"Unyielding_Defence\")\r\nscr_create_skill_passive(o_pass_skill_taste_of_victory)", EventType.Create, 0);

            UndertaleGameObject o_skeleton_guardianSpear_z = Msl.AddObject(  //Skeleton Guardsman Spear (T5 Undead)
            name: "o_skeleton_guardianSpear_z",
            spriteName: "s_skeleton_knightspear",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_guardianSpear_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Guardian Spear\")\r\nscr_create_skill_map(\"Nail_Down\")\r\nscr_create_skill_map(\"Piercing_Lunge\")\r\nscr_create_skill_map(\"Pikemans_Stance\")\r\nscr_create_skill_map(\"Regroup\")\r\nscr_create_skill_map(\"Against_the_Odds\")", EventType.Create, 0);

            UndertaleGameObject o_skeleton_guardianSword_z = Msl.AddObject(  //Skeleton Guardsman Sword (T5 Undead)
            name: "o_skeleton_guardianSword_z",
            spriteName: "s_skeleton_knightswordshield",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_guardianSword_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Guardian Sword\")\r\nscr_create_skill_map(\"Cleave\")\r\nscr_create_skill_map(\"Raise_Shield\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Defensive_Stance\")\r\nscr_create_skill_map(\"Breakthrough\")", EventType.Create, 0);

            UndertaleGameObject o_skeleton_guardianMace_z = Msl.AddObject(  //Skeleton Guardsman Mace (T5 Undead)
            name: "o_skeleton_guardianMace_z",
            spriteName: "s_skeleton_guardianmace",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_guardianMace_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Guardian Mace\")\r\nscr_create_skill_map(\"Armor_Break\")\r\nscr_create_skill_map(\"Onslaught\")\r\nscr_create_skill_map(\"Hammer_and_Anvil\")\r\nscr_create_skill_map(\"Ram\")\r\nscr_create_skill_map(\"Breakthrough\")", EventType.Create, 0);

            UndertaleGameObject o_skeleton_guardianAxe_z = Msl.AddObject(  //Skeleton Guardsman Axe (T5 Undead)
            name: "o_skeleton_guardianAxe_z",
            spriteName: "s_skeleton_guardianaxe",
            parentName: "o_skeleton_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_skeleton_guardianAxe_z", "event_inherited()\r\nscr_bw_param(\"Skeleton Guardian Axe\")\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Reign_in_Blood\")\r\nscr_create_skill_map(\"Against_the_Odds\")\r\n", EventType.Create, 0);

            UndertaleGameObject o_bw_harbinger_madness_z = Msl.AddObject(  //Harbinger of Madness (T5 Undead)
            name: "o_bw_harbinger_madness_z",
            spriteName: "s_bw_heraldzombie",
            parentName: "c_zombie_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            o_bw_harbinger_madness_z.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_harbinger_madness_z_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_harbinger_madness_z_Other_10.gml", EventType.Other, 10)
            );
            Msl.AddNewEvent("o_bw_harbinger_madness_z", "if (global.attack_mode_on || global.unit_inspect_id == id)\r\n    event_inherited()", EventType.Mouse, 4);
            Msl.AddNewEvent("o_bw_harbinger_madness_z", "if (!global.skill_activate)\r\n{\r\n    if (is_visible() && visible)\r\n    {\r\n        if (!(collision_point(global.guiMouseX, global.guiMouseY, c_GUI, 0, 0)))\r\n        {\r\n            if is_allow_actions()\r\n                scr_create_context_menu(\"Attack\", \"Explore\")\r\n        }\r\n    }\r\n}", EventType.Mouse, 5);

            UndertaleGameObject o_bw_harbinger_darkness_z = Msl.AddObject(  //Harbinger Darkness (T5 Undead)
            name: "o_bw_harbinger_darkness_z",
            spriteName: "s_bw_heraldzombie",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            o_bw_harbinger_darkness_z.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_harbinger_darkness_z_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_harbinger_darkness_z_Other_10.gml", EventType.Other, 10)
            );
            Msl.AddNewEvent("o_bw_harbinger_darkness_z", "if (global.attack_mode_on || global.unit_inspect_id == id)\r\n    event_inherited()", EventType.Mouse, 4);
            Msl.AddNewEvent("o_bw_harbinger_darkness_z", "if (!global.skill_activate)\r\n{\r\n    if (is_visible() && visible)\r\n    {\r\n        if (!(collision_point(global.guiMouseX, global.guiMouseY, c_GUI, 0, 0)))\r\n        {\r\n            if is_allow_actions()\r\n                scr_create_context_menu(\"Attack\", \"Explore\")\r\n        }\r\n    }\r\n}", EventType.Mouse, 5);

            UndertaleGameObject o_bw_harbinger_chaos_z = Msl.AddObject(  //Harbinger Chaos (T5 Undead)
            name: "o_bw_harbinger_chaos_z",
            spriteName: "s_bw_heraldzombie",
            parentName: "o_Undead_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            o_bw_harbinger_chaos_z.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_harbinger_chaos_z_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_harbinger_chaos_z_Other_10.gml", EventType.Other, 10)
            );
            Msl.AddNewEvent("o_bw_harbinger_chaos_z", "if (global.attack_mode_on || global.unit_inspect_id == id)\r\n    event_inherited()", EventType.Mouse, 4);
            Msl.AddNewEvent("o_bw_harbinger_chaos_z", "if (!global.skill_activate)\r\n{\r\n    if (is_visible() && visible)\r\n    {\r\n        if (!(collision_point(global.guiMouseX, global.guiMouseY, c_GUI, 0, 0)))\r\n        {\r\n            if is_allow_actions()\r\n                scr_create_context_menu(\"Attack\", \"Explore\")\r\n        }\r\n    }\r\n}", EventType.Mouse, 5);

            // Proselyte Undeads T1

            UndertaleGameObject o_proselyte_bw = Msl.AddObject(  
            name: "o_proselyte_bw",
            spriteName: "",
            parentName: "o_proselyte",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_bw", "event_inherited()\r\nrevivify_dur = 0\r\nalarm[4] = 1\r\nowner = o_player", EventType.Create, 0);
            Msl.AddNewEvent("o_proselyte_bw", "event_inherited()\r\ncorpse_durability = min(100, max(0, corpse_durability))", EventType.Step, 2);
            Msl.AddNewEvent("o_proselyte_bw", "if ((!global.attack_mode_on) && (!keyboard_check(vk_shift)))\r\n{\r\n    with (id)\r\n        scr_voice_text(choose(\"Get... lost\", \"Free... me\", \"Let me die...\", \"Don't ... get close...\"), -4, 16777215, 0, -39, 0)\r\n    scr_actionsLog(\"speech\", [scr_id_get_name(id), scr_actionsLogSpeechFormat(choose(\"Get... lost\", \"Free... me\", \"Let me die...\", \"Don't ... get close...\"))])\r\n}\r\nelse\r\n    event_inherited()", EventType.Mouse, 4);
            Msl.AddNewEvent("o_proselyte_bw", "if (!(scr_instance_exists_in_list(o_b_servemaster, buffs)))\r\n{\r\n    with (self)\r\n        scr_effect_create(o_b_servemaster, revivify_dur, id, id)\r\n}\r\nif scr_instance_exists_in_list(o_b_corpse_dur, buffs)\r\n{\r\n    with (o_b_corpse_dur)\r\n    {\r\n        if (target == other.id)\r\n            other.corpse_durability = duration\r\n    }\r\n}\r\nelse\r\n    scr_effect_create(o_b_corpse_dur, o_damage_dealer, id, id)", EventType.Alarm, 4);

            UndertaleGameObject o_proselyte_apostate_z = Msl.AddObject(  //Proselyte Apostate (T1 Proselyte) (Boss)
            name: "o_proselyte_apostate_z",
            spriteName: "s_proselyte_apostate_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_apostate_z", "event_inherited()\r\ncritDeathAnimationFraction = \"\"\r\nscr_bw_param(\"Proselyte Apostate\")\r\nscr_create_skill_map(\"Bloodletting\")\r\nscr_create_skill_map(\"Curse_of_Weakness\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_smell_of_blood(1)\r\nds_list_clear(weapon_impact)\r\nshadow_spr = s_shadow_medium\r\nshadow_spr_shift = [0, 1]\r\nnetSize = \"high\"\r\ncorpse_sprite = s_proselyte_prophet01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_harbinger_z = Msl.AddObject(  //Proselyte Harbinger (T1 Proselyte)
            name: "o_proselyte_harbinger_z",
            spriteName: "s_proselyte_harbinger_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_harbinger_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Harbinger\")\r\nscr_create_skill_map(\"Scream_of_Doom\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\ncorpse_sprite = s_proselyte_banshee01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_tormentor_z = Msl.AddObject(  //Proselyte Tormentor (T1 Proselyte)
            name: "o_proselyte_tormentor_z",
            spriteName: "s_proselyte_tormentor_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_tormentor_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Tormentor\")\r\nscr_create_skill_map(\"Chain_Strike\")\r\nscr_create_skill_map(\"Bloodletting\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_blood_scent)\r\ncorpse_sprite = s_proselyte_tormentor01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_immolated_z = Msl.AddObject(  //Proselyte Immolated (T1 Proselyte)
            name: "o_proselyte_immolated_z",
            spriteName: "s_proselyte_immolated_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_immolated_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Immolated\")\r\ncorpse_sprite = s_proselyte_immolated01_dead", EventType.Create, 0);

            // Proselyte Undeads T2

            UndertaleGameObject o_proselyte_matriarch_z = Msl.AddObject(  //Proselyte Matriarch (T2 Proselyte) (Boss)
            name: "o_proselyte_matriarch_z",
            spriteName: "s_proselyte_matriarch_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_matriarch_z", "event_inherited()\r\ncritDeathAnimationFraction = \"\"\r\nscr_bw_param(\"Proselyte Matriarch\")\r\nscr_create_skill_map(\"Bloodletting\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_map(\"Gaping_Wound\")\r\nscr_create_skill_map(\"Deflect\")\r\nscr_create_skill_passive(o_enemy_pass_blood_scent)\r\nshadow_spr = s_shadow_big\r\nnetSize = \"high\"\r\nnetOffset = [0, -3]\r\ncorpse_sprite = s_proselyte_matriarch_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_outcast_z = Msl.AddObject(  //Proselyte Outcast (T2 Proselyte)
            name: "o_proselyte_outcast_z",
            spriteName: "s_proselyte_outcast_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_outcast_z", "event_inherited()\r\ncritDeathAnimationFraction = \"\"\r\nscr_bw_param(\"Proselyte Outcast\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_blood_craze)\r\nshadow_spr = s_shadow_medium\r\nshadow_spr_shift = [0, 1]\r\nsuspicious_voice_tag = \"\"\r\nhostile_voice_tag = \"\"\r\nattack_voice_tag = \"\"\r\nskill_voice_tag = \"\"\r\ndead_voice_tag = \"\"\r\ninjury_voice_tag = \"\"\r\nnetSize = \"small\"\r\ncorpse_sprite = s_proselyte_outcast01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_flagellant_z = Msl.AddObject(  //Proselyte Flagellant (T2 Proselyte)
            name: "o_proselyte_flagellant_z",
            spriteName: "s_proselyte_flagellant_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_flagellant_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Flagellant\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_driven_by_pain)\r\ncorpse_sprite = s_proselyte_flagellant01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_toller_z = Msl.AddObject(  //Proselyte Toller (T2 Proselyte)
            name: "o_proselyte_toller_z",
            spriteName: "s_proselyte_toller_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_toller_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Toller\")\r\nscr_create_skill_map(\"For_Whom_the_Bell_Tolls\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\ncorpse_sprite = s_proselyte_toller01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_adept_z = Msl.AddObject(  //Proselyte Adept (T2 Proselyte)
            name: "o_proselyte_adept_z",
            spriteName: "s_proselyte_adept_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_adept_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Adept\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Sacrificial_blood\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\ncorpse_sprite = s_proselyte_adept01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_abomination_z = Msl.AddObject(  //Proselyte Abomination (T3 Proselyte) (Boss)
            name: "o_proselyte_abomination_z",
            spriteName: "s_proselyte_abomination_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_abomination_z", "event_inherited()\r\ncritDeathAnimationFraction = \"\"\r\nscr_bw_param(\"Proselyte Abomination\")\r\nscr_create_skill_map(\"Lacerate\")\r\nscr_create_skill_map(\"Thirst_for_Battle\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_driven_by_pain)\r\nscr_create_skill_passive(o_enemy_pass_blood_craze)\r\nshadow_spr = s_shadow_medium\r\nshadow_spr_shift = [0, 2]\r\nnetSize = \"high\"\r\ncorpse_sprite = s_proselyte_abomination_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_champion_z = Msl.AddObject(  //Proselyte Chosen (T3 Proselyte)
            name: "o_proselyte_champion_z",
            spriteName: "s_proselyte_champion_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_champion_z", "shadow_spr_shift = [0, 1]\r\nevent_inherited()\r\ncritDeathAnimationFraction = \"\"\r\nscr_bw_param(\"Proselyte Champion\")\r\nscr_create_skill_map(\"Swipe\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_map(\"Power_Kick\")\r\nscr_set_kd(\"Swipe\", \"max_KD\", 8, true)\r\ncorpse_sprite = s_proselyte_champion01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_saggul_z = Msl.AddObject(  //Proselyte Saggul (T3 Proselyte)
            name: "o_proselyte_saggul_z",
            spriteName: "s_proselyte_saggul_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_saggul_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Saggul\")\r\ncritDeathAnimationFraction = \"\"\r\nshadow_spr = s_shadow_big\r\nshadow_spr_shift = [1, 1]\r\nimage_speed = 1\r\nnetSize = \"high\"\r\nnetOffset = [0, 0]\r\nnetWaterDeepOffset = [0, 0]\r\nnetWaterDeepDrawLimit = undefined\r\nscr_create_skill_map(\"Blood_Spit\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\ncorpse_sprite = s_proselyte_saggul01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_impaler_z = Msl.AddObject(  //Proselyte Implaer (T3 Proselyte)
            name: "o_proselyte_impaler_z",
            spriteName: "s_proselyte_impaler_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_impaler_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Impaler\")\r\nscr_create_skill_map(\"Bloodletting\")\r\nscr_create_skill_map(\"Piercing_Lunge\")\r\nscr_create_skill_map(\"Sudden_Strike\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_blood_scent)\r\nshadow_spr = s_shadow_medium\r\nshadow_spr_shift = [0, -2]\r\ncorpse_sprite = s_proselyte_impaler01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_hierarch_z = Msl.AddObject(  //Proselyte Sanguimage (T3 Proselyte)
            name: "o_proselyte_hierarch_z",
            spriteName: "s_proselyte_hierarch_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_hierarch_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Hierarch\")\r\nscr_create_skill_map(\"Mark_of_the_Feast\")\r\nscr_create_skill_map(\"Sacrificial_blood\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\ncorpse_sprite = s_proselyte_hierarch01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_brander_z = Msl.AddObject(  //Proselyte Brander (T4 Proselyte) (Boss)
            name: "o_proselyte_brander_z",
            spriteName: "s_proselyte_brander_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_brander_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Brander\")\r\nscr_create_skill_map(\"Brand_of_Anguish\")\r\nscr_create_skill_map(\"Coals_and_Embers\")\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_anthem_of_bloodshed)\r\ncritDeathAnimationFraction = \"\"\r\nisIdleAnimation = true\r\nimage_speed = 1\r\nscr_onUnitEffectCreate(id, o_onUnitEffectBranderLight2, -1, 0, 0, true)\r\nshadow_spr = s_shadow_big\r\nshadow_spr_shift = [0, 0]\r\nresonanceSprite = s_resonance_big\r\nnetSize = \"high\"\r\nnetOffset = [2, -4]\r\nnetWaterDeepOffset = [0, 0]\r\nnetWaterDeepDrawLimit = undefined\r\ncorpse_sprite = s_proselyte_Brander_dead\r\n", EventType.Create, 0);

            UndertaleGameObject o_proselyte_anmara_z = Msl.AddObject(  //Proselyte Anmarak (T4 Proselyte) (Boss)
            name: "o_proselyte_anmara_z",
            spriteName: "s_proselyte_anmarak_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_anmara_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Anmara\")\r\nscr_create_skill_map(\"Fling_Away\")\r\nscr_create_skill_map(\"Swipe\")\r\ncritDeathAnimationFraction = \"\"\r\nshadow_spr = s_shadow_big\r\nshadow_spr_shift = [0, 0]\r\nresonanceSprite = s_resonance_big\r\nnetSize = \"high\"\r\nnetOffset = [2, -3]\r\nnetWaterDeepOffset = [0, 0]\r\nnetWaterDeepDrawLimit = undefined\r\ncorpse_sprite = s_proselyte_Anmara_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_gifted_mace_z = Msl.AddObject(  //Proselyte Fiend Mace (T4 Proselyte) 
            name: "o_proselyte_gifted_mace_z",
            spriteName: "s_proselyte_gifted_mace_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_gifted_mace_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Gifted 2H Mace\")\r\ncritDeathAnimationFraction = \"\"\r\nscr_create_skill_map(\"Mighty_Swing\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Skull_Crusher\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_witness_his_might)\r\nscr_create_skill_passive(o_enemy_pass_anthem_of_bloodshed)\r\ncorpse_sprite = s_proselyte_gifted_mace01", EventType.Create, 0);

            UndertaleGameObject o_proselyte_gifted_axe_z = Msl.AddObject(  //Proselyte Fiend Axe (T4 Proselyte) 
            name: "o_proselyte_gifted_axe_z",
            spriteName: "s_proselyte_gifted_axe_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_gifted_axe_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Gifted 2H Axe\")\r\ncritDeathAnimationFraction = \"\"\r\nscr_create_skill_map(\"Wide_Cut\")\r\nscr_create_skill_map(\"Dismember\")\r\nscr_create_skill_map(\"Reign_in_Blood\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_passive(o_enemy_pass_witness_his_might)\r\nscr_create_skill_passive(o_enemy_pass_anthem_of_bloodshed)\r\nscr_create_skill_passive(o_pass_skill_finish_him)\r\ncorpse_sprite = s_proselyte_gifted_axe01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_girrud_z = Msl.AddObject(  //Proselyte Girrud (T4 Proselyte) 
            name: "o_proselyte_girrud_z",
            spriteName: "s_proselyte_girrud_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_girrud_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Girrud\")\r\nscr_create_skill_map(\"Tongue_Push\")\r\nscr_create_skill_map(\"Tongue_Pull\")\r\nscr_create_skill_map(\"Tongue_Leech\")\r\ncritDeathAnimationFraction = \"\"\r\nshadow_spr = s_shadow_medium\r\nshadow_spr_shift = [0, 1]\r\ncorpse_sprite = s_proselyte_girrud01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_juggernaut_z = Msl.AddObject(  //Proselyte Juggernaut (T5 Proselyte) (Boss)
            name: "o_proselyte_juggernaut_z",
            spriteName: "s_proselyte_juggernaut_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_juggernaut_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Juggernaut\")\r\nscr_create_skill_map(\"Unstoppable_Force\")\r\nscr_create_skill_map(\"Knockout\")\r\nscr_create_skill_map(\"Forceful_Slam\")\r\nscr_create_skill_passive(o_pass_skill_balance_loss)\r\nscr_create_skill_passive(o_pass_skill_heavy_concussion)\r\nscr_create_skill_passive(o_pass_skill_preparation)\r\nscr_create_skill_passive(o_pass_skill_intimidation)\r\nscr_create_skill_passive(o_pass_skill_last_effort)\r\ntentacleId = -4\r\ncritDeathAnimationFraction = \"\"\r\nshadow_spr = s_shadow_big\r\nshadow_spr_shift = [0, 0]\r\nresonanceSprite = s_resonance_big\r\nnetSize = \"high\"\r\nnetOffset = [0, -4]\r\nnetWaterDeepOffset = [0, 0]\r\nnetWaterDeepDrawLimit = undefined\r\ncorpse_sprite = s_proselyte_Juggernaut_dead\r\n", EventType.Create, 0);

            UndertaleGameObject o_proselyte_wormbearer_z = Msl.AddObject(  //Proselyte Wormbearer (T5 Proselyte) (Boss)
            name: "o_proselyte_wormbearer_z",
            spriteName: "s_proselyte_wormbearer_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_wormbearer_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Wormbearer\")\r\ncritDeathAnimationFraction = \"\"\r\nscr_create_skill_map(\"Life_Leech\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nshadow_spr = s_shadow_big\r\nshadow_spr_shift = [0, 1]\r\nresonanceSprite = s_resonance_big\r\nnetSize = \"high\"\r\nnetOffset = [2, -4]\r\nnetWaterDeepOffset = [0, 0]\r\nnetWaterDeepDrawLimit = undefined\r\ncorpse_sprite = s_proselyte_wormbearer_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_yagram_z = Msl.AddObject(  //Proselyte Yagram (T5 Proselyte)
            name: "o_proselyte_yagram_z",
            spriteName: "s_proselyte_yagram_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_yagram_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Yagram\")\r\ncritDeathAnimationFraction = \"\"\r\nscr_create_skill_map(\"Tremor_Strike\")\r\nscr_create_skill_map(\"Swipe\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_map(\"Adrenaline_Rush\")\r\nshadow_spr = s_shadow_big\r\nshadow_spr_shift = [0, 1]\r\nnetSize = \"high\"\r\nnetOffset = [3, -2]\r\nnetWaterDeepOffset = [0, 0]\r\nnetWaterDeepDrawLimit = undefined\r\ncorpse_sprite = s_proselyte_yagram01_dead", EventType.Create, 0);

            UndertaleGameObject o_proselyte_murkstalker_z = Msl.AddObject(  //Proselyte Murkstalker (T5 Proselyte)
            name: "o_proselyte_murkstalker_z",
            spriteName: "s_proselyte_murkstalker_z",
            parentName: "o_proselyte_bw",
            isVisible: true,
            isPersistent: false,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_proselyte_murkstalker_z", "event_inherited()\r\nscr_bw_param(\"Proselyte Murkstalker\")\r\nscr_create_skill_map(\"Embrace_the_Murk\")\r\nscr_create_skill_map(\"Murkwalk\")\r\nscr_create_skill_map(\"Murk_Strike\")\r\nscr_create_skill_map(\"Vampiric_Blood\")\r\nscr_create_skill_map(\"Seize_the_Initiative\")\r\nscr_create_skill_passive(o_enemy_pass_blood_craze)\r\ncritDeathAnimationFraction = \"\"\r\nshadow_spr = s_shadow_medium\r\nshadow_spr_shift = [0, 1]\r\ncorpse_sprite = s_proselyte_murkstalker01_dead", EventType.Create, 0);

            // ==========================================

            Msl.LoadGML("gml_GlobalScript_scr_inventory_weapon_get_params")
                .MatchFrom("scr_weapon_array_get(\"Psimantic_Power\")")
                .InsertBelow("scr_weapon_array_get(\"Necromantic_Power\")")
                .Save();

            // Add New Scripts

            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_immortal_scr.gml"), "scr_bw_immortal_scr");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_aoe_effect.gml"), "scr_bw_aoe_effect");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_weapon_att_add.gml"), "scr_bw_weapon_att_add");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_armor_att_add.gml"), "scr_bw_armor_att_add");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_ai.gml"), "scr_bw_ai");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_turn_end.gml"), "scr_bw_turn_end");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_necromancy_dataloader.gml"), "scr_necromancy_dataloader");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_necromancy_textloader.gml"), "scr_necromancy_textloader");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_targeter_res.gml"), "scr_bw_targeter_res");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_enemydestory.gml"), "scr_bw_enemydestory");
            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_unholy_seal.gml"), "scr_bw_unholy_seal");

            // Setting Components

            Msl.AddMenu("Necromancy", (UIComponent[])(object)new UIComponent[1]
            {
                new UIComponent("Undeads' starting cap\n(More than 1 is cheating)", "servant_starting_number", (UIComponentType)2, (1, 10), 1)
            });

            // Modified Objects

            //Msl.GetObject("o_b_magic_unholy").Sprite = Msl.GetSprite("s_b_sealofpower_unholy");

            Msl.LoadGML("gml_Object_o_b_magic_unholy_Alarm_2")
                .MatchBelow("if (!is_load)", 1)
                .InsertBelow("if is_player(owner)\r\n{\r\nsprite_index = s_bw_b_sealofpower_unholy\r\nname = (global.language == 1 ? \"Печать некромантии\" : \"Seal of Necromancy\")\r\n}")
                .Save();

            // Edit Already-Existing Object Events 

            Msl.LoadGML("gml_Object_o_corpse_Alarm_1").MatchAll().ReplaceBy(ModFiles, "gml_Object_o_corpse_Alarm_1.gml").Save();
            Msl.LoadGML("gml_Object_o_corpse_Step_0").MatchAll().ReplaceBy(ModFiles, "gml_Object_o_corpse_Step_0.gml").Save();

            Msl.GetObject("o_corpse").ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_corpse_Other_13.gml", EventType.Other, 13)
            );

            Msl.LoadGML("gml_Object_o_skillmenu_Create_0").MatchBelow("var _metaCategoriesArray =", 0).InsertBelow(@"var _sus = []
                                                                                                                    for (var _kr = 0; _kr < array_length(_metaCategoriesArray[2]); _kr++)
                                                                                                                    {
                                                                                                                        array_push(_sus, _metaCategoriesArray[2][_kr])
                                                                                                                        if (_metaCategoriesArray[2][_kr] == o_skill_category_arcanistics)
                                                                                                                            array_push(_sus, o_skill_category_necromancy)
                                                                                                                    }
                                                                                                                    for (var _kj = 0; _kj < array_length(_sus); _kj++)
                                                                                                                        array_set(_metaCategoriesArray[2], _kj, _sus[_kj])").Save();

            UndertaleGameObject o_bw_attitude_menu = Msl.AddObject(
            name: "o_bw_attitude_menu",
            spriteName: "s_bw_att_menu",
            parentName: "o_guiContainer",
            isVisible: true,
            isPersistent: true,
            isAwake: true,
            collisionShapeFlags: CollisionShapeFlags.Circle
            );
            Msl.AddNewEvent("o_bw_attitude_menu", "event_inherited()\r\ndepth = -12110\r\nactive = false\r\nalarm[0] = 5\r\nvar _attitudesArray = [o_allDeffence_Attitude, o_allAttack_Attitude]\r\nvar _attitudesArrayLength = array_length(_attitudesArray)\r\nvar _startX = 19\r\nvar _startY = 19\r\nvar _offsetX = 0\r\nvar _offsetY = 0\r\nvar _count = 0\r\nfor (var _i = 0; _i < _attitudesArrayLength; _i++)\r\n{\r\n    var _attitude = _attitudesArray[_i]\r\n    _offsetX = 30 * (_i % 2)\r\n    _offsetY = 29 * (_i div 2)\r\n    scr_guiCreateInteractive(id, _attitude, (depth - 1), (_startX + _offsetX), (_startY + _offsetY))\r\n}\r\nevent_user(2)\r\n", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_attitude_menu", "active = true\r\nevent_user(2)\r\n", EventType.Alarm, 0);
            Msl.AddNewEvent("o_bw_attitude_menu", "if (!active)\r\n{\r\n    event_user(1)\r\n    audio_play_sound(snd_ui_open_window_st, 1, 0)\r\n}\r\nelse\r\n{\r\n    event_user(2)\r\n    audio_play_sound(snd_ui_close_window_st, 1, 0)\r\n}\r\n", EventType.Other, 10);
            Msl.AddNewEvent("o_bw_attitude_menu", "if active\r\n    event_user(0)\r\n", EventType.Other, 25);
            Msl.AddNewEvent("o_bw_attitude_menu", "if active\r\n{\r\n    active = false\r\n    with (o_Attitude)\r\n        is_draw = false\r\n    scr_guiVisibleUpdate(id, false)\r\n    scr_guiLayoutOffsetUpdate(id, 0, 1000)\r\n}", EventType.Other, 12);
            Msl.AddNewEvent("o_bw_attitude_menu", "if (!active)\r\n{\r\n    active = true\r\n    with (o_Attitude)\r\n        is_draw = true\r\n    scr_guiVisibleUpdate(id, true)\r\n    scr_guiLayoutOffsetUpdate(id, 512, -92)\r\n}\r\n", EventType.Other, 11);

            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_inject_bottompanel.gml"), "scr_bw_inject_bottompanel");

            Msl.LoadAssemblyAsString("gml_Object_o_bottompanel_Create_0").MatchFrom("call.i gml_Script_scr_guiCreateInteractive(argc=5)\r\npopz.v").InsertBelow("call.i gml_Script_scr_bw_inject_bottompanel(argc=0)\r\npopz.v").Save();

            Msl.LoadGML("gml_Object_o_gui_specials_Step_2")
                .MatchBelow("if ((!enter) && (!pressed))", 1)
                .InsertBelow("    with (o_bw_attitude_menu)\r\n    {\r\n        if active\r\n            other.image_index = 2\r\n        else\r\n            other.image_index = 0\r\n    }")
                .Save();

            Msl.LoadGML("gml_Object_o_gui_specials_Other_10")
                .MatchFrom("event_user(0)")
                .InsertBelow("with (o_bw_attitude_menu)\r\n    event_user(0)")
                .Save();

            Msl.LoadGML("gml_Object_o_inventory_Other_12")
                .MatchBelow("with (o_attitudes_menu)", 1)
                .InsertBelow("with (o_bw_attitude_menu)\r\n    event_user(15)")
                .Save();

            Msl.LoadGML("gml_Object_o_caravanMenu_Create_0")
                .MatchBelow("with (o_attitudes_menu)", 1)
                .InsertBelow("with (o_bw_attitude_menu)\r\n    event_user(15)")
                .Save();

            Msl.LoadGML("gml_Object_o_close_panel_Create_0")
                .MatchBelow("with (o_attitudes_menu)", 1)
                .InsertBelow("with (o_bw_attitude_menu)\r\n    event_user(2)")
                .Save();

            Msl.LoadGML("gml_Object_o_journal_Other_11")
                .MatchBelow("with (o_attitudes_menu)", 1)
                .InsertBelow("with (o_bw_attitude_menu)\r\n    event_user(15)")
                .Save();

            Msl.LoadGML("gml_Object_o_reward_container_Create_0")
                .MatchBelow("with (o_attitudes_menu)", 1)
                .InsertBelow("with (o_bw_attitude_menu)\r\n    event_user(2)")
                .Save();

            //Msl.LoadGML("gml_Object_o_attitudes_menu_Create_0").MatchBelow("var _attitudesArray =", 0).InsertBelow("var _attitudesArray = [o_allDeffence_Attitude, o_allAttack_Attitude, o_Meditative_Attitude, o_Aggressive_Attitude, o_shout, o_crossbow_charging]").Save();
            //Msl.LoadGML("gml_Object_o_attitudes_menu_Other_11").MatchFrom("scr_guiLayoutOffsetUpdate").ReplaceBy("scr_guiLayoutOffsetUpdate(id, 512, -82)").Save();

            // Edit Already-Existing Scripts

            Msl.LoadGML("gml_GlobalScript_scr_create_context_menu").MatchFrom("case \"Attack\":").InsertAbove(ModFiles, "gml_bwcontext2.gml").Save();
            Msl.LoadGML("gml_Object_o_context_button_Mouse_4").MatchFrom("break").InsertAbove(ModFiles, "gml_bwcontext.gml").Save();

            Msl.LoadGML("gml_Object_o_enemyTransitionsController_Other_10").MatchAll().InsertBelow(ModFiles, "gml_bwtransition.gml").Save();
            Msl.LoadGML("gml_Object_o_enemyTransitionsController_Other_11").MatchBelow("ds_list_delete(_enemiesList, _i)", 1).InsertBelow(ModFiles, "gml_bwtransition2.gml").Save();
            Msl.LoadGML("gml_GlobalScript_scr_enemyArcherChangeToMelee").MatchFrom("scr_set_hl()").InsertBelow("if object_is_ancestor(object_index, o_bw_brigand)\nalarm[4] = 1").Save();
            Msl.LoadGML("gml_GlobalScript_scr_enemyArcherChangeToMelee").MatchFromUntil("unitParamName += \" Melee\"", "HP = _hp").ReplaceBy("_mp = MP\r\nif (object_index == o_bandit_poacher_z)\r\nscr_bw_param(\"Brigand Poacher Melee\", 0)\r\nelse if (object_index == o_bandit_outlaw_z)\r\nscr_bw_param(\"Brigand Outlaw Melee\", 0)\r\nelse if (object_index == o_bandit_marksman_z)\r\nscr_bw_param(\"Brigand Marksman Melee\", 0)\r\nelse if (object_index == o_bandit_ambusher_z)\r\nscr_bw_param(\"Brigand Ambusher Melee\", 0)\r\nelse if (object_index == o_bandit_arbalester_z)\r\nscr_bw_param(\"Brigand Arbalester Melee\", 0)\r\nelse if (object_index == o_bandit_huntmaster_z)\r\nscr_bw_param(\"Brigand Huntmaster Melee\", 0)\r\nelse if (object_index == o_skeleton_bowman_z)\r\nscr_bw_param(\"Skeleton Bowman Melee\", 0)\r\nelse if (object_index == o_skeleton_ranger_z)\r\nscr_bw_param(\"Skeleton Ranger Melee\", 0)\r\nelse if (object_index == o_skeleton_crossbowman_z)\r\nscr_bw_param(\"Skeleton Crossbowman Melee\", 0)\r\nelse\r\nscr_param(unitParamName + \" Melee\", 0)\r\nHP = _hp\r\nMP = _mp").Save();
            Msl.LoadGML("gml_GlobalScript_scr_locationRoomEntityCorpsesSaveDataSet").MatchBelow("Pelt_Durability", 1).InsertBelow("corpse_durability = ds_map_find_value_ext(argument1, \"corpse_dur\", corpse_durability)\ncorpse_level = ds_map_find_value_ext(argument1, \"corpse_lvl\", corpse_level)\nrise_counter = ds_map_find_value_ext(argument1, \"rise_counter\", rise_counter)").Save();
            Msl.LoadGML("gml_GlobalScript_scr_locationRoomEntityCorpsesSaveDataGet").MatchBelow("Pelt_Durability", 1).InsertBelow("ds_map_add(_corpseDataMap, \"corpse_dur\", corpse_durability)\nds_map_add(_corpseDataMap, \"corpse_lvl\", corpse_level)\nds_map_add(_corpseDataMap, \"rise_counter\", rise_counter)").Save();
            Msl.LoadGML("gml_GlobalScript_scr_global_turn_end").MatchBelow("//gml_Script_scr_global_turn_end", 35).InsertBelow("with (o_corpse)\nevent_user(3)").Save();
            Msl.LoadGML("gml_GlobalScript_scr_change_coordinat").MatchFrom("isGround = scr_is_ground_unit(x, y)").InsertBelow("var _sussy_amongus = 0\nif is_player(argument2)\n{\nwith (o_enemy)\n{\nif scr_instance_exists_in_list(o_b_servemaster, buffs)\n_sussy_amongus = 1\n}\nif _sussy_amongus\nscr_allturn()\n}").Save();
            Msl.LoadGML("gml_Object_o_b_magic_unholy_Other_15").MatchFromUntil("{", "}").ReplaceBy("scr_bw_unholy_seal()").Save();
            Msl.LoadGML("gml_GlobalScript_scr_penalty_player_attack").MatchBelow("visible", 1).InsertBelow("if (!(scr_instance_exists_in_list(o_b_servemaster, id.buffs)))").Save();
            Msl.LoadGML("gml_GlobalScript_scr_penalty_enemy_attack").MatchBelow("with (o_enemy)", 1).InsertBelow("if (!(scr_instance_exists_in_list(o_b_servemaster, buffs)))").Save();
            Msl.LoadGML("gml_GlobalScript_scr_skill_tier_init").MatchFrom("armor_tier3").InsertBelow("global.necromancy_tier1 = [\"Necromancy\", o_skill_bw_1_ico, o_skill_bw_2, o_skill_bw_3_ico]\r\nglobal.necromancy_tier2 = [\"Necromancy\", o_skill_bw_4_ico, o_skill_bw_5, o_skill_bw_6, o_skill_bw_7_ico]\r\nglobal.necromancy_tier3 = [o_skill_bw_8, o_skill_bw_9_ico, o_skill_bw_10]\r\nglobal.necromancy_tier4 = [o_skill_bw_11, o_skill_bw_12_ico, o_skill_bw_13, o_skill_bw_14_ico]").Save();
            Msl.LoadGML("gml_Object_o_pass_skill_spirit_and_body_Other_13").MatchBelow("scr_temp_effect_update(object_index, owner, \"CRT\"", 2).InsertBelow("if (!is_enemy_skill)\r\n{\r\nif (instance_exists(o_pass_skill_kingdead) && o_pass_skill_kingdead.is_open)\r\n{\r\nif is_attack_skill\r\n{\r\n}\r\nelse if instance_exists(o_player)\r\n{\r\nwith (o_unit)\r\n{\r\nif ((!is_player()) && is_visible() && faction_key != \"Servant\")\r\ninstance_create_depth(x, y, -5000, o_archtheurgy_impact)\r\n}\r\n}\r\n}\r\nif is_attack_skill\r\n{\r\n}\r\nelse if (!global.bw_selection)\r\n{\r\nwith (o_b_charged_soul)\r\nevent_user(4)\r\n}\r\nglobal.bw_selection = 0\r\n}").Save();
            Msl.LoadGML("gml_GlobalScript_scr_skill_reparse_locked").MatchBelow("if (level_left > 0)", 1).InsertBelow("_text =  (level_to_open > 30 && global.language = 1 ? \"\" : level_to_open > 30 && global.language != 1 ? \"Perform the corresponding ritual to unlock this ability.\" : _text)  ").Save();
            Msl.LoadGML("gml_GlobalScript_scr_global_turn_end").MatchBelow("with (o_explosion)", 1).InsertBelow("scr_bw_turn_end()").Save();
     
            // Assembly Edit

            Msl.LoadAssemblyAsString("gml_Object_o_unit_Create_0").MatchFrom(":[0]").InsertBelow("pushi.e 100\r\npop.v.i self.corpse_durability\r\npushi.e 0\r\npop.v.i self.Necromantic_Power\r\npushi.e 0\r\npop.v.i self.bNecromantic_Power\r\npushi.e 0\r\npop.v.i self.Necromantic_Miscast_Chance").Save();
            Msl.LoadAssemblyAsString("gml_Object_o_abstract_corpse_Create_0").MatchFrom("pop.v.v self.isGround").InsertBelow("pushi.e 1\r\npop.v.i self.BW_res\r\npushi.e 0\r\npop.v.i self.corpse_level\r\npushi.e 0\r\npop.v.i self.rise_counter\r\npushi.e -4\r\npop.v.i self.corpse_durability\r\npushi.e 0\r\npop.v.i self.in_range\r\npushi.e 0\r\npop.v.i self.in_range2").Save();
            Msl.LoadAssemblyAsString("gml_Object_o_enemy_Destroy_0").MatchBelow("unitParamName", 1).InsertBelow("pushi.e 1\r\nconv.i.v\r\ncall.i gml_Script_scr_bw_enemydestroy(argc=1)\r\npopz.v").Save();
            Msl.LoadAssemblyAsString("gml_Object_o_enemy_Destroy_0").MatchBelow("event_inherited", 1).InsertBelow("pushi.e 2\r\nconv.i.v\r\ncall.i gml_Script_scr_bw_enemydestroy(argc=1)\r\npopz.v").Save();
            Msl.LoadAssemblyAsString("gml_Object_o_dataLoader_Other_10").MatchBelow("Jonna", 9).InsertBelow("call.i gml_Script_scr_necromancy_dataloader(argc=0)\r\npopz.v").Save();
            Msl.LoadAssemblyAsString("gml_Object_o_textLoader_Other_25").MatchFrom("pushglb.v global.attribute_order_all_without_damage\r\ncall.i ds_list_add(argc=16)\r\npopz.v").InsertBelow("call.i gml_Script_scr_necromancy_textloader(argc=0)\r\npopz.v").Save();
            Msl.LoadAssemblyAsString("gml_Object_o_player_Step_0").MatchFrom("pushglb.v global.playerNoPain").InsertAbove("call.i gml_Script_scr_bw_immortal_scr(argc=0)\r\npopz.v").Save();

            // Add player F5
            // Debug

            //Msl.InsertGMLString("scr_effect_create(o_b_newfound_power, 1, o_player, o_player, 0)", "gml_Object_o_player_KeyPress_116", 0);

            // New events for new objects 

            Msl.AddFunction(ModFiles.GetCode("gml_GlobalScript_scr_bw_targeter.gml"), "scr_bw_targeter");

            Msl.AddNewEvent("o_bw_lifeleech", "Bodypart_Damage = 0\r\nimage_speed = 0\r\nalarm[0] = 1\r\nscr_damage_init()\r\nname = \"Life Leech\"", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_lifeleech", "with (owner)\r\n{\r\n    scr_guiAnimation_ext(x, y, s_lifelech_impact_caster, 1, 1, 0, c_white, 0)\r\n    scr_lifesteal(other.steal, id, 100)\r\n    scr_audio_play_at(snd_life_leech_impact)\r\n}\r\ninstance_destroy()", EventType.Alarm, 1);
            Msl.AddNewEvent("o_bw_lifeleech", "var LVL = 2\r\nvar damage = 0\r\nUnholy_Damage = 6 * (100 + owner.Necromantic_Power) * 0.01\r\ndamage = scr_skill_damage()\r\nwith (owner)\r\n{\r\n    with (target)\r\n        scr_guiAnimation_ext(x, y, 1685, 1, 1, 0, 16777215, 0)\r\n    diss = -200 - random(50)\r\n}\r\nsteal = damage\r\nalarm[1] = 2", EventType.Alarm, 0);

            Msl.AddNewEvent("o_bw_aoe_range", "image_speed = 0\r\ndepth = (-y) + 42\r\nalarm[0] = 2\r\nimage_alpha = 0.5\r\ndelete_on_line = 0\r\ngrid_x = x div 26\r\ngrid_y = y div 26\r\nrange = 1\r\nis_change = 1\r\nif (x > room_width || y > room_height)\r\n    instance_destroy()", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_aoe_range", "instance_destroy()", EventType.Alarm, 1);
            Msl.AddNewEvent("o_bw_aoe_range", "", EventType.Alarm, 0);
            Msl.AddNewEvent("o_bw_aoe_range", "if instance_exists(o_ancientTroll_dead)\r\n{\r\n    if place_meeting(x, y, o_ancientTroll_dead)\r\n        is_change = 0\r\n}\r\nif is_change\r\n{\r\n    if (scr_pat_prototype(x, y, 0, 0) && (!(ds_grid_get_ext(o_controller.posgrid, (x div 26), (y div 26)))))\r\n        instance_destroy()\r\n    if visible_check\r\n    {\r\n        if (!is_visible())\r\n            instance_destroy()\r\n    }\r\n    is_change = 0\r\n}\r\nvisible = 1\r\ngrid_x = x div 26\r\ngrid_y = y div 26\r\nif (!instance_exists(o_aoe_range))\r\n    instance_destroy()", EventType.Step, 0);
            Msl.AddNewEvent("o_bw_aoe_range", "if global.UI_is_on\r\n{\r\n    image_index = scr_autotiling()\r\n    draw_self()\r\n    image_blend = c_red\r\n}", EventType.Draw, 0);

            Msl.AddNewEvent("o_skill_bw_leech", "event_inherited()\r\ndistance_check = false\r\nskill = \"Distracting_Shot\"\r\nxx = 0\r\nis_disposable = false\r\nbutton = \"\"\r\nSpecial_Bonus_Range = 0\r\nis_missile = false\r\nscr_skill_atr(7)\r\npointed = \"Target Object\"\r\nspell = o_arrow\r\nMPcost = 0\r\nbase_range = 4\r\nlock_movement = true\r\nalarm[1] = 5\r\nskill_is_invisible = true\r\nclick_snd = -4\r\ntarget_group = o_corpse\r\nignore_interact = true\r\nis_moving = 1\r\nself_cast = 0", EventType.Create, 0);
            Msl.AddNewEvent("o_skill_bw_leech", "with (o_player)\r\n    lock_movement = false\r\nrange = (base_range + owner.Bonus_Range)\r\nevent_user(2)\r\nif (instance_exists(o_skill_bw_2) && o_skill_bw_2.is_open)\r\nscr_bw_aoe_effect(o_player, 2, 2)", EventType.Alarm, 1);
            Msl.AddNewEvent("o_skill_bw_leech", "event_inherited()\r\ndepth = scr_round_cell((-mouse_y) + 22)", EventType.Step, 0);
            Msl.AddNewEvent("o_skill_bw_leech", "event_inherited()\r\nMPcost = 0\r\n", EventType.Other, 17);
            Msl.AddNewEvent("o_skill_bw_leech", "if (instance_exists(o_player) && instance_exists(target))\r\n{\r\n    with (instance_create_depth(x, y, depth, o_bw_essence_leech))\r\n    {\r\n        owner = o_player\r\n        target = other.target\r\n    }\r\n}\r\nevent_user(15)\r\nscr_allturn()", EventType.Other, 13);
            Msl.AddNewEvent("o_skill_bw_leech", "", EventType.Other, 15);
            Msl.AddNewEvent("o_skill_bw_leech", "with (o_player)\r\n    scr_setside(o_floor_target)\r\nvar _cur = s_cursor_skill\r\nif (pointed == \"Target Object\" || pointed == \"Target Ally\")\r\n    _cur = scr_bw_targeter()\r\nwith (o_floor_target)\r\n    cursor = _cur", EventType.Other, 19);
            Msl.AddNewEvent("o_skill_bw_leech", "event_inherited()\r\ninstance_destroy()\r\n", EventType.Other, 25);

            Msl.AddNewEvent("o_bw_cursebirth", "event_inherited()\r\nscr_set_lt()\r\nimage_speed = 1\r\nblend = make_colour_rgb(191, 0, 0)\r\ndepth = (-y)\r\nspell = o_bw_curse\r\nis_flying = false\r\ncan_reflect = true\r\nscr_audio_play_at(snd_shadow_casting_1)", EventType.Create, 0);

            Msl.AddNewEvent("o_bw_curse", "event_inherited()\r\nscr_set_lt()\r\ninstance_create_depth(x, y, (depth + 15), o_bw_curse_bg)\r\nblend = make_colour_rgb(191, 0, 0)\r\ndx = 13\r\ndy = 13\r\nscr_audio_play_at(choose(snd_debuff_weakness_apply_st_1, snd_debuff_weakness_apply_st_2))", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_curse", "var _dur = 9\r\nif (instance_exists(owner) && is_crit)\r\n    _dur *= max(1, (owner.Miracle_Power / 100))\r\nscr_effect_create(o_db_demise_curse, _dur, target, owner)\r\nscr_allturn()\r\nevent_inherited()", EventType.Other, 7);
            Msl.AddNewEvent("o_bw_curse", "draw_self()", EventType.Draw, 0);

            Msl.AddNewEvent("o_bw_curse_bg", "scr_set_lt()\r\nimage_blend = c_teal", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_curse_bg", "instance_destroy()", EventType.Other, 7);

            Msl.AddNewEvent("o_db_demise_curse", "event_inherited()\r\nif (global.language == 1)\r\n{\r\n    name = \"\"\r\n    mid_text = \"\"\r\n}\r\nelse\r\n{\r\n    name = \"Curse of Demise\"\r\n    mid_text = \"~w~I~/~ stack: each turn deals ~ur~Unholy Damage~/~ and worsens the condition of the same body part by ~r~0.066%~/~ for each percent of ~w~Magic Resistance~/~ and ~w~Unholy Resistance~/~.\n\n~lg~Doubles~/~ the damage if the caster is adjacent.\"\r\n}\r\nduration = 1\r\nDamage = 0\r\nbuff_snd = -4\r\nmax_duration = 36\r\nstage = 1\r\npreviousStage = stage\r\nmax_stage = 3\r\nhave_stages = true", EventType.Create, 0);
            Msl.AddNewEvent("o_db_demise_curse", "event_inherited()\r\nevent_user(5)", EventType.Alarm, 2);
            Msl.AddNewEvent("o_db_demise_curse", "event_inherited()\r\nds_map_clear(data)\r\nwith (target)\r\n{\r\n    ds_map_add(other.data, \"max_hp\", (-0.09 * max_hp * other.stage))\r\n    ds_map_add(other.data, \"Damage_Received\", (3 * other.stage))\r\n    ds_map_add(other.data, \"Magic_Resistance\", (-5 * other.stage))\r\n    ds_map_add(other.data, \"Fortitude\", (-7 * other.stage))\r\n    ds_map_add(other.data, \"Bleeding_Resistance\", (-13 * other.stage))\r\n}", EventType.Other, 15);
            Msl.AddNewEvent("o_db_demise_curse", "event_inherited()\r\nvar _count = 1\r\nwith (o_enemy)\r\n{\r\n    if (scr_tile_distance(id, other.target) == 1 && scr_instance_exists_in_list(o_b_servemaster, buffs))\r\n        _count++\r\n}\r\nvar _caster_near = false\r\nif (scr_tile_distance(owner, target) == 1)\r\n    _caster_near = true\r\n_count = min(3, max(1, _count))\r\nstage = _count\r\nevent_user(5)\r\nif (stage == 1)\r\n{\r\n    Unholy_Damage = math_round(2 * (100 + owner.Necromantic_Power) / 100)\r\n    if _caster_near\r\n        Unholy_Damage *= 2\r\n    Armor_Piercing = 23 + owner.PRC\r\n    Bodypart_Damage = 23 + (owner.Magic_Power + owner.Necromantic_Power) * 0.1\r\n    var _dmg = scr_damage_with_calc(target)\r\n    with (target)\r\n        scr_injuryChange(id, scr_choose_body_part(), (-((0.066 * (bUnholy_Resistance + bMagic_Resistance)))))\r\n}", EventType.Other, 10);

            o_b_newfound_power.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_b_newfound_power_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_b_newfound_power_Other_15.gml", EventType.Other, 15)
            );

            Msl.AddNewEvent("o_b_newfound_power", "event_inherited()\r\nname = (global.language == 1 ? \"\" : \"Otherworldly Link\")\r\nmid_text = \"~lg~+0.005%~/~ Sit.Morale Change.\\n~r~-0.0005~/~ Sit.Sanity Change per each learned ~sy~Necromantic~/~ ability.\\n\\n~r~Prevents~/~ from receiving other blessings and ~lg~positive~/~ psyche effects as well as ~lg~Vigor~/~ from sleeping.\\n\\nDesecrating graves, unholy altars, killing humans and taking ~ur~Unholy Damage~/~ no longer impacts ~lg~Sanity~/~ and ~lg~Morale~/~.\\n\\nBy clicking on this icon, once per ~sy~5~/~ turns allows to leech essence from a targeted corpse or ~y~Servant~/~, ~r~depleting~/~ 25-33% of their ~sy~Body Condition~/~, then grants an additional stack to the effect (up to ~r~IV~/~):\\n\\n~lg~+9%~/~ Necromantic Power\\n~lg~-6%~/~ Spells Energy Cost\\n~lg~-3%~/~ Damage Taken\n\nEvery ~sy~33~/~ turns ~r~reduces~/~ the number of stacks.\"\r\nstage = 0\r\nmax_stage = 4\r\nhave_duration = false\r\ndraw_duration = false\r\nhave_stages = true\r\nstage_sprite = s_bw_stage_sprite\r\ncooldown_time = 0\r\nstage_time = 0\r\nimage_speed = 0\r\nsnd_loop = -4\r\nturn_count = 0\r\nhp_decr = 0\r\nobs_cooldown = 0", EventType.Create, 0);
            Msl.AddNewEvent("o_b_newfound_power", "event_inherited()\r\nevent_user(5)", EventType.Alarm, 2);
            Msl.AddNewEvent("o_b_newfound_power", "", EventType.Alarm, 9);
            //Msl.AddNewEvent("o_b_newfound_power", "event_inherited()\r\nif (keyboard_check(ord(global.bw_essence_leech)) && alarm[9] == -1 && is_allow_actions() && !instance_exists(o_skill_bw_leech) && cooldown_time <= 0)\r\n{\r\n    scr_use_consum_skill(5040, o_skill_bw_leech, false)\r\n    alarm[9] = 15\r\n}\r\n", EventType.Step, 0);
            //Msl.AddNewEvent("o_b_newfound_power", "if collision_point(global.guiMouseX, global.guiMouseY, object_index, 0, 0) && is_allow_actions() && !instance_exists(o_skill_bw_leech) && cooldown_time <= 0\r\n    scr_use_consum_skill(o_player, o_skill_bw_leech, false)", EventType.Mouse, 53);
            Msl.AddNewEvent("o_b_newfound_power", "if sprite_exists(sprite_index)\r\n{\r\n    if is_enemy_modificator\r\n    {\r\n        if (global.GFX && shine != 0)\r\n        {\r\n            shader_set(sh_whiteblend)\r\n            shader_set_uniform_f(white_col, shine)\r\n            scr_drawSpriteClipped(sprite_index, image_index, x, y, guiVisibleAreaBorderLeft, guiVisibleAreaBorderTop, guiVisibleAreaBorderRight, guiVisibleAreaBorderBottom, image_xscale, image_yscale, image_blend, image_alpha)\r\n            shader_reset()\r\n        }\r\n        else\r\n            scr_drawSpriteClipped(sprite_index, image_index, x, y, guiVisibleAreaBorderLeft, guiVisibleAreaBorderTop, guiVisibleAreaBorderRight, guiVisibleAreaBorderBottom, image_xscale, image_yscale, image_blend, image_alpha)\r\n        if (draw_duration && duration > 0)\r\n            scr_drawTextClipped((x - sprite_xoffset + sprite_width + 1), (y - sprite_yoffset + sprite_height - 2), duration, 11, guiVisibleAreaBorderTop, guiVisibleAreaBorderBottom, c_white, global.f_dmg, fa_right, fa_middle)\r\n        if have_stages\r\n        {\r\n            var _scaleX = 1.5 * image_xscale - textTransform / 2\r\n            var _scaleY = 1.5 * image_yscale - textTransform / 2\r\n            scr_drawSpriteClipped(stage_sprite, (stage - 1), (x - sprite_xoffset + sprite_width + 1), (y - sprite_yoffset + 2), guiVisibleAreaBorderLeft, guiVisibleAreaBorderTop, guiVisibleAreaBorderRight, guiVisibleAreaBorderBottom, _scaleX, _scaleY, c_white, textTransform)\r\n        }\r\n    }\r\n    else\r\n    {\r\n        if (global.GFX && shine != 0)\r\n        {\r\n            shader_set(sh_whiteblend)\r\n            shader_set_uniform_f(white_col, shine)\r\n            draw_self()\r\n            shader_reset()\r\n        }\r\n        else\r\n            draw_self()\r\n        if (draw_duration && duration > 0)\r\n            scr_drawText((x - sprite_xoffset + sprite_width + 1), (y - sprite_yoffset + sprite_height - 2), duration, c_white, fa_right, fa_middle)\r\n        if (cooldown_time > 0)\r\n        {\r\n            scr_drawText((x - sprite_xoffset + sprite_width + 1), (y - sprite_yoffset + sprite_height - 2), cooldown_time, c_white, fa_right, fa_middle)\r\n            image_index = 1\r\n        }\r\n        else\r\n            image_index = 0\r\n        if have_stages\r\n        {\r\n            _scaleX = 1.5 * image_xscale - textTransform / 2\r\n            _scaleY = 1.5 * image_yscale - textTransform / 2\r\n            draw_sprite_ext(stage_sprite, stage, (x - sprite_xoffset + sprite_width), (y - sprite_yoffset + 2), _scaleX, _scaleY, 0, c_white, textTransform)\r\n        }\r\n    }\r\n}", EventType.Draw, 0);

            Msl.AddNewEvent("o_bw_essence_leech", "event_inherited()\r\nalarm0_delay = 27\r\nalarm[9] = 54", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_essence_leech", @"var _33 = ((instance_exists(o_skill_bw_10) && o_skill_bw_10.is_open) ? 26 : 33)
            var _25 = ((instance_exists(o_skill_bw_10) && o_skill_bw_10.is_open) ? 20 : 25)
            if (instance_exists(owner) && instance_exists(target))
            {
                var _is_special = false
                var _targ = target
                with (target)
                {
                    if (object_index != o_corpse && scr_instance_exists_in_list(o_b_servemaster, buffs))
                    {
                        with (scr_guiAnimation(s_essence_leech_hit, 1, 1, 0))
                            scr_set_lt()
                        scr_audio_play_at(snd_skill_essence_leech_hit)
                        corpse_durability -= irandom_range(_25, _33)
                    }
                    else if (object_index != o_corpse)
                    {
                        _is_special = true
                        with (instance_create_depth(x, y, depth, o_bw_lifeleech))
                        {
                            owner = o_player
                            target = _targ
                            is_fumble = false
                            var _sus = scr_chance_value(o_player.Miracle_Chance)
                            is_crit = _sus
                        }
                    }
                    if (object_index == o_corpse)
                    {
                        corpse_durability -= irandom_range(_25, _33)
                        scr_guiAnimation_ext(x, y, s_signofdarkness_impact)
                        scr_guiAnimation_ext(x, y, s_signofdarkness_impact_lt)
                        diss = 80
                        scr_unitInterractImpact()
                        inside_particles = o_empty
                        scr_audio_play_at(snd_meat_blood_death_1)
                        var luft = 10
                        if (corpse_durability <= 0)
                        {
                            repeat (20)
                            {
                                with (instance_create_depth((x + 26 + (random_range((-luft), luft))), (y + (random_range((-luft), luft))), 0, o_bloodpart))
                                    speed = 0
                                with (instance_create_depth((x - 26 + (random_range((-luft), luft))), (y + (random_range((-luft), luft))), 0, o_bloodpart))
                                    speed = 0
                                with (instance_create_depth((x + 26 + (random_range((-luft), luft))), (y + 26 + (random_range((-luft), luft))), 0, o_bloodpart))
                                    speed = 0
                                with (instance_create_depth((x - 26 + (random_range((-luft), luft))), (y - 26 + (random_range((-luft), luft))), 0, o_bloodpart))
                                    speed = 0
                                with (instance_create_depth((x - 26 + (random_range((-luft), luft))), (y + 26 + (random_range((-luft), luft))), 0, o_bloodpart))
                                    speed = 0
                                with (instance_create_depth((x + 26 + (random_range((-luft), luft))), (y - 26 + (random_range((-luft), luft))), 0, o_bloodpart))
                                    speed = 0
                                with (instance_create_depth((x + (random_range((-luft), luft))), (y - 26 + (random_range((-luft), luft))), 0, o_bloodpart))
                                    speed = 0
                                with (instance_create_depth((x + (random_range((-luft), luft))), (y + 26 + (random_range((-luft), luft))), 0, o_bloodpart))
                                    speed = 0
                            }
                            instance_destroy()
                            instance_create_depth(x, y, 0, o_explosion_hole)
                        }
                    }
                }
                with (owner)
                {
                    var _essence = scr_instance_exists_in_list(o_b_newfound_power)
                    if _essence
                    {
                        if (!_is_special)
                        {
                            with (_essence)
                            {
                                duration = 5
                                stage++
                                cooldown_time = 6
                                stage_time = 34
                                event_user(5)
                            }
                        }
                        else if (object_is_ancestor(other.target.object_index, o_Undead) || ((!(object_is_ancestor(other.target.object_index, o_Undead))) && scr_chance_value(100)))
                        {
                            with (_essence)
                            {
                                duration = 5
                                stage++
                                cooldown_time = 6
                                stage_time = 34
                                event_user(5)
                            }
                        }
                        else
                        {
                            with (_essence)
                                cooldown_time = 6
                        }
                    }
                }
            }
            else
                instance_destroy()", EventType.Alarm, 0);
            Msl.AddNewEvent("o_bw_essence_leech", "event_inherited()\r\nwith (owner)\r\n{\r\n    with (scr_guiAnimation(s_essence_leech_cast, 1, 1, 0))\r\n        scr_set_lt()\r\n    scr_audio_play_at(snd_skill_essence_leech_cast)\r\n}", EventType.Alarm, 10);
            Msl.AddNewEvent("o_bw_essence_leech", "with (owner)\r\n{\r\n    with (scr_guiAnimation(s_essence_leech_buff, 1, 1, 0))\r\n        scr_set_lt()\r\n    scr_audio_play_at(snd_skill_essence_leech_buff)\r\n}\r\ninstance_destroy()", EventType.Alarm, 9);

            Msl.LoadGML("gml_Object_c_roadAltar_Other_10")
                .MatchFrom("var _playerRaceKey = scr_atr(\"raceKey\")")
                .InsertAbove("if scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs)\r\n    return;")
                .Save();

            Msl.LoadGML("gml_Object_o_player_Other_12")
                .MatchFrom("_is_create_block = true")
                .InsertBelow("if (scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs) && (_create_object == o_state_secondwind || _create_object == o_state_heroism || _create_object == o_state_optimism))\r\n            _is_create_block = true")
                .Save();

            Msl.LoadGML("gml_GlobalScript_scr_psy_change")
                .MatchFrom("argument2 = \"\"")
                .InsertBelow("if (scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs) && (argument2 == \"interactive_grave\" || argument2 == \"hand_digging\" || argument2 == \"cryptgrimoire\" || argument2 == \"unholy_damage\" || argument2 == \"church_corpsepile\" || argument2 == \"contract_grimoir\" || argument2 == \"enemy_death_human\"))\r\n        return;")
                .Save();

            Msl.LoadGML("gml_GlobalScript_scr_actionsLogSleep")
                .MatchFrom("else if scr_globaltile_situation_exists(\"nightmares\")")
                .ReplaceBy("else if scr_globaltile_situation_exists(\"nightmares\") || scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs)")
                .Save();

            Msl.LoadGML("gml_Object_o_sleepController_Other_10").MatchFrom("if (!scr_globaltile_situation_exists(\"nightmares\"))").ReplaceBy("if !scr_globaltile_situation_exists(\"nightmares\") && !scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs)").Save();
            Msl.LoadGML("gml_Object_o_sleepController_Other_12").MatchFrom("if (!scr_globaltile_situation_exists(\"nightmares\"))").ReplaceBy("if !scr_globaltile_situation_exists(\"nightmares\") && !scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs)").Save();
            Msl.LoadGML("gml_Object_o_sleepController_Other_13").MatchFrom("if (!scr_globaltile_situation_exists(\"nightmares\"))").ReplaceBy("if !scr_globaltile_situation_exists(\"nightmares\") && !scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs)").Save();
            Msl.LoadGML("gml_Object_o_sleepController_Other_15").MatchFrom("if (!scr_globaltile_situation_exists(\"nightmares\"))").ReplaceBy("if !scr_globaltile_situation_exists(\"nightmares\") && !scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs)").Save();

            //Necromancer Drop Item

            Msl.AddNewEvent("o_occultist", "event_inherited()\r\nscr_loot(o_loot_occult_text1, x, y, 100)", EventType.Destroy, 0); //T1

            Msl.AddNewEvent("o_necromancer", "event_inherited()\r\nscr_loot(o_loot_occult_text2, x, y, 100)", EventType.Destroy, 0); //T2
            Msl.AddNewEvent("o_archivist", "event_inherited()\r\nscr_loot(o_loot_occult_text2, x, y, 100)", EventType.Destroy, 0); //T2

            Msl.AddNewEvent("o_armored_husk", "event_inherited()\r\nscr_loot(o_loot_occult_text3, x, y, 100)", EventType.Destroy, 0); //T3
            Msl.AddNewEvent("o_ritualist", "event_inherited()\r\nscr_loot(o_loot_occult_text3, x, y, 100)", EventType.Destroy, 0); //T3
            Msl.AddNewEvent("o_undertaker", "event_inherited()\r\nscr_loot(o_loot_occult_text3, x, y, 100)", EventType.Destroy, 0); //T3

            Msl.AddNewEvent("o_mortician", "event_inherited()\r\nscr_loot(o_loot_occult_text4, x, y, 100)", EventType.Destroy, 0); //T4
            Msl.AddNewEvent("o_restless_hero", "event_inherited()\r\nscr_loot(o_loot_occult_text4, x, y, 100)", EventType.Destroy, 0); //T4
            Msl.AddNewEvent("o_crypt_warden", "event_inherited()\r\nscr_loot(o_loot_occult_text4, x, y, 100)", EventType.Destroy, 0); //T4

            // Amogsus

            o_bw_brigand.ApplyEvent(ModFiles,
            new MslEvent("gml_bwessenceleech.gml", EventType.Mouse, 5)
            );
            o_Undead_bw.ApplyEvent(ModFiles,
            new MslEvent("gml_bwessenceleech.gml", EventType.Mouse, 5)
            );
            o_Specter_bw.ApplyEvent(ModFiles,
            new MslEvent("gml_bwessenceleech.gml", EventType.Mouse, 5)
            );
            c_zombie_bw.ApplyEvent(ModFiles,
            new MslEvent("gml_bwessenceleech.gml", EventType.Mouse, 5)
            );
            c_ghoul_bw.ApplyEvent(ModFiles,
            new MslEvent("gml_bwessenceleech.gml", EventType.Mouse, 5)
            );
            o_skeleton_bw.ApplyEvent(ModFiles,
            new MslEvent("gml_bwessenceleech.gml", EventType.Mouse, 5)
            );
            o_proselyte_bw.ApplyEvent(ModFiles,
            new MslEvent("gml_bwessenceleech.gml", EventType.Mouse, 5)
            );

            //New Skill Codes

            o_skill_bw_1.ApplyEvent(ModFiles, //Ruination
            new MslEvent("gml_Object_o_skill_bw_darkbolt_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_darkbolt_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_skill_bw_darkbolt_Other_17.gml", EventType.Other, 17)
            );
            o_skill_bw_1_ico.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_darkbolt_ico_Create_0.gml", EventType.Create, 0)
            );

            o_skill_bw_2.ApplyEvent(ModFiles, //Soul Reap
            new MslEvent("gml_Object_o_skill_bw_2_Create_0.gml", EventType.Create, 0)
            );
            Msl.AddNewEvent("o_skill_bw_2", "event_inherited()", EventType.Other, 13);
            Msl.AddNewEvent("o_skill_bw_2", "if instance_exists(owner)\r\n{\r\n    ds_map_replace(text_map, \"Unholy_Damage\", (6 * (owner.Magic_Power + owner.Necromantic_Power) * 0.01))\r\n    ds_map_replace(text_map, \"Chance\", (owner.WIL + 23))\r\n}\r\nevent_inherited()", EventType.Other, 17);

            o_skill_bw_3.ApplyEvent(ModFiles, //Curse of Demise
            new MslEvent("gml_Object_o_skill_bw_curse_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_curse_Other_17.gml", EventType.Other, 17),
            new MslEvent("gml_Object_o_skill_bw_curse_Other_13.gml", EventType.Other, 13)
            );
            o_skill_bw_3_ico.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_curse_ico_Create_0.gml", EventType.Create, 0)
            );

            o_skill_bw_7.ApplyEvent(ModFiles, //Resurrection
            new MslEvent("gml_Object_o_skill_bw_resurrection_Create_0.gml", EventType.Create, 0)
            );
            Msl.AddNewEvent("o_skill_bw_7", "event_inherited()\r\nvar _crit = is_crit\r\nvar _own = owner\r\nif instance_exists(o_unit)\r\n{\r\n    with (o_unit)\r\n    {\r\n        if instance_exists(o_skill_bw_13) && o_skill_bw_13.is_open\r\n        {\r\n            if ((!is_player()) && is_visible() && faction_key != \"Servant\")\r\n            {\r\n                with (instance_create_depth(x, y, depth, o_archtheurgy_impact))\r\n                {\r\n                    is_crit = _crit\r\n                    owner = _own\r\n                }\r\n            }\r\n        }\r\n    }\r\n}", EventType.Other, 13);
            Msl.AddNewEvent("o_skill_bw_7", "var _can_cast = true\r\nif instance_exists(o_player)\r\n{\r\n    var _eff = scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs)\r\n    with (_eff)\r\n    {\r\n        if obs_cooldown\r\n            _can_cast = false\r\n    }\r\n}\r\nif _can_cast\r\n    event_inherited()", EventType.Other, 14);
            Msl.AddNewEvent("o_skill_bw_7", "if instance_exists(owner)\r\n{\r\n    ds_map_replace(data, \"LEVL\", (owner.LVL >= 21 ? \"VI\" : owner.LVL >= 16 ? \"V\" : owner.LVL >= 11 ? \"IV\" : owner.LVL >= 6 ? \"III\" : owner.LVL >= 1 ? \"II\" : \"I\"))\r\n    ds_map_replace(data, \"Servant_Number\", (global.servant_starting_number + global.servant_additional))\r\n}\r\nevent_inherited()", EventType.Other, 17);
            Msl.AddNewEvent("o_skill_bw_7", "with (o_player)\r\n    scr_setside(o_floor_target)\r\nvar _cur = scr_bw_targeter_res()\r\nwith (o_floor_target)\r\n    cursor = _cur", EventType.Other, 19);
            o_skill_bw_7_ico.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_resurrection_ico_Create_0.gml", EventType.Create, 0)
            );

            o_bw_wraith_summoning.ApplyEvent(ModFiles, //Wraith Binding
            new MslEvent("gml_Object_o_bw_wraith_summoning_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_wraith_summoning_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_bw_wraith_summoning_Other_7.gml", EventType.Other, 7),
            new MslEvent("gml_Object_o_bw_wraith_summoning_Other_10.gml", EventType.Other, 10)
            );
            o_skill_bw_14.ApplyEvent(ModFiles, //Wraith Binding
            new MslEvent("gml_Object_o_skill_bw_wraithsummon_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_wraithsummon_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_skill_bw_wraithsummon_Other_17.gml", EventType.Other, 17)
            );

            Msl.AddNewEvent("o_skill_bw_14", "var _can_cast = true\r\nif instance_exists(o_player)\r\n{\r\n    var _eff = scr_instance_exists_in_list(o_b_newfound_power, o_player.buffs)\r\n    with (_eff)\r\n    {\r\n        if obs_cooldown\r\n            _can_cast = false\r\n    }\r\n}\r\nif _can_cast\r\n    event_inherited()", EventType.Other, 14);

            o_skill_bw_14_ico.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_wraithsummon_ico_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_wraithsummon_ico_Step_2.gml", EventType.Step, 2)
            );

            o_skill_bw_4.ApplyEvent(ModFiles, //Death Blessing
            new MslEvent("gml_Object_o_skill_bw_dark_bless_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_dark_bless_Other_17.gml", EventType.Other, 17),
            new MslEvent("gml_Object_o_skill_bw_dark_bless_Other_13.gml", EventType.Other, 13)
            );
            o_skill_bw_4_ico.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_dark_bless_ico_Create_0.gml", EventType.Create, 0)
            );

            o_skill_bw_12.ApplyEvent(ModFiles, //Death Blessing
            new MslEvent("gml_Object_o_skill_bw_12_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_12_Other_17.gml", EventType.Other, 17),
            new MslEvent("gml_Object_o_skill_bw_12_Other_13.gml", EventType.Other, 13)
            );
            o_skill_bw_12_ico.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_12_ico_Create_0.gml", EventType.Create, 0)
            );

            o_skill_bw_8.ApplyEvent(ModFiles, //Absolute Darkness
            new MslEvent("gml_Object_o_skill_absolute_darkness_Create_0.gml", EventType.Create, 0)
            );
            Msl.AddNewEvent("o_skill_bw_8", "event_inherited()", EventType.Other, 13);
            Msl.AddNewEvent("o_skill_bw_8", "event_inherited()", EventType.Other, 17);

            o_skill_bw_10.ApplyEvent(ModFiles, //Mastery of Binding
            new MslEvent("gml_Object_o_skill_binding_mastery_Create_0.gml", EventType.Create, 0)
            );
            Msl.AddNewEvent("o_skill_bw_10", "event_inherited()", EventType.Other, 13);
            Msl.AddNewEvent("o_skill_bw_10", "event_inherited()", EventType.Other, 17);

            o_skill_bw_5.ApplyEvent(ModFiles, //Decay Flesh
            new MslEvent("gml_Object_o_pass_skill_shackles_of_darkness_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_pass_skill_shackles_of_darkness_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_pass_skill_shackles_of_darkness_Other_17.gml", EventType.Other, 17)
            );

            o_skill_bw_9.ApplyEvent(ModFiles, //Nightmare Rift
            new MslEvent("gml_Object_o_skill_bw_9_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_9_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_skill_bw_9_Other_17.gml", EventType.Other, 17)
            );

            o_skill_bw_9_ico.ApplyEvent(ModFiles, //Nightmare Rift
            new MslEvent("gml_Object_o_skill_bw_9_ico_Create_0.gml", EventType.Create, 0)
            );

            o_skill_bw_6.ApplyEvent(ModFiles, //Restless Spirit
            new MslEvent("gml_Object_o_pass_skill_restless_spirit_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_pass_skill_restless_spirit_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_pass_skill_restless_spirit_Other_17.gml", EventType.Other, 17)
            );

            o_skill_bw_11.ApplyEvent(ModFiles, //Immortality
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Step_2.gml", EventType.Step, 2),
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Other_17.gml", EventType.Other, 17)
            );

            o_skill_bw_13.ApplyEvent(ModFiles, //Mastery of Binding
            new MslEvent("gml_Object_o_skill_bw_13_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_13_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_skill_bw_13_Other_17.gml", EventType.Other, 17)
            );

            //Skills and some things related to them.

            Msl.AddNewEvent("o_bw_enemy_birth", "event_inherited()\r\ndepth = (-y) + 18\r\nimage_speed = 1\r\nblock_disable_frame = 0\r\nis_check = 0\r\ncreating_unit = 3721\r\nalarm[0] = 1\r\nowner = -4\r\ncreate_snd = -4\r\ngain_xp_k = 1\r\nisSummoning = false\r\nnew_sprite = -1\r\nspawn_x = x\r\nspawn_y = y\r\nis_crit = false\r\ninvisible = false", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_enemy_birth", "create_snd = choose(snd_zombie_revive_1, snd_zombie_revive_2, snd_zombie_revive_3)\r\nscr_audio_play_at(create_snd)\r\n", EventType.Alarm, 0);
            Msl.AddNewEvent("o_bw_enemy_birth", "event_inherited()\r\nif invisible\r\n{\r\n    visible = false\r\n    image_speed = 100\r\n}\r\n", EventType.Step, 1);
            Msl.AddNewEvent("o_bw_enemy_birth", "var _unit = scr_enemy_create(spawn_x, spawn_y, creating_unit, is_check)\r\nwith (_unit)\r\n{\r\n    owner = other.owner\r\n    if (other.new_sprite != -1)\r\n    {\r\n        sprite_index = other.new_sprite\r\n        spr = sprite_index\r\n        default_sprite = sprite_index\r\n    }\r\n    image_xscale = other.image_xscale\r\n    if instance_exists(owner)\r\n    {\r\n        scr_locationRoomEntityGenerateTag(id, owner.roomEntityTag)\r\n        scr_locationRoomEntityGeneratePresetTag(id, owner.roomEntityPresetTag)\r\n    }\r\n    if instance_exists(o_controller)\r\n    {\r\n        ds_grid_set(o_controller.posgrid, grid_x, grid_y, id)\r\n        astar_add_cell(o_controller.newgrid, grid_x, grid_y)\r\n    }\r\n    scr_agred(100)\r\n    event_user(5)\r\n    scr_enemy_fog_visible_update(id)\r\n    gain_xp *= other.gain_xp_k\r\n    if (object_index == o_astral_phantasm)\r\n    {\r\n        scr_effect_create(o_b_astral_phantasm, -1, id, owner)\r\n        scr_arcane_particles_spawn(13)\r\n    }\r\n    if object_is_ancestor(object_index, o_summoned_entity)\r\n        scr_effect_create(o_b_summoned_entity, scr_skill_get_duration((8 + 8 * other.is_crit), owner), id, owner)\r\n    is_cast_spell = true\r\n}\r\ninstance_destroy()", EventType.Other, 7);
            Msl.AddNewEvent("o_bw_enemy_birth", "draw_self()\r\n", EventType.Draw, 0);

            Msl.AddNewEvent("o_bw_harbingers_call", "event_inherited()\r\nspeed = 10", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_harbingers_call", "var _arr = []\r\nvar _trigger = true\r\nif !instance_exists(o_bw_coord_harbingers)\r\n    instance_create_depth(x, y, depth, o_bw_coord_harbingers)\r\nif instance_exists(o_player)\r\n{\r\n    if (instance_exists(target) && instance_exists(owner))\r\n    {\r\n        if (!disable)\r\n        {\r\n            if scr_water_filter(x, y, x, y)\r\n            {\r\n                var _targ = ds_grid_get_ext(o_controller.posgrid, (x div 26), (y div 26))\r\n                if (_targ > o_confirm_panel)\r\n                {\r\n                    if instance_exists(_targ)\r\n                    {\r\n                        if object_is_ancestor(_targ.object_index, o_unit)\r\n                        {\r\n                            if (scr_can_be_broken(_targ) || object_is_ancestor(object_index, c_skill_aura_smoke))\r\n                                _trigger = false\r\n                        }\r\n                    }\r\n                }\r\n            }\r\n        }\r\n    }\r\n}\r\nif _trigger\r\n{\r\n    array_push(_arr, x, y)\r\n    array_push(o_bw_coord_harbingers.coord_array, _arr)\r\n}\r\ninstance_destroy()", EventType.Other, 10);

            Msl.AddNewEvent("o_bw_coord_harbingers", "coord_array = []\r\nalarm[1] = 10", EventType.Create, 0);
            Msl.AddNewEvent("o_bw_coord_harbingers", "var _num = array_length(coord_array) - 1\r\nvar _high_num = irandom_range(0, _num)\r\nvar _randomize = coord_array[_high_num]\r\nvar _new_arr = []\r\nfor (var _i = 0; _i < array_length(coord_array); _i++)\r\n{\r\n    if (coord_array[_i] != _randomize)\r\n        array_push(_new_arr, coord_array[_i])\r\n}\r\ncoord_array = _new_arr\r\nwith (instance_create_depth(_randomize[0], _randomize[1], 0, o_bw_enemy_birth))\r\n{\r\n    is_check = false\r\n    scr_set_lt()\r\n    sprite_index = s_bw_herald_birth\r\n    creating_unit = o_bw_harbinger_madness_z\r\n}\r\nalarm[2] = 35", EventType.Alarm, 1);
            Msl.AddNewEvent("o_bw_coord_harbingers", "var _num = array_length(coord_array) - 1\r\nvar _high_num = irandom_range(0, _num)\r\nvar _randomize = coord_array[_high_num]\r\nvar _new_arr = []\r\nfor (var _i = 0; _i < array_length(coord_array); _i++)\r\n{\r\n    if (coord_array[_i] != _randomize)\r\n        array_push(_new_arr, coord_array[_i])\r\n}\r\ncoord_array = _new_arr\r\nwith (instance_create_depth(_randomize[0], _randomize[1], 0, o_bw_enemy_birth))\r\n{\r\n    is_check = false\r\n    scr_set_lt()\r\n    sprite_index = s_bw_herald_birth\r\n    creating_unit = o_bw_harbinger_darkness_z\r\n}\r\nalarm[3] = 35", EventType.Alarm, 2);
            Msl.AddNewEvent("o_bw_coord_harbingers", "var _num = array_length(coord_array) - 1\r\nvar _high_num = irandom_range(0, _num)\r\nvar _randomize = coord_array[_high_num]\r\nvar _new_arr = []\r\nfor (var _i = 0; _i < array_length(coord_array); _i++)\r\n{\r\n    if (coord_array[_i] != _randomize)\r\n        array_push(_new_arr, coord_array[_i])\r\n}\r\ncoord_array = _new_arr\r\nwith (instance_create_depth(_randomize[0], _randomize[1], 0, o_bw_enemy_birth))\r\n{\r\n    is_check = false\r\n    scr_set_lt()\r\n    sprite_index = s_bw_herald_birth\r\n    creating_unit = o_bw_harbinger_chaos_z\r\n}\r\nalarm[4] = 35", EventType.Alarm, 3);
            Msl.AddNewEvent("o_bw_coord_harbingers", "scr_allturn()\r\ninstance_destroy()", EventType.Alarm, 4);

            o_bw_harbingers_birth.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_harbingers_birth_Create_0.gml", EventType.Create, 0)
            );

            o_b_angel_charm.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_b_angel_charm_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_b_angel_charm_Alarm_2.gml", EventType.Alarm, 2),
            new MslEvent("gml_Object_o_b_angel_charm_Other_10.gml", EventType.Other, 10)
            );

            o_archtheurgy_impact.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_archtheurgy_impact_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_archtheurgy_impact_Alarm_1.gml", EventType.Alarm, 1)
            );

            o_bw_sign_of_darkness_birth.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_sign_of_darkness_birth_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_sign_of_darkness_birth_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_bw_sign_of_darkness_birth_Other_10.gml", EventType.Other, 10)
            );

            o_bw_sign_of_darkness.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_sign_of_darkness_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_sign_of_darkness_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_bw_sign_of_darkness_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_bw_sign_of_darkness_Other_11.gml", EventType.Other, 11)
            );

            o_pass_skill_bw_immortality.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Alarm_7.gml", EventType.Alarm, 7),
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Other_17.gml", EventType.Other, 17),
            new MslEvent("gml_Object_o_pass_skill_bw_immortality_Step_2.gml", EventType.Step, 2)
            );

            o_bw_darkbless.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_darkbless_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_darkbless_Other_7.gml", EventType.Other, 7),
            new MslEvent("gml_Object_o_bw_darkbless_Draw_0.gml", EventType.Draw, 0)
            );

            o_skill_bw_dark_bless.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_dark_bless_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_dark_bless_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_skill_bw_dark_bless_Other_17.gml", EventType.Other, 17)
            );

            o_bw_blessing_birth.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_blessing_birth_Create_0.gml", EventType.Create, 0)
            );

            o_b_deathbless.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_b_deathbless_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_b_deathbless_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_b_deathbless_Alarm_2.gml", EventType.Alarm, 2),
            new MslEvent("gml_Object_o_b_deathbless_Other_15.gml", EventType.Other, 15)
            );
            Msl.AddNewEvent("o_b_deathbless", "", EventType.Alarm, 1);
            Msl.AddNewEvent("o_b_deathbless", "event_inherited()\r\nevent_user(5)", EventType.Other, 10);

            o_inv_bw_journal1.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_inv_bw_journal1_Create_0.gml", EventType.Create, 0)
            );

            o_loot_bw_journal1.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_loot_bw_journal1_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_loot_bw_journal1_Other_11.gml", EventType.Other, 11)
            );

            o_inv_bwbook.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_inv_bwbook_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_inv_bwbook_Alarm_0.gml", EventType.Alarm, 0),
            new MslEvent("gml_Object_o_inv_bwbook_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_inv_bwbook_Other_24.gml", EventType.Other, 24),
            new MslEvent("gml_Object_o_inv_bwbook_Other_25.gml", EventType.Other, 25)
            );

            o_bw_open_book.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_open_book_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_open_book_Alarm_0.gml", EventType.Alarm, 0),
            new MslEvent("gml_Object_o_bw_open_book_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_bw_open_book_Draw_0.gml", EventType.Draw, 0),
            new MslEvent("gml_Object_o_bw_open_book_Other_5.gml", EventType.Other, 5),
            new MslEvent("gml_Object_o_bw_open_book_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_bw_open_book_Other_24.gml", EventType.Other, 24),
            new MslEvent("gml_Object_o_bw_open_book_Other_25.gml", EventType.Other, 25)
            );

            o_allAttack_Attitude.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_allAttack_Attitude_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_allAttack_Attitude_Mouse_7.gml", EventType.Mouse, 7),
            new MslEvent("gml_Object_o_allAttack_Attitude_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_allAttack_Attitude_Other_12.gml", EventType.Other, 12)
            );

            o_bw_printer.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_printer_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_printer_Alarm_0.gml", EventType.Alarm, 0),
            new MslEvent("gml_Object_o_bw_printer_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_bw_printer_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_bw_printer_Other_11.gml", EventType.Other, 11),
            new MslEvent("gml_Object_o_bw_printer_Other_12.gml", EventType.Other, 12),
            new MslEvent("gml_Object_o_bw_printer_Step_0.gml", EventType.Step, 0),
            new MslEvent("gml_Object_o_bw_printer_Draw_0.gml", EventType.Draw, 0)
            );

            o_bw_chart.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_chart_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_chart_Alarm_0.gml", EventType.Alarm, 0),
            new MslEvent("gml_Object_o_bw_chart_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_bw_chart_Mouse_53.gml", EventType.Mouse, 53),
            new MslEvent("gml_Object_o_bw_chart_Draw_0.gml", EventType.Draw, 0)
            );

            o_allDeffence_Attitude.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_allDeffence_Attitude_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_allDeffence_Attitude_Mouse_7.gml", EventType.Mouse, 7),
            new MslEvent("gml_Object_o_allDeffence_Attitude_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_allDeffence_Attitude_Other_12.gml", EventType.Other, 12)
            );

            o_bw_resurrection.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_resurrection_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_resurrection_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_bw_resurrection_Alarm_0.gml", EventType.Alarm, 0),
            new MslEvent("gml_Object_o_bw_resurrection_Other_7.gml", EventType.Other, 7),
            new MslEvent("gml_Object_o_bw_resurrection_Draw_0.gml", EventType.Draw, 0)
            );

            o_bw_resurrection_birth.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_resurrection_birth_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_resurrection_birth_Other_7.gml", EventType.Other, 7),
            new MslEvent("gml_Object_o_bw_resurrection_birth_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_bw_resurrection_birth_Draw_0.gml", EventType.Draw, 0)
            );

            o_skill_bw_resurrection_ico.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_resurrection_ico_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_resurrection_ico_Step_2.gml", EventType.Step, 2)
            );

            o_skill_bw_resurrection.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_resurrection_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_resurrection_Other_17.gml", EventType.Other, 17),
            new MslEvent("gml_Object_o_skill_bw_resurrection_Other_14.gml", EventType.Other, 14),
            new MslEvent("gml_Object_o_skill_bw_resurrection_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_skill_bw_resurrection_Other_19.gml", EventType.Other, 19)
            );

            o_darkball2.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_darkball2_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_darkball2_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_darkball2_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_darkball2_Other_11.gml", EventType.Other, 11)
            );

            o_bw_ballbirth.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_bw_ballbirth_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_bw_ballbirth_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_bw_ballbirth_Other_17.gml", EventType.Other, 17)
            );

            o_inv_occult_text1.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_inv_occult_text1_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_inv_occult_text1_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_inv_occult_text1_Other_24.gml", EventType.Other, 24)
            );

            o_loot_occult_text1.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_loot_occult_text1_Create_0.gml", EventType.Create, 0)
            );

            o_inv_occult_text2.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_inv_occult_text2_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_inv_occult_text2_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_inv_occult_text2_Other_24.gml", EventType.Other, 24)
            );

            o_loot_occult_text2.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_loot_occult_text2_Create_0.gml", EventType.Create, 0)
            );

            o_inv_occult_text3.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_inv_occult_text3_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_inv_occult_text3_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_inv_occult_text3_Other_24.gml", EventType.Other, 24)
            );

            o_loot_occult_text3.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_loot_occult_text3_Create_0.gml", EventType.Create, 0)
            );

            o_inv_occult_text4.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_inv_occult_text4_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_inv_occult_text4_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_inv_occult_text4_Other_24.gml", EventType.Other, 24)
            );

            o_loot_occult_text4.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_loot_occult_text4_Create_0.gml", EventType.Create, 0)
            );

            o_soul_absorption_impact.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_soul_absorption_impact_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_soul_absorption_impact_Alarm_1.gml", EventType.Alarm, 1)
            );

            o_former_physician.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_former_physician_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_former_physician_Other_12.gml", EventType.Other, 12),
            new MslEvent("gml_Object_o_former_physician_Draw_73.gml", EventType.Draw, 73)
            );

            o_perk_order_and_chaos.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_perk_order_and_chaos_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_perk_order_and_chaos_Other_10.gml", EventType.Other, 10)
            );

            o_b_corpse_dur.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_b_corpse_dur_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_b_corpse_dur_Alarm_2.gml", EventType.Alarm, 2),
            new MslEvent("gml_Object_o_b_corpse_dur_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_b_corpse_dur_Other_15.gml", EventType.Other, 15)
            );

            o_b_ammo_count.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_b_ammo_count_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_b_ammo_count_Alarm_2.gml", EventType.Alarm, 2),
            new MslEvent("gml_Object_o_b_ammo_count_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_b_ammo_count_Other_15.gml", EventType.Other, 15)
            );

            o_b_unbind.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_b_unbind_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_b_unbind_Mouse_53.gml", EventType.Mouse, 53),
            new MslEvent("gml_Object_o_b_unbind_Other_10.gml", EventType.Other, 10)
            );

            o_skill_bwammo.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bwammo_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bwammo_Alarm_0.gml", EventType.Alarm, 0),
            new MslEvent("gml_Object_o_skill_bwammo_Other_20.gml", EventType.Other, 20),
            new MslEvent("gml_Object_o_skill_bwammo_Other_11.gml", EventType.Other, 11)
            );

            o_skill_bw_targeting.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_skill_bw_targeting_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_skill_bw_targeting_Alarm_1.gml", EventType.Alarm, 1),
            new MslEvent("gml_Object_o_skill_bw_targeting_Step_0.gml", EventType.Step, 0),
            new MslEvent("gml_Object_o_skill_bw_targeting_Other_17.gml", EventType.Other, 17),
            new MslEvent("gml_Object_o_skill_bw_targeting_Other_13.gml", EventType.Other, 13),
            new MslEvent("gml_Object_o_skill_bw_targeting_Other_25.gml", EventType.Other, 25),
            new MslEvent("gml_Object_o_skill_bw_targeting_Draw_0.gml", EventType.Draw, 0)
            );

            o_b_servemaster.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_b_servemaster_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_b_servemaster_Destroy_0.gml", EventType.Destroy, 0),
            new MslEvent("gml_Object_o_b_servemaster_Alarm_2.gml", EventType.Alarm, 2),
            new MslEvent("gml_Object_o_b_servemaster_Alarm_7.gml", EventType.Alarm, 7),
            new MslEvent("gml_Object_o_b_servemaster_Alarm_6.gml", EventType.Alarm, 6),
            new MslEvent("gml_Object_o_b_servemaster_Alarm_8.gml", EventType.Alarm, 8),
            new MslEvent("gml_Object_o_b_servemaster_Step_0.gml", EventType.Step, 0),
            new MslEvent("gml_Object_o_b_servemaster_Mouse_54.gml", EventType.Mouse, 54),
            new MslEvent("gml_Object_o_b_servemaster_Mouse_53.gml", EventType.Mouse, 53),
            new MslEvent("gml_Object_o_b_servemaster_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_b_servemaster_Other_23.gml", EventType.Other, 23),
            new MslEvent("gml_Object_o_b_servemaster_Other_15.gml", EventType.Other, 15),
            new MslEvent("gml_Object_o_b_servemaster_KeyPress_77.gml", EventType.KeyPress, 77),
            new MslEvent("gml_Object_o_b_servemaster_KeyPress_78.gml", EventType.KeyPress, 78),
            new MslEvent("gml_Object_o_b_servemaster_KeyPress_86.gml", EventType.KeyPress, 86)
            );

            o_b_charged_soul.ApplyEvent(ModFiles,
            new MslEvent("gml_Object_o_b_charged_soul_Create_0.gml", EventType.Create, 0),
            new MslEvent("gml_Object_o_b_charged_soul_Alarm_2.gml", EventType.Alarm, 2),
            new MslEvent("gml_Object_o_b_charged_soul_Alarm_3.gml", EventType.Alarm, 3),
            new MslEvent("gml_Object_o_b_charged_soul_Step_2.gml", EventType.Step, 2),
            new MslEvent("gml_Object_o_b_charged_soul_Other_10.gml", EventType.Other, 10),
            new MslEvent("gml_Object_o_b_charged_soul_Other_14.gml", EventType.Other, 14)
            );
        }
    }
}
